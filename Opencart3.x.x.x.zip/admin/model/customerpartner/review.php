<?php
class ModelCustomerpartnerReview extends Model {
	/**
 * [getTotalReviews number of allreview]
 * @param  array  $data [filter values]
 * @return [int]       [number of all reviewws according to the filter value]
 */
  public function getTotalReviews($data = array()) {
    $sql = "SELECT COUNT(*) AS total FROM " . DB_PREFIX .  "customerpartner_to_feedback c WHERE c.review != ''";

    // if (!empty($data['filter_product'])) {
    //   $sql .= " AND cd.name LIKE '%" . $this->db->escape($data['filter_product']) . "%'";
    // }

    if (!empty($data['filter_author'])) {
      $sql .= " AND c.nickname LIKE '%" . $this->db->escape($data['filter_author']) . "%'";
    }

    if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
      $sql .= " AND c.status = '" . (int)$data['filter_status'] . "'";
    }

    if (!empty($data['filter_date_added'])) {
      $sql .= " AND DATE(c.createdate) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
    }

    $query = $this->db->query($sql);

    return $query->row['total'];
  }
  /**
 * [getReviews array of all reviews]
 * @param  array  $data [filter values]
 * @return [array]       [details of all reviews]
 */
  public function getReviews($data = array()) {

    $sql = "SELECT c.* FROM " . DB_PREFIX . "customerpartner_to_feedback c WHERE c.review != '' ";

    // if (!empty($data['filter_product'])) {
    //   $sql .= " AND cd.name LIKE '%" . $this->db->escape($data['filter_product']) . "%'";
    // }
 	if (!empty($data['filter_author'])) {
      $sql .= " AND c.nickname LIKE '%" . $this->db->escape($data['filter_author']) . "%'";
    }

    if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
      $sql .= " AND c.status = '" . (int)$data['filter_status'] . "'";
    }

    if (!empty($data['filter_date_added'])) {
      $sql .= " AND DATE(c.createdate) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
    }

    $sort_data = array(
      //'c.name',
      'c.nickname',
      'c.status',
      'c.createdate'
    );

    if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
      $sql .= " ORDER BY " . $data['sort'];
    } else {
      $sql .= " ORDER BY c.createdate";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC";
    } else {
      $sql .= " ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
    }

    $query = $this->db->query($sql);
   
   
    return $query->rows;
  }

  /**
 * [getReview information about particular review]
 * @param  [int] $review_id [review id of review]
 * @return [array]            [details of review in array]
 */
  public function getReview($review_id) {
    $query = $this->db->query("SELECT * FROM ".DB_PREFIX. "customerpartner_to_feedback WHERE id = '" . (int)$review_id . "'");

    return $query->row;
  }
  /**
 * [editReview update the existing review]
 * @param  [int] $review_id [review id ]
 * @param  [array] $data      [details of review]
 */
  public function editReview($review_id, $data) {
    $this->db->query("UPDATE " . DB_PREFIX . "customerpartner_to_feedback SET nickname = '" . $this->db->escape($data['author']) . "', review = '" . $this->db->escape(strip_tags($data['text'])) . "', feedprice = '" . (int)$data['price'] . "', feedvalue = '" . (int)$data['value'] . "', feedquality = '".(int)$data['quality']."',status = '".(int)$data['status']."' WHERE id = '".(int)$review_id."'");
  }
  /**
 * [deleteReview delete particular review by review id]
 * @param  [int] $review_id [review id which is to be delete]
 */
  public function deleteReview($review_id) {
    $this->db->query("DELETE FROM " . DB_PREFIX . "wk_hotel_reviews WHERE id = '" . (int)$review_id . "'");

  }

}
?>