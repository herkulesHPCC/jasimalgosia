<?php

class ModelCatalogWkhotelbookinghotels extends Model {
	//Facilities
  /**
   * [getFacilities description]
   * @param  [array] $filterValue [array of filters value]
   * @return [array]              [facilities arrray according to filter]
   */
    public function getFacilities($filterValue) {
      $sql = "SELECT * FROM ".DB_PREFIX."wk_hotel_facility wkh WHERE wkh.facility_type=1 ";
      if(!empty($filterValue['name'])) {
          $sql .= " AND wkh.facility_name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND wkh.status = '".(int)$filterValue['status']."' ";
        }
         if(isset($filterValue['type']) && !is_null($filterValue['type'])) {
            $sql .= " AND wkh.status = '".$filterValue['type']."' ";
         }
        if(!empty($filterValue['order'])) {
            if($filterValue['order'] == 'name')
              $sql .= " ORDER BY wkh.facility_name ".$filterValue['sort']." LIMIT ".$filterValue['start'].",".$filterValue['end'];
            else
              $sql .= " ORDER BY wkh.".$this->db->escape($filterValue['order'])." ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }else{
          $sql .= " LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }
      $result = $this->db->query($sql)->rows;
      return $result;
    }


/**
 * [getTotalFacilities description]
 * @param  [array] $filterValue [array of filters value]
 * @return [int]              [number of results of facilitites]
 */
    public function getTotalFacilities($filterValue) {
      $sql = "SELECT * FROM ".DB_PREFIX."wk_hotel_facility wkh WHERE wkh.facility_type=1 ";
      if(!empty($filterValue['name'])) {
          $sql .= " AND wkh.facility_name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND wkh.status = '".(int)$filterValue['status']."' ";
        }
        if(isset($filterValue['type']) && !is_null($filterValue['type'])) {
            $sql .= " AND wkh.status = '".$filterValue['type']."' ";
         }
      $result = $this->db->query($sql)->rows;
      return count($result);
    }



    /**
     * [addFacility description]
     * @param array  $data [array of facility value]
     * @param [type] $type [fixed/optional]
     */
    public function addFacility($data = array(),$type) {
      $this->db->query("INSERT INTO ".DB_PREFIX."wk_hotel_facility SET facility_name='".$this->db->escape($data['name'])."',facility_image = '".$this->db->escape($data['image'])."',status = '".(int)$data['status']."',sort_order = '".(int)$data['sort_order']."',facility_type = '".(int)$type."',facility_ocid = '".(int)$data['facility_ocid']."',owner=0");
    }



/**
 * [deleteOptFacility optional facility]
  */
    public function deleteOptFacility() {
      $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_facility WHERE facility_type = 2");
    }


/**
 * [deleteFxFacility fixed facility]
 * @param  [int] $attribute_id [facility_ocid of facility]
 */
    public function deleteFxFacility($attribute_id) {
      $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_facility WHERE facility_ocid = '".(int)$attribute_id."'");
    }


/**
 * [getFacility for particular facility]
 * @param  [int] $facility_id [facility_ocid]
 * @return [array]              [details of particular facility]
 */
    public function getFacility($facility_id) {
    	$result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_facility WHERE facility_ocid = '".(int)$facility_id."'")->row;
    	return $result;
    }

/**
 * Edit the facility by getting it's ocid and type(fixed/optional)
 */

    public function editFacility($facility_id,$data=array(),$type) {
    	 $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_facility SET facility_name = '" . $this->db->escape($data['name']) . "',facility_image = '".$this->db->escape($data['image'])."', status = '".(int)$data['status']."', sort_order= '".$this->db->escape($data['sort_order'])."', facility_type ='".(int)$type."' WHERE facility_ocid = '" . (int)$facility_id . "'");
    }
/**
 * [getEnableFacilities for getting ponly enable facilites in autocomplete at time of adding room]
 * @return [array] [enable  facilities]
 */
    public function getEnableFacilities() {
      $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_facility WHERE status=1")->rows;
      return $result;
    }

/**
 * [geTotalRoomFacilities all rooms of a hotel with hotel_id]
 * @param  [int] $hotel_id [hotel id of hotel]
 * @return [array]           [array of rooms with thier details]
 */
    public function geTotalRoomFacilities($hotel_id) {
      $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_room_detail WHERE hotel_id = '".(int)$hotel_id."'")->rows;
      return $result;
    }
/**
 * [geRoomFacilities for facilities of particular room]
 * @param  [int] $hotel_id [id of hotel]
 * @param  [int] $room_id  [id of room]
 * @return [type]           [array of room details]
 */
    public function geRoomFacilities($hotel_id,$room_id) {
      $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_room_detail WHERE hotel_id = '".(int)$hotel_id."' AND room_id='".(int)$room_id."'")->row;
      return $result;
    }

/**
 * [getFixedFacility return all fixed facilities]
 * @return [array] [array of all attribute with details]
 */
    public function getFixedFacility($filterValue = array()) {
     $sql = "SELECT DISTINCT *, (SELECT agd.name FROM " . DB_PREFIX . "attribute_group_description agd WHERE agd.attribute_group_id = a.attribute_group_id AND agd.language_id = '" . (int)$this->config->get('config_language_id') . "') AS attribute_group FROM " . DB_PREFIX . "attribute a LEFT JOIN " . DB_PREFIX . "attribute_description ad ON (a.attribute_id = ad.attribute_id) LEFT JOIN ".DB_PREFIX."wk_hotel_facility wh ON (a.attribute_id = wh.facility_ocid) WHERE ad.language_id = '" . (int)$this->config->get('config_language_id') . "' AND wh.status = 1 AND wh.facility_type = 1";

     if(isset($filterValue['filter_name']) && $filterValue['filter_name']) {
        $sql .= " AND ad.name LIKE '%".$this->db->escape($filterValue['filter_name'])."%'";
     }
     $query = $this->db->query($sql);

    return $query->rows;
    }
    //Rooms
    /**
     * [getRooms return all rooms]
     * @return [array] [arrray of all rooms]
     */
     public function getRooms($filterValue) {
      $sql = "SELECT DISTINCT p.*,pd.name,cd.name as hotel_name,wr.owner as owner, wr.approve FROM ".DB_PREFIX."product p RIGHT JOIN ".DB_PREFIX."wk_hotel_room wr ON (p.product_id=wr.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON(p.product_id=pd.product_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id=wr.hotel_id) WHERE cd.language_id = '".$this->config->get('config_language_id')."'";




      if(isset($filterValue['name']) && !is_null($filterValue['name'])) {
          $sql .= " AND cd.name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND p.status = ".(int)$filterValue['status']."";
        }
        if(isset($filterValue['rname']) && !is_null($filterValue['rname'])) {
          $sql .= " AND pd.name like '%".$this->db->escape($filterValue['rname'])."%' ";
        }
        if(isset($filterValue['price']) && !is_null($filterValue['price'])) {
          $sql .= " AND p.price = ".(float)$filterValue['price']." ";
        }
        if(isset($filterValue['type']) && !is_null($filterValue['type'])) {
          $sql .= " AND p.status = ".(int)$filterValue['type']."";
        }


        if(!empty($filterValue['order'])) {
            if($filterValue['order'] == 'name')
              $sql .= " ORDER BY cd.name ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            elseif($filterValue['order'] == 'price')
              $sql .= " ORDER BY p.price ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            elseif($filterValue['order'] == 'rname')
              $sql .= " ORDER BY pd.name ".$filterValue['sort']." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            else
              $sql .= " ORDER BY whd.".$filterValue['order']." ".$filterValue['sort']." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }else if(isset($filterValue['start'])){
          $sql .= " LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }
      $results = $this->db->query($sql)->rows;
      $return_result = array();
      if($results) {
         foreach ($results as $result) {
           $return_result[] = array(
            'name' => $result['name'],
            'image' =>$result['image'],
            'status'=>$result['status'],
            'price'=>$result['price'],
            'room_id'=>$result['product_id'],
            'hotel_name' => $result['hotel_name'],
            'owner' => $result['owner'],
            'approve' => $result['approve']
            );
         }
       }
      return $return_result;
    }

    public function getTotoalRooms($filterValue) {
       $sql = "SELECT DISTINCT p.*,pd.name,cd.name as hotel_name FROM ".DB_PREFIX."product p RIGHT JOIN ".DB_PREFIX."wk_hotel_room wr ON (p.product_id=wr.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON(p.product_id=pd.product_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id=wr.hotel_id) WHERE cd.language_id = '".$this->config->get('config_language_id')."'";




       if(isset($filterValue['name']) && !is_null($filterValue['name'])) {
          $sql .= " AND cd.name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND p.status = ".(int)$filterValue['status']."";
        }
        if(isset($filterValue['rname']) && !is_null($filterValue['rname'])) {
          $sql .= " AND pd.name
           like '%".$this->db->escape($filterValue['rname'])."%' ";
        }
        if(isset($filterValue['price']) && !is_null($filterValue['price'])) {
          $sql .= " AND p.price = ".(float)$filterValue['price']." ";
        }
         if(isset($filterValue['type']) && !is_null($filterValue['type'])) {
          $sql .= " AND p.status = ".(int)$filterValue['type']."";
        }
      $results = $this->db->query($sql)->rows;
      return count($results);
    }
    /**
     * [addRoom insert the room details in wk_hotel_room table and add the required options to the room]
     * @param [int] $product_id [product_id of room]
     * @param array  $data       [details about room(product)]
     */
    public function addRoom($product_id , $data = array()) {

        $hotel_status = $this->db->query("SELECT owner,status FROM ".DB_PREFIX."wk_hotel_details WHERE category_id = '".(int)$data['hotel_id']."'")->row;

        if($hotel_status) {
          if(!(int)$data['max_adult']) {
            $data['max_adult'] = 1;
          }
            $this->db->query("INSERT " . DB_PREFIX . "wk_hotel_room VALUES('".(int)$product_id."','".(int)$data['quantity']."', '".$this->db->escape($data['image'])."','".(int)$data['status']."','".(float)$data['price']."','".(int)$data['max_adult']."','".(int)$data['max_child']."','".(int)$data['hotel_id']."','".$this->db->escape($data['from'])."','".$this->db->escape($data['till'])."','".(int)$hotel_status['owner']."', approve = '".(int)$data['approve']."')");
        }

        //Get the status of hotel

        if($hotel_status && isset($hotel_status['status']) && $hotel_status['status'] == 0 && $data['status']) {
          $this->db->query("UPDATE ".DB_PREFIX."product SET status = 0 WHERE product_id = '".(int)$room_id."'");
          $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_room SET status = 0 WHERE product_id = '".(int)$room_id."'");
        }

          $duration=$this->config->get('wk_hotelbooking_options0');
          $rate=$this->config->get('wk_hotelbooking_options1');
          $from=$this->config->get('wk_hotelbooking_options2');
          $till=$this->config->get('wk_hotelbooking_options3');
          $adult=$this->config->get('wk_hotelbooking_options4');
          $child=$this->config->get('wk_hotelbooking_options5');
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$duration."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$rate."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$from."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$till."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$adult."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$product_id."','".(int)$child."','',0) ");

    }
    /**
     * [getRoom for information about particular room]
     * @param  [int] $room_id [product id of room]
     * @return [array]          [details about particular room in array]
     */
    public function getRoom($room_id) {
        $query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "product p LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) LEFT JOIN ".DB_PREFIX."wk_hotel_room wr ON (wr.product_id = p.product_id) WHERE p.product_id = '" . (int)$room_id . "' AND pd.language_id = '" . (int)$this->config->get('config_language_id') . "'");
        return $query->row;
    }
    /**
     * [editRoom for update the room value after edit]
     * @param  [int] $room_id [product_id of room]
     * @param  array  $data    [updated values during edit]
     */
    public function editRoom($room_id,$data=array()) {

        $hotel_status = $this->db->query("SELECT owner,status FROM ".DB_PREFIX."wk_hotel_details WHERE category_id = '".(int)$data['hotel_id']."'")->row;
        if($hotel_status) {
          if(!(int)$data['max_adult']) {
            $data['max_adult'] = 1;
          }
          $sql = "UPDATE ".DB_PREFIX."wk_hotel_room SET quantity = '" . (int)$data['quantity'] . "',image = '".$this->db->escape($data['image'])."', status = '".(int)$data['status']."', price= '".(float)$data['price']."' , max_adult ='".(int)$data['max_adult']."' , max_child ='".(int)$data['max_child']."' , hotel_id = '".$data['hotel_id']."' , start_from = '".$data['from']."', till = '".$data['till']."' , owner = '".(int)$hotel_status['owner']."'";

          if($hotel_status['owner']==0) {
            $sql.=" , approve = 1 ";
          }
          $sql.=" WHERE product_id = '" . (int)$room_id . "'";
          $this->db->query($sql);


          $options= $this->db->query("SELECT product_option_id FROM " . DB_PREFIX . "product_option WHERE product_id='".(int)$room_id."' AND option_id= '".(int)$this->config->get('wk_hotelbooking_options0')."'")->row;
          if(!$options){
          $duration=$this->config->get('wk_hotelbooking_options0');
          $rate=$this->config->get('wk_hotelbooking_options1');
          $from=$this->config->get('wk_hotelbooking_options2');
          $till=$this->config->get('wk_hotelbooking_options3');
          $adult=$this->config->get('wk_hotelbooking_options4');
          $child=$this->config->get('wk_hotelbooking_options5');
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$duration."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$rate."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$from."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$till."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$adult."','',1) ");
          $this->db->query("INSERT INTO " . DB_PREFIX . "product_option VALUES('','".(int)$room_id."','".(int)$child."','',0) ");
          }
        }
        if($hotel_status && isset($hotel_status['status']) && $hotel_status['status'] == 0 && $data['status']) {
          $this->db->query("UPDATE ".DB_PREFIX."product SET status = 0 WHERE product_id = '".(int)$room_id."'");
          $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_room SET status = 0 WHERE product_id = '".(int)$room_id."'");
        }
    }
    /**
     * [getRoomOfHotel rooms of particular hotel]
     * @param  [int] $hotel_id [id of hotel]
     * @return [array]           [room details of hotel in array]
     */
    public function getRoomOfHotel($hotel_id){
      $results = $this->db->query("SELECT wr.*,p.name FROM ".DB_PREFIX."wk_hotel_room wr LEFT JOIN ".DB_PREFIX."product_description p ON (wr.product_id=p.product_id) WHERE hotel_id ='".(int)$hotel_id."' AND p.language_id = '".(int)$this->config->get('config_language_id')."'")->rows;
      return $results;
     }
/**
 * [deleteRoom description]
 * @param  [int] $product_id [product_id of room]
 */
    public function deleteRoom($product_id) {
         $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_room WHERE product_id='".(int)$product_id."'");
    }

    //Hotels
    /**
     * [getHotels return all hotels]
     * @param  array  $filterValue
     * @return [array]              [all hotels details according to the filtervalue]
     */
     public function getHotels($filterValue = array()) {

      $sql = "SELECT whd.*,c.image,cd.name FROM ".DB_PREFIX."wk_hotel_details whd LEFT JOIN ".DB_PREFIX."category c ON (whd.category_id=c.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (whd.category_id=cd.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "'";
      if(isset($filterValue['name']) && !is_null($filterValue['name'])) {
          $sql .= " AND cd.name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND whd.status = ".(int)$filterValue['status']."";
        }
        if(isset($filterValue['website']) && !is_null($filterValue['website'])) {
          $sql .= " AND whd.website like '%".$this->db->escape($filterValue['website'])."%' ";
        }
        if(isset($filterValue['address']) && !is_null($filterValue['address'])) {
          $sql .= " AND whd.address like '%".$this->db->escape($filterValue['address'])."%' ";
        }
        if(isset($filterValue['type']) && !is_null($filterValue['type'])) {
          $sql .= " AND whd.status = ".(int)$filterValue['type']."";
        }

        if(!empty($filterValue['order'])) {
            if($filterValue['order'] == 'name')
              $sql .= " ORDER BY cd.name ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
            else
              $sql .= " ORDER BY whd.".$this->db->escape($filterValue['order'])." ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }else if(isset($filterValue['start'])){
          $sql .= " LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
        }
      $result = $this->db->query($sql)->rows;

      return $result;
    }
    public function getAllHotels($filterValue = array()) {

      $sql = "SELECT whd.*,c.image,cd.name FROM ".DB_PREFIX."wk_hotel_details whd LEFT JOIN ".DB_PREFIX."category c ON (whd.category_id=c.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (whd.category_id=cd.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "'";
      if(!empty($filterValue['name'])) {
          $sql .= " AND cd.name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if (isset($filterValue['status']) && !is_null($filterValue['status'])) {
          $sql .= " AND whd.status = ".(int)$filterValue['status']."";
        }
        if(!empty($filterValue['website'])) {
          $sql .= " AND whd.website like '%".$this->db->escape($filterValue['website'])."%' ";
        }
        if(!empty($filterValue['address'])) {
          $sql .= " AND whd.address like '%".$this->db->escape($filterValue['address'])."%' ";
        }
        if(isset($filterValue['type']) && !is_null($filterValue['type'])) {
          $sql .= " AND whd.status = ".(int)$filterValue['type']."";
        }
      $result = $this->db->query($sql)->rows;

      return count($result);
    }
/**
 * [addHotel adding the new hotel ]
 * @param [int] $category_id [category id which is from opencart after adding to the category]
 * @param [array] $postData    [other hotel details saved on our tables]
 */
    public function addHotel($category_id,$postData) {
      $lat=0;
      $long=0;
            $address = str_replace(" ", "+", $postData['bookingaddress']);
            $url = "https://maps.google.com/maps/api/geocode/json?key=". $this->config->get('module_wk_hotelbooking_res_google_key') ."&address=$address";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
            // curl_setopt($ch, CURLOPT_true_VERIFYHOST, 0);
            // curl_setopt($ch, CURLOPT_true_VERIFYPEER, 0);
            $response = curl_exec($ch);
            curl_close($ch);
            $response_a = json_decode($response);
            if(isset($response_a->results) && isset($response_a->results[0]->geometry->location->lat))
            $lat = $response_a->results[0]->geometry->location->lat;
            if(isset($response_a->results) && isset($response_a->results[0]->geometry->location->lng))
            $long = $response_a->results[0]->geometry->location->lng;
            $owner = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_details WHERE category_id='".(int)$category_id."'")->row;
            if(isset($owner['owner']) && $owner['owner']) {
              $hotel_owner = $owner['owner'];
              $postData['approve'] = $owner['approve'];
            } else {
              $hotel_owner = 0;
              $postData['approve'] = 1;
            }
          if($postData['approve']==0) {
            $postData['status'] = 0;
            $this->db->query("UPDATE ".DB_PREFIX."category SET status = 0 WHERE category_id = '".(int)$category_id."'");
          }
        $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_details WHERE category_id='".(int)$category_id."'");
        $this->db->query("INSERT INTO " . DB_PREFIX . "wk_hotel_details SET category_id = ".(int)$category_id.",status = '".(int)$postData['status']."', address = '".$this->db->escape($postData['bookingaddress'])."',email = '".$this->db->escape($postData['bookingemail'])."',website = '".$this->db->escape($postData['bookingwebsite'])."', contact = '".$this->db->escape($postData['bookingcontact'])."',faxno = '". $this->db->escape($postData['bookingfaxno'])."',checkin = '".(int)$postData['bookingcheckin']."',checkin_ap='".$this->db->escape($postData['bookingcheckinap'])."',checkout = '".(int)$postData['bookingcheckout']."',checkout_ap = '".$this->db->escape($postData['bookingcheckoutap'])."',latitude = '".(float)$lat."',longitude = '".(float)$long."',owner = '".(int)$hotel_owner."', approve = '".(int)$postData['approve']."'");
          if($postData['status']==0) {
            $rooms = $this->db->query("SELECT p.product_id FROM ".DB_PREFIX."product p LEFT JOIN ".DB_PREFIX."product_to_category pc ON(pc.product_id=p.product_id)WHERE pc.category_id = '".(int)$category_id."'");
            if($rooms) {
              foreach ($rooms as $key => $value) {
                if(isset($value['product_id'])) {
                  $this->db->query("UPDATE ".DB_PREFIX."product SET status = 0 WHERE product_id = '".(int)$value['product_id']."'");
                  $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_room SET status = 0 WHERE product_id = '".(int)$value['product_id']."'");
                }
              }
            }

        }
    }
    /**
     * [getHotelDetails return details of particular hotel]
     * @param  [int] $category_id [category id of hotel]
     * @return [array]              [information about particular hotel]
     */
    public function getHotelDetails($category_id) {
       $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_details WHERE category_id ='".(int)$category_id."'")->row;
       return $result;
    }
    /**
     * [deleteHotel delete particular hotel]
     * @param  [int] $category_id [category id of hotel(category)]
     */
    public function deleteHotel($category_id) {
      $this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_details WHERE category_id ='".(int)$category_id."'");
    }
    /**
     * [getTotalRooms all rooms of hotel with id = hotel_id]
     * @param  [int] $hotel_id [hotel id of hotel]
     * @return [int]           [number of total room in particular hotel]
     */
    public function getTotalRooms($hotel_id) {
      $total = $this->db->query("SELECT COUNT(*) AS total FROM ".DB_PREFIX."wk_hotel_room WHERE hotel_id='".(int)$hotel_id."'")->row;
      return $total['total'];
    }

//Reviews
/**
 * [editReview update the existing review]
 * @param  [int] $review_id [review id ]
 * @param  [array] $data      [details of review]
 */
  public function editReview($review_id, $data) {
    $this->db->query("UPDATE " . DB_PREFIX . "wk_hotel_reviews SET customer_name = '" . $this->db->escape($data['author']) . "', response = '" . $this->db->escape(strip_tags($data['text'])) . "', rating = '" . (int)$data['rating'] . "', status = '" . (int)$data['status'] . "', date = NOW() WHERE id = '" . (int)$review_id . "'");
  }
/**
 * [deleteReview delete particular review by review id]
 * @param  [int] $review_id [review id which is to be delete]
 */
  public function deleteReview($review_id) {
    $this->db->query("DELETE FROM " . DB_PREFIX . "wk_hotel_reviews WHERE id = '" . (int)$review_id . "'");

  }
/**
 * [getReview information about particular review]
 * @param  [int] $review_id [review id of review]
 * @return [array]            [details of review in array]
 */
  public function getReview($review_id) {
    $query = $this->db->query("SELECT * FROM ".DB_PREFIX. "wk_hotel_reviews r WHERE r.id = '" . (int)$review_id . "'");

    return $query->row;
  }
/**
 * [getReviews array of all reviews]
 * @param  array  $data [filter values]
 * @return [array]       [details of all reviews]
 */
  public function getReviews($data = array()) {

    $sql = "SELECT r.*,cd.name FROM " . DB_PREFIX . "wk_hotel_reviews r  LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id=r.hotel_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

    if (!empty($data['filter_product'])) {
      $sql .= " AND cd.name LIKE '%" . $this->db->escape($data['filter_product']) . "%'";
    }

    if (!empty($data['filter_author'])) {
      $sql .= " AND r.customer_name LIKE '%" . $this->db->escape($data['filter_author']) . "%'";
    }

    if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
      $sql .= " AND r.status = '" . (int)$data['filter_status'] . "'";
    }

    if (!empty($data['filter_date_added'])) {
      $sql .= " AND DATE(r.date) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
    }

    $sort_data = array(
      'cd.name',
      'r.customer_name',
      'r.rating',
      'r.status',
      'r.date'
    );

    if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
      $sql .= " ORDER BY " . $data['sort'];
    } else {
      $sql .= " ORDER BY r.date";
    }

    if (isset($data['order']) && ($data['order'] == 'DESC')) {
      $sql .= " DESC";
    } else {
      $sql .= " ASC";
    }

    if (isset($data['start']) || isset($data['limit'])) {
      if ($data['start'] < 0) {
        $data['start'] = 0;
      }

      if ($data['limit'] < 1) {
        $data['limit'] = 20;
      }

      $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
    }

    $query = $this->db->query($sql);
    return $query->rows;
  }
/**
 * [getTotalReviews number of allreview]
 * @param  array  $data [filter values]
 * @return [int]       [number of all reviewws according to the filter value]
 */
  public function getTotalReviews($data = array()) {
    $sql = "SELECT COUNT(*) AS total FROM " . DB_PREFIX . "wk_hotel_reviews r LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id=r.hotel_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

    if (!empty($data['filter_product'])) {
      $sql .= " AND cd.name LIKE '%" . $this->db->escape($data['filter_product']) . "%'";
    }

    if (!empty($data['filter_author'])) {
      $sql .= " AND r.customer_name LIKE '%" . $this->db->escape($data['filter_author']) . "%'";
    }

    if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
      $sql .= " AND r.status = '" . (int)$data['filter_status'] . "'";
    }

    if (!empty($data['filter_date_added'])) {
      $sql .= " AND DATE(r.date) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
    }

    $query = $this->db->query($sql);

    return $query->row['total'];
  }
  /**
   * [updateBooking update slots when booking from back end]
   * @param  [int] $pid      [product_id of room]
   * @param  [int] $order_id [order_id]
   * @param  [date] $from     [booking from date]
   * @param  [date] $till     [booking till date]
   * @param  [int] $quantity [quantity of room]
   * @param  [array] $ementies [extra ementies]
   */
  public function updateBooking($pid,$order_id,$from,$till,$quantity,$name='',$email='',$telephone='',$ementies){
    if ($this->customer->isLogged()) {
      if(!$name)
      $name=$this->customer->getFirstName().' '.$this->customer->getLastName();
      if(!$email)
      $email=$this->customer->getEmail();
    if(!$telephone)
      $telephone=$this->customer->getTelephone();
    } else {
      if(!$name)
      $name = $this->session->data['guest']['firstname'].' '.$this->session->data['guest']['lastname'];
      if(!$email)
      $email = $this->session->data['guest']['email'];
    if(!$telephone)
      $telephone = $this->session->data['guest']['telephone'];
    }
    $this->db->query("INSERT INTO " . DB_PREFIX . "wk_booking_slots VALUES('',".(int)$pid.",'".(int)$order_id."','".$this->db->escape($from)."','".$this->db->escape($till)."',".(int)$quantity.",'".$this->db->escape($name)."','".$this->db->escape($email)."','".$this->db->escape($telephone)."','".$ementies."',1)");
}
/**
 * [getBookedSlots return booked slots of particular room on the basis from start and last date]
 * @param  [int] $product_id [product_id of room]
 * @param  [date] $start_date [booking from date]
 * @param  [date] $last_Date  [booking till date by customer/admin]
 * @return [array]             [all slots between from and till date]
 */
public function getBookedSlots($product_id,$start_date,$last_Date){
$bookedSlots= $this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots WHERE product_id= ".(int)$product_id." AND NOT(( DATE(start_day) < '".$last_Date."' AND DATE(end_day) < '".$start_date."') OR (DATE(start_day) > '".$last_Date."'AND DATE(end_day) > '".$start_date."'))")->rows;
return $bookedSlots;
}
/**
 * [viewtotalentry return number of  all bookable poroduct(room)]
 * @param  [array] $filterValue [filter parameters]
 * @return [array]              [number of all rooms]
 */
public function viewtotalentry($filterValue){

    $sql = "SELECT br.product_id,pd.name,br.start_from,br.till,br.status  FROM " . DB_PREFIX . "wk_hotel_room br LEFT JOIN " . DB_PREFIX . "product_description pd ON(pd.product_id = br.product_id) WHERE pd.language_id = '" . $this->config->get('config_language_id') . "' ";

    if(!empty($filterValue['name'])) {
          $sql .= " AND pd.name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if(!empty($filterValue['from'])) {
          $sql .= " AND br.start_from = '".$this->db->escape($filterValue['from'])."' ";
        }
        if(!empty($filterValue['to'])) {
          $sql .= " AND br.till = '".$this->db->escape($filterValue['to'])."' ";
        }
        if(!empty($filterValue['status']) || (isset($filterValue['status']) && $filterValue['status']==0)) {
          $sql .= " AND br.status = '".(int)$filterValue['status']."' ";
        }
    $result=$this->db->query($sql);

    return count($result->rows);


  }
  /**
 * [viewtotalentry return   all bookable poroduct(room)]
 * @param  [array] $filterValue [filter parameters]
 * @return [array]              [ all rooms]
 */
    public function viewtotal($filterValue){

    $sql ="SELECT br.product_id,pd.name,br.start_from,br.till,br.status  FROM " . DB_PREFIX . "wk_hotel_room br LEFT JOIN " . DB_PREFIX . "product_description pd ON(pd.product_id = br.product_id) WHERE pd.language_id = '" . $this->config->get('config_language_id') . "' ";

    if(!empty($filterValue['name'])) {
      $sql .= " AND pd.name like '%".$this->db->escape($filterValue['name'])."%' ";
    }

    if(!empty($filterValue['from'])) {
      $sql .= " AND br.start_from = '".$this->db->escape($filterValue['from'])."' ";
    }

    if(!empty($filterValue['to'])) {
      $sql .= " AND br.till = '".$this->db->escape($filterValue['to'])."' ";
    }

    if(!empty($filterValue['status']) || (isset($filterValue['status']) && $filterValue['status']==0)) {
      $sql .= " AND br.status = '".(int)$filterValue['status']."' ";
    }
    if(!empty($filterValue['order'])) {
      if($filterValue['order'] == 'name')
        $sql .= " ORDER BY pd.name ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
      else
        $sql .= " ORDER BY br.".$this->db->escape($filterValue['order'])." ".$this->db->escape($filterValue['sort'])." LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
    }else{
      $sql .= " ORDER BY br.start_from DESC LIMIT ".(int)$filterValue['start'].",".(int)$filterValue['end'];
    }

    $result=$this->db->query($sql);

    return $result->rows;
  }
  /**
   * [viewtotalbookings return all bookings of a particular room]
   * @param  [type] $id          [room_id of room]
   * @param  array  $filterValue [filter parameters]
   * @return [array]              [array of booking slots]
   */
  public function viewtotalbookings($id,$filterValue=array()){

    $sql="SELECT * FROM ".DB_PREFIX."wk_booking_slots ws WHERE product_id = ".(int)$id."";
    if(!empty($filterValue['name'])) {
          $sql .= " AND ws.customer_name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if(!empty($filterValue['from'])) {
          $sql .= " AND ws.start_day = '".$this->db->escape($filterValue['from'])."' ";
        }
        if(!empty($filterValue['to'])) {
          $sql .= " AND ws.end_day = '".$this->db->escape($filterValue['to'])."' ";
        }
        if(!empty($filterValue['email'])) {
          $sql .= " AND ws.customer_email = '".$this->db->escape($filterValue['email'])."' ";
        }
        if(!empty($filterValue['telephone'])) {
          $sql .= " AND ws.customer_telephone = '".$this->db->escape($filterValue['telephone'])."' ";
        }
        if (isset($filterValue['start']) || isset($filterValue['limit'])) {
          if ($filterValue['start'] < 0) {
            $filterValue['start'] = 0;
          }

          if ($filterValue['limit'] < 1) {
            $filterValue['limit'] = 20;
          }

          $sql .= " LIMIT " . (int)$filterValue['start'] . "," . (int)$filterValue['limit'];
        }

      $results = $this->db->query($sql);
      return $results->rows;
  }
  public function viewtotalbookingsCount($id,$filterValue=array()){

    $sql="SELECT * FROM ".DB_PREFIX."wk_booking_slots ws WHERE product_id = ".(int)$id."";
    if(!empty($filterValue['name'])) {
          $sql .= " AND ws.customer_name like '%".$this->db->escape($filterValue['name'])."%' ";
        }
        if(!empty($filterValue['from'])) {
          $sql .= " AND ws.start_day = '".$this->db->escape($filterValue['from'])."' ";
        }
        if(!empty($filterValue['to'])) {
          $sql .= " AND ws.end_day = '".$this->db->escape($filterValue['to'])."' ";
        }
        if(!empty($filterValue['email'])) {
          $sql .= " AND ws.customer_email = '".$this->db->escape($filterValue['email'])."' ";
        }
        if(!empty($filterValue['telephone'])) {
          $sql .= " AND ws.customer_telephone = '".$this->db->escape($filterValue['telephone'])."' ";
        }
    $results = $this->db->query($sql);
    return count($results->rows);
  }
  /**
   * [exportHistory description]
   * @param  [int] $product_id [product_id of room]
   * @param  [date] $from       [booking from date]
   * @param  [date] $to         [booking till date]
   * @return [type]             [array of slots during export between from and till date]
   */
  public function exportHistory($product_id,$from,$to){

    $results=$this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots WHERE product_id = ".(int)$product_id." AND start_day >= '".$from."'  AND end_day <= '".$to."'")->rows;
    return $results;
  }
    public function cancelBooking($order_id) {
    $this->db->query("UPDATE ".DB_PREFIX."wk_booking_slots SET status = 0 WHERE order_id = '".(int)$order_id."'");
    $this->db->query("UPDATE ".DB_PREFIX."order SET order_status_id = 7 WHERE order_id = '".(int)$order_id."'");
  }

  public function approveHotels($hotel_id){
     $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_details SET status = 1, approve = 1 WHERE category_id = '".(int)$hotel_id."'");
     $this->db->query("UPDATE ".DB_PREFIX."category SET status = 1 WHERE category_id = '".(int)$hotel_id."'");
  }
   public function approveRoom($room_id){
     $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_room SET status = 1 , approve = 1 WHERE product_id = '".(int)$room_id."'");
     $this->db->query("UPDATE ".DB_PREFIX."product SET status = 1 WHERE product_id = '".(int)$room_id."'");

    $mail_id = $this->config->get('module_wk_hotelbooking_res_mail_product_approve');

    //get product details
    $this->load->model('catalog/product');
    $data = $this->model_catalog_product->getProduct($room_id);

    //add seller id with product data
    $data['customer_id'] = $this->getSellerbasedonProduct($room_id);
    $data['product_id'] = $room_id;

    if(!$data['customer_id'])
      return;

    $this->load->model('customerpartner/mail');
      $this->model_customerpartner_mail->mail($data,'seller_product_approve');
  }


  public function approveFixed($facility_ocid){
     $this->db->query("UPDATE ".DB_PREFIX."wk_hotel_facility SET status = 1 WHERE facility_ocid = '".(int)$facility_ocid."'");
  }



  public function getSellerbasedonProduct($product_id) {
    $result = $this->db->query("SELECT customer_id FROM ".DB_PREFIX."customerpartner_to_product WHERE product_id = '".(int)$product_id."' ORDER BY id ASC LIMIT 1")->row;
    if($result)
      return $result['customer_id'];
    else
      return false;
  }

}
 ?>
