<?php
// Heading Goes here:
$_['heading_title']      	  	    = 'Marketplace Hotel Booking And Reservation ';
$_['heading_title_edit']      	  = 'Edit Marketplace Hotel Booking And Reservation module';

// Text
$_['text_module']     	 	  	    = 'Modules';
$_['text_success']    	 	  	    = 'Success: You have modified module Marketplace Hotel Booking And Reservation !';
$_['ur_timezone']  	 		  	      = 'Please Select Your TimeZone :';

$_['text_enabled']  	 		        = 'Enable';
$_['text_disabled']  	 		        = 'Disable';
$_['entry_status']				        = 'Status';
$_['text_hbr']					          = 'Marketplace Hotel Booking And Reservation';
$_['text_cat_mod_con']		  	    = 'Catalog Module Configuration';
$_['text_allowed_acc_menu']		    = 'Allowed Hotel Menu';
$_['text_allowed_acc_seq']		    = 'Hotel Menu Sequence';
$_['text_extension']              = 'Extension';
$_['text_allowed_acc_menu_info']  = 'Select those options which you want to show for hosts';
$_['text_allowed_acc_seq_info']	  = 'Toggle account menu sequence according to the need';

$_['text_allowed_acc_menu_info']  = 'Select those option which you want to show for hosts';
$_['text_allowed_acc_seq_info']	  = 'Toggle account menu sequence according to the need';


$_['entry_partnerapprov']   			= 'Approve host Automatic  ';
$_['entry_partnerapprovinfo']   	= 'Using this option, you don\'t have to approve Hosts manually, customers will become Hosts automatically when customers apply for become a host.';


$_['text_partner']				        = "Hosts";
$_['text_commission']			        = "Commisson";
$_['menu_arr']					          = array(
                        									'text_cp_partnerlist' => 'Hosts',
                        									'text_cp_income' => 'Income',
                        									'text_cp_transaction' => 'Transaction',
                        									'text_cp_review' => 'Host Reviews',
                        									'text_hp_review' => 'Hotel Reviews',
                        									'text_wk_hotelbooking_res' => 'All Bookings',
                        									'text_wk_hotelbooking_booking' => 'Book Rooms',
                        									'text_wk_hotelbooking_review' => 'Hotel Reviews',
                        									'text_wk_hotelbooking_opfacility' => 'Optional Facilities',
                        									'text_wk_hotelbooking_facility' => 'Fixed Facilities',
                        									'text_wk_hotelbooking_room' => 'Rooms',
                        									'text_wk_hotelbooking_hotel' => 'Hotels',
                        									'text_partner_related' => "Hotel Hosts",
                        									'text_hotels'		=> 'Hotels',
                        									'text_mails'		=> 'Mails',
                        									'text_cp_query'     => 'Queries'
                        									);
$_['hotel_arr'] 				           = array(
                        									'text_hotels'=>'wk_hotelbooking_hotel',
                        									'text_wk_hotelbooking_room'=>'wk_hotelbooking_room',
                        									'text_wk_hotelbooking_facility'=>'wk_hotelbooking_facility',
                        									'text_wk_hotelbooking_opfacility'=>'wk_hotelbooking_opfacility',
                        									'text_hp_review'=>'wk_hotelbooking_review',
                        									'text_wk_hotelbooking_booking'=>'wk_hotelbooking_booking',
                        									'text_wk_hotelbooking_res'=>'wk_hotelbooking_res'
                        									);
$_['mp_arr'] 				              = array(
                        									'cp_partnerlist' => 'partner',
                        									'cp_income' => 'income',
                        									'cp_transaction'=>'transaction',
                        									'mails' => 'mails',
                        									'cp_review' => 'review',
                        									'cp_query' => 'query'
                									        );
// Error
$_['error_permission']  	  	    = 'Warning: You do not have permission to modify module Marketplace Hotel Booking And Reservation ';
//MP
$_['entry_mod_mphbr']			        = 'Marketplace Hotel Booking and Reservation';
$_['tab_general']				          = 'General';
$_['tab_images']                  = 'Images';


$_['entry_header_image']          = 'Header Image';
$_['entry_host_central_image']    = 'Host Central page image';
$_['entry_hotelapprov']		        = 'Approve Hotel Automatic';
$_['entry_hotelapprovinfo']		    = 'Using this option, you don\'t have to approve Hotels manually, Hotels will become live automatically when host will add the hotel.';


$_['text_google_key']             = 'Google key for search';
$_['help_key_info']               = 'You can generate Maps Api Key From <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">here</a>';
$_['text_google_key']             = 'Enter Google Key';
$_['entry_roomapprov']			      = 'Approve Rooms Automatic';
$_['entry_roomapprovinfo']		    = 'Using this option, you don\'t have to approve rooms manually, Rooms will become live automatically when host will add the room.';

$_['entry_enableFxFacility']	    = "Fixed Facility Access";
$_['entry_enableFxFacility_info'] = "If enabled then host can use the Fixed facilities of admin in adding the room";

$_['entry_enableOpFacility']	    = "Optional Facility Access";
$_['entry_enableOpFacility_info'] = "If enabled then host can use the Optional facilities of admin in adding the room";

$_['entry_fixedamentiyapprove']   = 'Approve Fixed Amenity Automatic';
$_['entry_opamentiyapprove']      = 'Approve Optional Amenity Automatic';
$_['entry_selectall']			        = 'Select All';
$_['entry_deselectall']			      = 'Deselect All';

$_['entry_mod_profile']			      = 'Profile';
$_['entry_mod_dashboard']		      = 'Dashboard';
$_['entry_mod_order']			        = 'Orders';
$_['entry_mod_transaction']		    = 'Transaction';
$_['entry_mod_asktoadmin']		    = 'Ask to admin';
$_['entry_mod_add_hotel']		      = 'Hotels';
$_['entry_mod_add_room']		      = 'Rooms';
$_['entry_mod_add_fxfacility']	  = 'Fixed Facility';
$_['entry_mod_add_opfacility']	  = 'Optional Facility';
$_['entry_mod_hotel_review']	    = 'Hotel Review';
$_['entry_mod_allbookings']		    = 'All Bookings';


$_['disapprove_hotel_edit']		    = 'Disapprove Hotel on edit';
$_['disapprove_room_edit']		    = 'Disapprove Rooms on edit';;
$_['disapprove_facility_edit']    = 'Disapprove Fixed Facility on edit';
$_['disapprove_facility_edit_info'] = 'The Facility will be disabled if host edit the approved hotels and it will be enabled after the admin approves the modifications';

$_['disapprove_hotel_edit_info']  = 'The Hotel will be disabled if host edit the approved hotels and it will be enabled after the admin approves the modifications';
$_['disapprove_room_edit_info']   = 'The  Room will be disabled if host edit the approved hotels and it will be enabled after the admin approves the modifications';
$_['disapprove_fx_edit_info'] 	  = 'Fixed facility will be disabled if host edit and will be live again if admin approves modifications';

$_['text_limit']			            = 'Host Configuration';

$_['text_no_ofhotel']			        = 'Number of Hotel';
$_['text_no_ofrooms']			        = 'Number of rooms';
$_['text_no_fxfacility']		      = 'Number of Fixed Facility';
$_['text_no_opFacility']		      = 'Number of Optional Facility';
$_['text_limit_tab_info']		      = 'For unlimited quantity leave the following fields blank';

$_['text_info_profile'] 	 			  = 'Under this tab you can globally enable/disable Hosts Profile details, which will visible to customer .';

$_['entry_alowed_profile_columnsinfo']  = 'Select Profile fields for host to add/edit any his/her profile and only allowed fields will display to customer. ';
$_['entry_alowed_profile_columns']  	  = 'Allowed Profile Fields ';
$_['entry_alowed_profile_columnsinfo']  = 'Select Profile fields for host to add/edit any his/her profile and only allowed fields will display to customer. ';
$_['entry_alowed_profile_columns']  	  = 'Allowed Profile Fields ';
$_['entry_store_tab']  				    = 'About Store Tab';
$_['entry_collection_tab']  			= 'Hotels Tab';
$_['entry_review_tab']  				  = 'Review Tab';
$_['entry_product_review_tab']  	= 'Hotel Review Tab';
$_['entry_location_tab']  				= 'Location Tab';
$_['entry_seller_email']				  = 'Customer can see hosts\'s Email ID';
$_['entry_seller_telephone']			= 'Customer can see hosts\'s Telephone number';
$_['tab_profile']    					    = 'Profile Settings';
$_['wkentry_add_tab']					    = 'Add Tab';

$_['tab_sell']							      = 'Hosts Details';
$_['text_tab_title']	  	 			  = 'Enter Tab Title:';
$_['wkentry_selld']    		 			  = 'Sell Description';
$_['entry_seller_email']				  = 'Customer can see hosts\'s Email ID';
$_['entry_seller_telephone']			= 'Customer can see hosts\'s Telephone number';

$_['entry_commission_worked']  		= 'Commission Works on All Category ';
$_['entry_commission_workedinfo'] = 'If this checkbox is checked then commission will be sum of all catagory commission related to particular product.';

$_['tab_commission']  					  = 'Commission';
$_['entry_commission']    				= 'Percentage';
$_['entry_commission_default']    		= 'Fixed';
$_['entry_commission_mixed']			= 'Mixed';

$_['entry_cat_commission']  			= 'Category Commission';

$_['entry_priority_commission']  	= 'Select Commission Priority ';
$_['entry_priority_commissioninfo']  	= 'You can select commission priority. This will determine in what priority each commission will work.';

$_['entry_commission_add']  			= 'Category Commission Based on ';
$_['entry_commission_addinfo']  	= 'Select Categories for Category Commission.';
$_['entry_fixed']  						    = 'Fixed';
$_['entry_category']  					  = 'Category';
$_['entry_category_child']  			= 'Category Child';

$_['text_info_mail']	 	 			    = 'Under this tab you can set Mail for different conditions which will occur in Marketplace Hotel Booking System.';

$_['entry_mail_keywords']  				= 'Mail Keywords';
$_['entry_mail_product_approve']  = 'Please enter keyword that you want to enter in mail ending with comma(,)';
$_['entry_mail_product_approve_info']   = 'Select mail, which will send to host after admin approves the host room.';
$_['entry_mail_partner_request']        = 'Request for Hostship';
$_['entry_mail_partner_request_info']  	= 'Select mail, which will send to customer after customer apply for Hostship.';
$_['entry_mail_partner_admin']  	    = 'Mail to Admin after Customer Request';
$_['entry_mail_partner_admin_info']   = 'Select mail, which will send to admin after customer apply for Hostship.';
$_['entry_mail_product_request']  		= 'Room add';
$_['entry_mail_product_request_info'] = 'Select Mail, which will send to host';
$_['entry_mail_product_admin']  		  = 'Mail to Admin after Room Add';
$_['entry_mail_product_admin_info']   = 'Select mail, which will send to admin after host add room.';
$_['entry_mail_transaction']  			  = 'Transaction Add';
$_['entry_mail_transaction_info']  		= 'Select Mail, which will send to host after transaction will add.';
$_['entry_mail_order']  				      = 'Order Mail';
$_['entry_mail_order_info']  			    = 'Select Mail, which will send to host after customer will buy his products with order details.';
$_['entry_mail_cutomer_to_seller']  	= 'Customer Contact host Mail';
$_['entry_mail_cutomer_to_seller_info'] = 'Select Mail, which will send to host when customer contact to the host.';
$_['entry_mail_seller_to_admin']  		= 'Host Contact Admin Mail';
$_['entry_mail_seller_to_admin_info'] = 'Select Mail, which will send to admin When customer contact to the host.';
$_['entry_mail_edit_product_seller']  = 'Edit room mail to hosts';
$_['entry_mail_edit_product_sellerinfo']  	= 'Mail will be sent to host when host will edit any room and \'disapprove on edit\' is enabled';
$_['entry_mail_edit_product_admin']  	= 'Edit room mail to admin';
$_['entry_mail_edit_product_admininfo'] = 'Mail will be sent to admin when host will edit any room and \'disapprove on edit\' is enabled';
$_['entry_mail_partner_approve']  		= 'Mail After Approve host (Manually)';
$_['entry_mail_partner_approve_info'] = 'Select mail, which will send to host after admin approves his Hostship manually.';
$_['entry_mail_product_approve']  		= 'Mail After Approve Room (Manually)';

$_['tab_general']    					        = 'General';
$_['wkentry_sellh']      	 			      = 'Sell Header:';
$_['wkentry_mailtoseller']   			    = 'Mail to Host :';
$_['wkentry_sellb']     	 			      = 'Sell Button Title:';
$_['wkentry_selld']    		 			      = 'Sell Description';
$_['tab_tab']    						          = 'Hotel Policies Tabs';
$_['entry_text']     	  	 			      = 'Add Text';
$_['text_tab_title']	  	 			      = 'Enter Tab Title:';
$_['entry_sellinfo']    				      = 'Using these options you can manage your Host details Page. You can display Policies Rules and Terms and Conditons for hosts in the form of tabs.';
$_['entry_commission_info']  			    = 'You can add fixed and percentage commission on each host.';

$_['entry_fixed']					            = 'Fixed';
$_['entry_percentage']					      = 'Percentage';
$_['entry_both']						          = 'Mixed';
$_['entry_customer_contact_seller']  	= 'Customer can contact Hosts ';
$_['entry_customer_contact_sellerinfo']     = 'This option will display contact option to customer.';
$_['entry_customer_contact_seller_admin']  	= 'Admin notify ';
$_['entry_customer_contact_selleradmininfo']= 'This option will notify admin through mail when customer contacts host';

$_['entry_seller_delete_review']			= 'Host can delete hotel reviews';

$_['entry_seller_edit_review']				= 'Host can edit hotel reviews';

$_['entry_seller_modify_query']				= 'Host can respond on query';

$_['entry_mod_query']					        = 'Queries';

$_['entry_canecl_booking']				    = 'Cancel Booking';
$_['entry_cancel_info']					      = 'If this option is enabled then host can cancel the booking';
$_['entry_dele_seller']               = 'After delete the host';
$_['entry_dele_seller_info']          = 'Select the action from host room and his hotels etc. after delete or disapprove the host ';
$_['text_delete_room']                = 'Delete all';
$_['text_assign_admin']               = 'Assign Admin';
$_['text_range']                      = 'Hotel Display Range';
$_['text_range_info']                 = 'The hotels with in the specified range will be show during the search. If blank then all hotel will be show';
$_['error_warning']                   = 'Warning: Please check the form carefully for errors';

$_['header_button_error']             = 'Header Title must be greater than 1 and less than 255 characters!';

$_['header_name_error']               = 'Header Name must be greater than 1 and less than 255 characters!';

$_['button_range_error']               = 'Enter the range in valid formate';

?>
