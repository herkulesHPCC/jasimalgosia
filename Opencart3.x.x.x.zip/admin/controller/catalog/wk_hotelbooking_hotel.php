<?php

class ControllerCatalogWkhotelbookinghotel extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/wk_hotelbooking_hotels');
		$this->document->setTitle($this->language->get('hotel_heading_title'));
		$this->getList();
	}
	public function getList() {
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('hotel_heading_title'),
			'href'      => $this->url->link('catalog/wk_hotelbooking_hotel', '&user_token=' . $this->session->data['user_token'] , 'true'),
   		);
   		if(isset($this->request->get['sort'])){
			$data['sort'] = $sort = $this->request->get['sort'];
		}else{
			$sort = null;
		}
		if(isset($this->request->get['name'])){
			$data['name'] = $name = $this->request->get['name'];
		}else{
			$name = null;
		}
		if(isset($this->request->get['status'])){
			$data['status'] = $status = $this->request->get['status'];
		}else{
			$status = null;
		}
		if(isset($this->request->get['address'])){
			$data['address'] = $address = $this->request->get['address'];
		}else{
			$address = null;
		}
		if(isset($this->request->get['website'])){
			$data['website'] = $website = $this->request->get['website'];
		}else{
			$website = null;
		}
		if(isset($this->request->get['order'])){
			$data['order'] = $order = $this->request->get['order'];
		}else{
			$order = null;
		}
		if(isset($this->request->get['type'])){
			$data['type'] = $type = $this->request->get['type'];
		}else{
			$type = null;
		}
		$limit = $this->config->get('config_limit_admin');

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
			$page = 1;
		}
		$filterValues = array(
				'sort'	=> $sort,
				'name'	=> $name,
				'type'	=> $type,
				'order'	=> $order,
				'status'	=> $status,
				'website'	=> $website,
				'address' => $address,
				'start'	=> $start,
				'end'	=> $end,
				);


   		$hotels = $this->model_catalog_wk_hotelbooking_hotels->getHotels($filterValues);
   		$total_hotels = $this->model_catalog_wk_hotelbooking_hotels->getAllHotels($filterValues);
   		$this->load->model('customer/customer');
   		$data['hotels'] =array();
   		$this->load->model('tool/image');
   		if(!empty($hotels)) {
	   		foreach ($hotels as $result) {
				if (is_file(DIR_IMAGE . $result['image'])) {
					$image = $this->model_tool_image->resize($result['image'], 100, 100);
				} else {
					$image = $this->model_tool_image->resize('no_image.png', 100, 100);
				}
				if($result['owner']) {
					$owner_name = $this->model_customer_customer->getCustomer($result['owner']);
					if($owner_name && isset($owner_name['firstname'])) {
						$owner_name = $owner_name['firstname'].' '.$owner_name['lastname'];
						$approve_action = true;
					}
					else {
						$owner_name = 'Admin';
						$approve_action = false;
					}
				}
				else {
					$owner_name = 'Admin';
					$approve_action = false;
				}
				$data['hotels'][] = array(
					'hotel_id' => $result['category_id'],
					'image'      => $image,
					'name'       => $result['name'],
					'website'    => $result['website'],
					'address'	 => $result['address'],
					'status'  	 => $result['status'],
					'owner'		 => $owner_name,
					'approve'    => $approve_action,
					'is_approve' => $result['approve'],
					'edit'       => $this->url->link('catalog/wk_hotelbooking_hotel/edit', 'user_token=' . $this->session->data['user_token'] . '&hotel_id=' . $result['category_id'], true)
				);
			}
		}
		$data['add'] =  $this->url->link('catalog/wk_hotelbooking_hotel/add', 'user_token=' . $this->session->data['user_token'] , true);
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['user_token'] = $this->session->data['user_token'];
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		$pagination = new Pagination();
		$pagination->total = $total_hotels;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('catalog/wk_hotelbooking_hotel', 'user_token=' . $this->session->data['user_token'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($total_hotels) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($total_hotels - $this->config->get('config_limit_admin'))) ? $total_hotels : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $total_hotels, ceil($total_hotels / $this->config->get('config_limit_admin')));

		$data['add']	=	$this->url->link('catalog/wk_hotelbooking_hotel/add', 'user_token='.$this->session->data['user_token'],true);
		$data['delete']	=	$this->url->link('catalog/wk_hotelbooking_hotel/delete', 'user_token='.$this->session->data['user_token'],true);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_hotel_list',$data));
	}
	public function edit() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('hotel_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->load->model('catalog/category');

			$this->request->post['parent_id'] = $this->config->get('wk_hotelbookingcat_categoryid');
			$this->request->post['column']	  = '';
			$this->request->post['sort_order']='';
			$this->request->post['keyword']	= '';
			$this->request->post['category_store'] =array('0'=>0);

			$this->model_catalog_category->editCategory($this->request->get['hotel_id'], $this->request->post);

			$this->model_catalog_wk_hotelbooking_hotels->addHotel($this->request->get['hotel_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_hotel', 'user_token=' . $this->session->data['user_token'], true));
		}
		$this->getForm();
	}

	public function add() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('hotel_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			$this->load->model('catalog/category');

			$this->request->post['parent_id'] = $this->config->get('wk_hotelbookingcat_categoryid');
			$this->request->post['column']	  = '';
			$this->request->post['sort_order']='';
			$this->request->post['category_store'] =array('0'=>0);

			$category_id = $this->model_catalog_category->addCategory($this->request->post);

			$this->model_catalog_wk_hotelbooking_hotels->addHotel($category_id , $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_hotel', 'user_token=' . $this->session->data['user_token'], true));
		}
		$this->getForm();
	}
	public function getForm() {
		$this->load->language('catalog/wk_hotelbooking_hotels');
		$data['text_form'] = !isset($this->request->get['category_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');


		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->error['address_error'])) {
			$data['error_address_error'] = $this->error['address_error'];
		} else {
			$data['error_address_error'] = '';
		}
		if (isset($this->error['email_error'])) {
			$data['error_email_error'] = $this->error['email_error'];
		} else {
			$data['error_email_error'] = '';
		}
		if (isset($this->error['contact_error'])) {
			$data['error_contact_error'] = $this->error['contact_error'];
		} else {
			$data['error_contact_error'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}

		if (isset($this->error['meta_title'])) {
			$data['error_meta_title'] = $this->error['meta_title'];
		} else {
			$data['error_meta_title'] = array();
		}

		if (isset($this->error['keyword'])) {
			$data['error_keyword'] = $this->error['keyword'];
		} else {
			$data['error_keyword'] = '';
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('catalog/wk_hotelbooking_hotel', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		if (!isset($this->request->get['hotel_id'])) {
			$data['action'] = $this->url->link('catalog/wk_hotelbooking_hotel/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('catalog/wk_hotelbooking_hotel/edit', 'user_token=' . $this->session->data['user_token'] . '&hotel_id=' . $this->request->get['hotel_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('catalog/wk_hotelbooking_hotel', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$this->document->addScript('https://maps.googleapis.com/maps/api/js?libraries=places&key='.$this->config->get('module_wk_hotelbooking_res_google_key'));

		$this->load->model('catalog/category');

		if (isset($this->request->get['hotel_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$category_info = $this->model_catalog_category->getCategory($this->request->get['hotel_id']);
		}

		$data['user_token'] = $this->session->data['user_token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->post['category_description'])) {
			$data['category_description'] = $this->request->post['category_description'];
		} elseif (isset($this->request->get['hotel_id'])) {
			$data['category_description'] = $this->model_catalog_category->getCategoryDescriptions($this->request->get['hotel_id']);
		} else {
			$data['category_description'] = array();
		}

		$data['parent_id'] = 0;

		$this->load->model('catalog/filter');

		$this->load->model('setting/store');


		$this->load->model('tool/image');

		if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
			$data['image'] = $this->request->post['image'];
		} elseif (!empty($category_info) && is_file(DIR_IMAGE . $category_info['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($category_info['image'], 100, 100);
			$data['image'] = $category_info['image'];
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
			$data['image'] = '';
		}

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($category_info)) {
			$data['status'] = $category_info['status'];
		} else {
			$data['status'] = true;
		}

		if(isset($this->request->get['hotel_id'])) {
			$hotel_id = $this->request->get['hotel_id'];
		} else {
			$hotel_id = 0;
		}

		$hotel_info = $this->model_catalog_wk_hotelbooking_hotels->getHotelDetails($hotel_id);
	    if (!empty($hotel_info)) {
				$data['hotel_details'] = array(
	        'bookingstatus'     => (isset($this->request->post) && isset($this->request->post['bookingstatus'])) ? $this->request->post['bookingstatus'] : $hotel_info['status'],
	        'bookingaddress'    => (isset($this->request->post) && isset($this->request->post['bookingaddress'])) ? $this->request->post['bookingaddress'] : $hotel_info['address'],
	        'bookingemail'      => (isset($this->request->post) && isset($this->request->post['bookingemail'])) ? $this->request->post['bookingemail'] : $hotel_info['email'],
	        'bookingwebsite'    => (isset($this->request->post) && isset($this->request->post['bookingwebsite'])) ? $this->request->post['bookingwebsite'] : $hotel_info['website'],
	        'bookingcontact'    => (isset($this->request->post) && isset($this->request->post['bookingcontact'])) ? $this->request->post['bookingcontact'] : $hotel_info['contact'],
	        'bookingfaxno'      => (isset($this->request->post) && isset($this->request->post['bookingfaxno'])) ? $this->request->post['bookingfaxno'] : $hotel_info['faxno'],
	        'bookingcheckin'    => (isset($this->request->post) && isset($this->request->post['bookingcheckin'])) ? $this->request->post['bookingcheckin'] : $hotel_info['checkin'],
	        'bookingcheckout'   => (isset($this->request->post) && isset($this->request->post['bookingcheckout'])) ? $this->request->post['bookingcheckout'] : $hotel_info['checkout'],
	        'bookingcheckoutap' => (isset($this->request->post) && isset($this->request->post['bookingcheckoutap'])) ? $this->request->post['bookingcheckoutap'] : $hotel_info['checkout_ap'],
	        'bookingcheckinap'  => (isset($this->request->post) && isset($this->request->post['bookingcheckinap'])) ? $this->request->post['bookingcheckinap'] : $hotel_info['checkin_ap'],
	        );
	    } else {
	      $data['hotel_details'] = array(
	        'bookingstatus'  => isset($this->request->post['bookingstatus']) ? $this->request->post['bookingstatus'] : 0,
	        'bookingaddress' =>  isset($this->request->post['bookingaddress']) ? $this->request->post['bookingaddress'] : '',
	        'bookingemail'   =>  isset($this->request->post['bookingemail']) ? $this->request->post['bookingemail'] : '',
	        'bookingwebsite' =>  isset($this->request->post['bookingwebsite']) ? $this->request->post['bookingwebsite'] : '',
	        'bookingcontact' =>  isset($this->request->post['bookingcontact']) ? $this->request->post['bookingcontact'] : '',
	        'bookingfaxno'   =>  isset($this->request->post['bookingfaxno']) ? $this->request->post['bookingfaxno'] : '',
	        'bookingcheckin' =>  isset($this->request->post['bookingcheckin']) ? $this->request->post['bookingcheckin'] : '',
	        'bookingcheckout'=>  isset($this->request->post['bookingcheckout']) ? $this->request->post['bookingcheckout'] : '',
	        'bookingcheckoutap' => isset($this->request->post['bookingcheckoutap']) ? $this->request->post['bookingcheckoutap'] : 1,
	        'bookingcheckinap'  => isset($this->request->post['bookingcheckinap']) ? $this->request->post['bookingcheckinap'] : 1
	        );
	    }
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_hotel_form', $data));
	}
	public function delete() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/product');
		$this->load->model('catalog/category');
		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {

			foreach ($this->request->post['selected'] as $category_id) {

				$this->model_catalog_product->deleteProduct($category_id);

				$this->model_catalog_wk_hotelbooking_hotels->deleteHotel($category_id);
				$this->model_catalog_category->deleteCategory($category_id);
			}

			$this->session->data['success'] = $this->language->get('text_hotel_delete_success');

			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_hotel', 'user_token=' . $this->session->data['user_token'] , true));
		}

		$this->getList();

	}

	protected function validateForm() {

		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_hotel')) {
			$this->error['warning'] = $this->language->get('category_error_permission');
		}

		foreach ($this->request->post['category_description'] as $language_id => $value) {
			if ((utf8_strlen(trim($value['name'])) < 2) || (utf8_strlen(trim($value['name'])) > 255)) {
				$this->error['name'][$language_id] = $this->language->get('category_error_name');
			}

			if ((utf8_strlen(trim($value['meta_title'])) < 3) || (utf8_strlen(trim($value['meta_title'])) > 255)) {
				$this->error['meta_title'][$language_id] = $this->language->get('category_error_meta_title');
			}
		}
		if(!trim($this->request->post['bookingaddress'])) {
			$this->error['address_error']	 = $this->language->get('address_error');
		}

		if ($this->request->post['bookingemail'] && !filter_var($this->request->post['bookingemail'], FILTER_VALIDATE_EMAIL)) {
			$this->error['email_error']	 = $this->language->get('email_error');
		}
		if ($this->request->post['bookingcontact'] && !preg_match('/^[0-9\/-]+$/', $this->request->post['bookingcontact'])) {
			$this->error['contact_error']	 = $this->language->get('contact_error');
		}
		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('hotel_error_warning');
		}

		return !$this->error;
	}
	protected function validateDelete(){
		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_hotel')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$this->load->model('catalog/wk_hotelbooking_hotels');

		foreach ($this->request->post['selected'] as $hotel_id) {

			$room_total = $this->model_catalog_wk_hotelbooking_hotels->getTotalRooms($hotel_id);

			if ($room_total) {
				$this->error['warning'] = sprintf($this->language->get('error_hotel_delete'), $room_total);
			}
		}

		return !$this->error;
	}
	public function approve(){
		$this->load->language('catalog/wk_hotelbooking_hotels');
			if($this->request->server['REQUEST_METHOD'] == "POST" && $this->request->post['hotel_id']) {
				$json = array();
				$this->load->model('catalog/wk_hotelbooking_hotels');
				$this->model_catalog_wk_hotelbooking_hotels->approveHotels($this->request->post['hotel_id']);
				$json['success'] = $this->language->get("text_aphotel_success");
			}
		if(isset($json) && $json['success']) {
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));

		}
	}
}
