<?php
class ControllerCatalogwkhotelbookingopfacility extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->getForm();
	}

	public function add() {

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/option');
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->load->language('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validateForm())) {
			$this->load->model('localisation/language');

			$data['languages'] = $this->model_localisation_language->getLanguages();

			$sort_order = 1;

			foreach ($data['languages'] as $language) {
				$name[$language['language_id']]['name'] = 'Extra Amenties';
			}
			if(!isset($this->request->post['option_value']))
				$this->request->post['option_value']=array();
			else {
				foreach ($this->request->post['option_value'] as $key => $value) {
					if(!isset($value['owner']))
						$this->request->post['option_value'][$key]['owner'] = 0;
				}
			}
			$option_data = array(
			'type'=>'checkbox',
			'sort_order'=>1,
			'option_description'=>$name,
			'option_value' => $this->request->post['option_value']
			);
			$this->model_catalog_wk_hotelbooking_hotels->deleteOptFacility();
			$this->model_catalog_option->editOption($this->config->get('wk_hotelbookingopt_optionid'),$option_data);

			$this->session->data['success'] = $this->language->get('text_opt_success');

			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_opfacility', 'user_token=' . $this->session->data['user_token'] , true));
		}

		$this->getForm();
	}
	protected function getForm() {
		$this->document->setTitle($this->language->get('opfacility_heading_title'));

		$this->load->model('catalog/option');
		if (isset($this->request->post['option_value'])) {
			$option_values = $this->request->post['option_value'];
		} elseif ($this->config->get('wk_hotelbookingopt_optionid')) {
			$option_values = $this->model_catalog_option->getOptionValueDescriptions($this->config->get('wk_hotelbookingopt_optionid'));
		} else {
			$option_values = array();
		}

		if (isset($this->error['option_value'])) {
			$data['error_option_value'] = $this->error['option_value'];
		} else {
			$data['error_option_value'] = array();
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('opfacility_heading_title'),
			'href' => $this->url->link('catalog/wk_hotelbooking_opfacility', 'user_token=' . $this->session->data['user_token'], true)
		);
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
	  	$data['action'] = $this->url->link('catalog/wk_hotelbooking_opfacility/add', 'user_token=' . $this->session->data['user_token'], true);

		$this->load->model('tool/image');

		$data['option_values'] = array();

		foreach ($option_values as $option_value) {
			$owner = $this->db->query("SELECT owner,facility_image,status FROM ".DB_PREFIX."wk_hotel_facility WHERE facility_ocid = '".$option_value['option_value_id']."'")->row;
			if($owner && isset($owner['owner']) && $owner['owner']) {
				$option_value['image'] = $owner['facility_image'];
				$status = $owner['status'];
				$owner = $owner['owner'];

			} else {
				$owner = 0;
				$status = 1;
			}
			if (is_file(DIR_IMAGE. $option_value['image'])) {
				$image = $option_value['image'];
				$thumb = $this->model_tool_image->resize($option_value['image'], 40, 40);
			}else {
				$image = '';
				$thumb =  $this->model_tool_image->resize('no_image.png',40,40);
			}

			$data['option_values'][] = array(
				'option_value_id'          => $option_value['option_value_id'],
				'option_value_description' => $option_value['option_value_description'],
				'image'                    => $image,
				'thumb'                    => $thumb,
				'sort_order'               => $option_value['sort_order'],
				'status'				   => $status,
				'owner'					   => $owner
			);
		}
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 40, 40);


		$data['user_token'] = $this->session->data['user_token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_opfacility', $data));
	}
	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_opfacility')) {
			$this->error['warning'] = $this->language->get('option_error_permission');
		}

		if (isset($this->request->post['option_value']) && $this->request->post['option_value']) {
			foreach ($this->request->post['option_value'] as $option_value_id => $option_value) {
				foreach ($option_value['option_value_description'] as $language_id => $option_value_description) {
					if ((utf8_strlen(trim($option_value_description['name'])) < 1) || (utf8_strlen(trim($option_value_description['name'])) > 128)) {
						$this->error['option_value'][$option_value_id][$language_id] = $this->language->get('error_option_value');
						$this->error['warning'] = $this->language->get('option_error_warning');
					}
				}
			}
		}
		return !$this->error;
	}
}
