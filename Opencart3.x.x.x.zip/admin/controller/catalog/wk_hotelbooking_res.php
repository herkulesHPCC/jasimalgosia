<?php
class ControllerCatalogwkhotelbookingres extends Controller {

	private $error = array();

	public function index() {
		$this->language->load('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('booking_information'));

		$this->load->model('catalog/wk_hotelbooking_hotels');


		$this->getList();
  	}


	protected function getList() {
		$this->language->load('catalog/wk_hotelbooking_hotels');


		$data['user_token'] = $this->session->data["user_token"];


  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('booking_information'),
			'href'      => $this->url->link('catalog/wk_hotelbooking_res', '&user_token=' . $this->session->data['user_token'] , 'true'),
      		'separator' => ' :: '
   		);

		$data['update'] = $this->url->link('catalog/wk_hotelbooking_res/delete', '&user_token=' . $this->session->data['user_token'] , 'true');

		$data['questionarray'] = array();


		$questionarray = array();

		$limit = $this->config->get('config_limit_admin');

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
		}

		if(isset($this->request->get['sort'])){
			$data['sort'] = $sort = $this->request->get['sort'];
		}else{
			$sort = null;
		}

		if(isset($this->request->get['order'])){
			$data['order'] = $order = $this->request->get['order'];
		}else{
			$order = null;
		}

		if(isset($this->request->get['name'])){
			$data['name'] = $name = $this->request->get['name'];
		}else{
			$name = null;
		}

		if(isset($this->request->get['from'])){
			$data['from'] = $from = $this->request->get['from'];
		}else{
			$from = null;
		}

		if(isset($this->request->get['to'])){
			$data['to'] = $to = $this->request->get['to'];
		}else{
			$to = null;
		}

		if(isset($this->request->get['timespan'])){
			$data['timespan'] = $timespan = $this->request->get['timespan'];
		}else{
			$timespan = null;
		}

		if(isset($this->request->get['interval'])){
			$data['interval'] = $interval = $this->request->get['interval'];
		}else{
			$interval = null;
		}

		if(isset($this->request->get['status'])){
			$data['status'] = $status = $this->request->get['status'];
		}else{
			$status = null;
		}

		$filterValues = array(
				'sort'	=> $sort,
				'order'	=> $order,
				'name'	=> $name,
				'from'	=> $from,
				'to'	=> $to,
				'timespan'	=> $timespan,
				'interval'	=> $interval,
				'status'	=> $status,
				'start'	=> $start,
				'end'	=> $end,
			);

			$data['sub_heading_title'] = $this->language->get('heading_title_products');
			$product_total = $this->model_catalog_wk_hotelbooking_hotels->viewtotalentry($filterValues);

			$results = $this->model_catalog_wk_hotelbooking_hotels->viewtotal($filterValues);

	        foreach ($results as $result) {
				$status = $this->language->get('text_disabled');
				if($result['status'])
					$status = $this->language->get('text_enabled');
	      		$data['result_book'][] = array(
					'selected'=>False,
					'id' => $result['product_id'],
					'name' => $result['name'],
					'date_from' => $result['start_from'],
					'date_to' => $result['till'],
					'status' => $status,
					'action'     => $this->url->link('catalog/wk_hotelbooking_res_booking','&user_token=' . $this->session->data['user_token'] .'&id=' . $result['product_id'], true),
				);
			}
 		$data['user_token'] = $this->session->data['user_token'];

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['sort_name'] = $this->url->link('catalog/wk_hotelbooking_res', 'user_token=' . $this->session->data['user_token'] , 'true');

		$pagination = new Pagination();
		$pagination->total = $product_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('catalog/wk_hotelbooking_res', 'user_token=' . $this->session->data['user_token'] . '&page={page}', 'true');

		$data['pagination'] = $pagination->render();
		$data['results'] = sprintf($this->language->get('text_pagination'), ($product_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($product_total - $this->config->get('config_limit_admin'))) ? $product_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $product_total, ceil($product_total / $this->config->get('config_limit_admin')));
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_res',$data));
  	}


  	public function delete() {
    	$this->language->load('catalog/wk_hotelbooking_hotels');

    	$this->document->setTitle($this->language->get('booking_information'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			$this->load->model('catalog/product');

			foreach ($this->request->post['selected'] as $id) {
				$this->model_catalog_wk_hotelbooking_hotels->deleteRoom($id);
				$this->model_catalog_product->deleteProduct($product_id);
	  		}

			$this->session->data['success'] = $this->language->get('text_room_delete_success');

			$url='';

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_res', '&user_token=' . $this->session->data['user_token'] . $url, 'true'));
		}

    	$this->getList();
  	}


	private function validateForm() {
		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_res')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}



		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		if (!$this->error) {
				return true;
		} else {
			return false;
		}
		}
	protected function validateDelete() {
    	if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_res')) {
      		$this->error['warning'] = $this->language->get('error_permission');
    	}

		if (!$this->error) {
	  		return true;
		} else {
	  		return false;
		}
  	}
  }
?>
