<?php
class ControllerExtensionModuleLayerNavigation extends Controller {
	/**
	 * [$error description]
	 * @var array contain the error message and warning
	 */
	private $error = array();
	public function install() {

			$this->load->model('localisation/language');
			$this->load->model('catalog/attribute_group');
			$this->load->model('setting/setting');

			$data['languages'] = $this->model_localisation_language->getLanguages();
			foreach ($data['languages'] as $language) {
				$name[$language['language_id']]['name'] = 'price';
			}
			$attribute_group_data = array(
				'sort_order' => 1,
				'attribute_group_description' => $name
			);
			$result = $this->db->query("SELECT * FROM  ".DB_PREFIX."setting WHERE  `code` LIKE  'ad_layer_navigation_attrg' ")->rows;
			if(empty($result)) {
				$ad_layer_navigation_attrg['ad_layer_navigation_attrg'] = $this->model_catalog_attribute_group->addAttributeGroup($attribute_group_data);
				$this->model_setting_setting->editSetting('ad_layer_navigation_attrg', $ad_layer_navigation_attrg);
			}
	}
	public function index() {

		$this->load->language('extension/module/layer_navigation');
		$this->load->model('setting/setting');
		$this->load->model('extension/module/layer_navigation');

		$this->document->setTitle($this->language->get('heading_title'));

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			$this->model_setting_setting->editSetting('module_layer_navigation', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

		$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}


		$config_data = array(
			'module_layer_navigation_status',
			'module_layer_navigation_group_details',
			'module_layer_navigation_price_min',
			'module_layer_navigation_price_max',
			// 'layer_navigation_category_details,'
			);
		//status
		foreach ($config_data as $conf) {
			if (isset($this->request->post[$conf])) {
				$data[$conf] = $this->request->post[$conf];
			} else {
				$data[$conf] = $this->config->get($conf);
			}
		}
		$results = $this->model_extension_module_layer_navigation->getAttributeGroups();

		$data['all_attribute_groups']	=	$results;


		if(isset($this->error['price_range'])){
  			$data['error_price_range']	=	$this->error['price_range'];
  		}else{
  			$data['error_price_range']	=	'';
  		}

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
				'text'      => $this->language->get('text_home'),
		'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
		);

				$data['breadcrumbs'][] = array(
					'text' => $this->language->get('text_extension'),
					'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
				);


		$data['breadcrumbs'][] = array(
				'text'      => $this->language->get('heading_title'),
		'href'      => $this->url->link('extension/module/layer_navigation', 'user_token=' . $this->session->data['user_token'], true),
		);
   		$data['user_token'] = $this->session->data['user_token'];

		$data['action'] = $this->url->link('extension/module/layer_navigation', 'user_token=' . $this->session->data['user_token'], true);
	  $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/layer_navigation', $data));

	}

	private function validate() {

		if (!$this->user->hasPermission('modify', 'extension/module/layer_navigation')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if(isset($this->request->post['module_layer_navigation_group_details']) && in_array($this->request->post['module_layer_navigation_price_min_chk'], $this->request->post['module_layer_navigation_group_details'] )){

			if(isset($this->request->post['module_layer_navigation_price_min']) && isset($this->request->post['module_layer_navigation_price_max']) ){

				$min_price = $this->request->post['module_layer_navigation_price_min'];
				$max_price = $this->request->post['module_layer_navigation_price_max'];

				if(empty($min_price) || empty($max_price)){
						$this->error['price_range'] = $this->language->get('error_price');
				}else if(preg_match("/^[0-9]+(\.[0-9]{2})?$/",$min_price) && preg_match("/^[0-9]+(\.[0-9]{2})?$/",$max_price)){
						if($min_price >= $max_price)
							$this->error['price_range'] = $this->language->get('error_price');
						else
							return true;
				}else{
						$this->error['price_range'] = "Enter valid price";
				}
			}else{

				return true;
			}

		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			$this->load->model('extension/module/layer_navigation');

			$filter_data = array(
				'filter_name' => $this->request->get['filter_name'],
				'sort'        => 'name',
				'order'       => 'ASC',
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_extension_module_layer_navigation->getCategories($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'category_id' => $result['category_id'],
					'name'        => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function getAttributeGroups(){

		$json = array();

			$this->load->model('extension/module/layer_navigation');
			if(isset($this->request->post['group_id']) && !empty($this->request->post['group_id'])){
				$group_id = $this->request->post['group_id'];
				$result = $this->model_extension_module_layer_navigation->getGroup($group_id);

				$json['success'] = array(
					'attribute_group_id'	=>	$result['attribute_group_id'],
					'attribute_group_name'	=>	$result['name'],
					'group_language_id'		=>	$result['language_id'],);
			}

		$this->response->setOutput(json_encode($json));
	}
}
?>
