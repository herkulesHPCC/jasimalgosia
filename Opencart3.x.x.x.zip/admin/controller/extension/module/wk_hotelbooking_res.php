<?php
class ControllerExtensionModulewkhotelbookingres extends Controller {

	private $error = array();

	public function install() {

		$this->load->model('extension/module/wk_hotelbooking_res');
		$this->model_extension_module_wk_hotelbooking_res->createTableReservation();
		$this->model_extension_module_wk_hotelbooking_res->createTablePartner();

		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();
		$sort_order = 1;
		foreach ($data['languages'] as $language) {
			$name[$language['language_id']]['name'] = 'Room Amenities';
			$cat[$language['language_id']]['name'] = 'Hotel';
			$cat[$language['language_id']]['description'] = 'Hotel';
			$cat[$language['language_id']]['meta_title'] = 'Hotel';
			$cat[$language['language_id']]['meta_description'] = 'Hotel';
			$cat[$language['language_id']]['meta_keyword'] = 'Hotel';

		}
		$attribute_group_data = array(
			'sort_order' => $sort_order,
			'attribute_group_description' => $name
		);
		$option_data = array(
			'type'=>'checkbox',
			'sort_order'=>1,
			'option_description'=>$name
			);
		$category_data = array(
			'category_description' => $cat,
			'path' => '',
			'parent_id'=>0,
			'filter'=>'',
			'keyword'=>'',
			'image'=>'',
			'top'=>1,
			'column'=>1,
			'sort_order'=>1,
			'status'=>1,
			'category_store'=>array('0'=>0),
			'category_layout'=>array('0'=>'')
			);
		$this->load->model('setting/setting');

		$result = $this->db->query("SELECT * FROM  ".DB_PREFIX."setting WHERE  `code` LIKE  'wk_hotelbookingattr_attrgroupid' ")->rows;

		$this->load->model('catalog/attribute_group');

		if(empty($result)) {
			$attrgrpid['wk_hotelbookingattr_attrgroupid'] = $this->model_catalog_attribute_group->addAttributeGroup($attribute_group_data);

			$this->model_setting_setting->editSetting('wk_hotelbookingattr', $attrgrpid);
		}
		$result = $this->db->query("SELECT * FROM  ".DB_PREFIX."setting WHERE  `code` LIKE  'wk_hotelbookingopt_optionid' ")->rows;
		if(empty($result)) {
			$this->load->model('catalog/option');
			$option_id['wk_hotelbookingopt_optionid'] = $this->model_catalog_option->addOption($option_data);

			$this->model_setting_setting->editSetting('wk_hotelbookingopt', $option_id);
		}
		$result = $this->db->query("SELECT * FROM  ".DB_PREFIX."setting WHERE  `code` LIKE  'wk_hotelbookingcat_categoryid' ")->rows;
		if(empty($result)) {
			$this->load->model('catalog/category');
			$category_id['wk_hotelbookingcat_categoryid'] = $this->model_catalog_category->addCategory($category_data);
			$this->model_setting_setting->editSetting('wk_hotelbookingcat', $category_id);
		}
		foreach ($data['languages'] as $language) {
			 $duration_option_description[$language['language_id']]['name'] = 'Duration';
			 $rate_option_description[$language['language_id']]['name'] = 'Rate';
			 $from_option_description[$language['language_id']]['name'] = 'Check in';
			 $till_option_description[$language['language_id']]['name'] = 'Check out';
			 $adult_option_description[$language['language_id']]['name'] = 'Adult';
			 $child_option_description[$language['language_id']]['name'] = 'Child';
		}
		$result = $this->db->query("SELECT * FROM  ".DB_PREFIX."setting WHERE  `code` LIKE  'wk_booking_options' ")->rows;
		$val=array(array(
			'type'=>'text',
			'sort_order'=>1,
			'option_description'=>$duration_option_description
			),
			array(
			'type'=>'text',
			'sort_order'=>1,
			'option_description'=>$rate_option_description
			),array(
			'type'=>'datetime',
			'sort_order'=>1,
			'option_description'=>$from_option_description
			),array(
			'type'=>'datetime',
			'sort_order'=>1,
			'option_description'=>$till_option_description
			),array(
			'type'=>'text',
			'sort_order'=>1,
			'option_description'=>$adult_option_description
			),array(
			'type'=>'text',
			'sort_order'=>1,
			'option_description'=>$child_option_description
			));
		if(empty($result)) {
		foreach ($val as $key => $opt) {
			$options['wk_hotelbooking_options' . $key]=$this->model_catalog_option->addOption($opt);
		}
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('wk_hotelbooking_options', $options);
	}
	}

	public function index() {

		$this->load->language('extension/module/wk_hotelbooking_res');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		$this->load->model('extension/module/wk_hotelbooking_res');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('module_wk_hotelbooking_res', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');

			if(isset($this->request->post['module_wk_hotel_res_tab'])){
				foreach ($this->request->post['module_wk_hotel_res_tab'] as $key => $value) {
					$left_this = false;
					foreach($value as $language_key => $language_value){
						if(isset($language_value['heading']) && $language_value['heading'])
							$left_this = true;

					if(!$left_this){
						unset($this->request->post['module_wk_hotel_res_tab'][$key][$language_key]);
						if(!$this->request->post['module_wk_hotel_res_tab'][$key])
							unset($this->request->post['module_wk_hotel_res_tab'][$key]);
					}
					}
				}

				$this->model_extension_module_wk_hotelbooking_res->addTabData($this->request->post['module_wk_hotel_res_tab']);
			} else {
				$this->db->query("DELETE FROM ".DB_PREFIX."wk_hotel_tab");
			}
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'].'&type=module', true));
		}


		$data['ur_timezone'] = $this->language->get('ur_timezone');

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['header_name_error'])) {
			$data['header_name_error'] = $this->error['header_name_error'];
		} else {
			$data['header_name_error'] = '';
		}

		if (isset($this->error['header_button_error'])) {
			$data['header_button_error'] = $this->error['header_button_error'];
		} else {
			$data['header_button_error'] = '';
		}

		if (isset($this->error['button_range_error'])) {
			$data['button_range_error'] = $this->error['button_range_error'];
		} else {
			$data['button_range_error'] = '';
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('marketplace/extension', 'user_token='. $this->session->data['user_token'].'&type=module', true)
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('extension/module/wk_hotelbooking_res', 'user_token=' . $this->session->data['user_token'], true),
   		);
   		$config_array = array(
                        'module_wk_hotelbooking_res_enable',
                        'module_wk_hotelbooking_res_status',
                        'module_wk_hotelbooking_res_hotelapprove',
                        'module_wk_hotelbooking_res_roomapprove',
                        'module_wk_hotelbooking_res_fxapprove',
                        'module_wk_hotelbooking_res_opapprove',
                        'module_wk_hotelbooking_res_accfx',
                        'module_wk_hotelbooking_res_accop',
                        'module_wk_hotelbooking_res_allowedaccmenu',
                        'module_wk_hotelbooking_res_accmenuseq',
                        'module_wk_hotelbooking_res_fxdisapprove',
                        'module_wk_hotelbooking_res_roomdisapprove',
                        'module_wk_hotelbooking_res_hoteldisapprove',
                        'module_wk_hotelbooking_res_numhotel',
                        'module_wk_hotelbooking_res_numroom',
                        'module_wk_hotelbooking_res_numfxfacility',
                        'module_wk_hotelbooking_res_numopfacility',
                        'module_wk_hotelbooking_res_allowedprofilecolumn',
                        'module_wk_hotelbooking_res_profile_telephone',
                        'module_wk_hotelbooking_res_profile_email',
                        'module_wk_hotelbooking_res_commission_add',
                        'module_wk_hotelbooking_res_commission',
												'module_wk_hotelbooking_res_google_key',
                        'module_wk_hotelbooking_res_commissionworkedon',
                        'module_wk_hotelbooking_res_boxcommission',
                        'module_wk_hotelbooking_res_mail_keywords',
												'module_wk_hotelbooking_res_mail_partner_request',
												'module_wk_hotelbooking_res_mail_product_request',
												'module_wk_hotelbooking_res_mail_transaction',
												'module_wk_hotelbooking_res_mail_order',
												'module_wk_hotelbooking_res_mail_partner_admin',
												'module_wk_hotelbooking_res_mail_product_admin',
												'module_wk_hotelbooking_res_mail_cutomer_to_seller',
												'module_wk_hotelbooking_res_mail_seller_to_admin',
												'module_wk_hotelbooking_res_mail_partner_approve',
												'module_wk_hotelbooking_res_mail_product_approve',
												'module_wk_hotelbooking_res_mail_admin_on_edit',
												'module_wk_hotelbooking_res_mail_seller_on_edit',
												'wk_hotelboooking_res_mail_product_approve',
												'module_wk_hotelbooking_res_mail_product_request',
												'module_wk_hotelbooking_res_partnerapprov',
												'module_wk_hotelbooking_res_sellheader',
												'module_wk_hotelbooking_res_sellbuttontitle',
												'module_wk_hotelbooking_res_commission_fixed',
												'module_wk_hotelbooking_res_commission_percentage',
												'module_wk_hotelbooking_res_commission_default',
												'module_wk_hotelbooking_res_adminPath',
												'module_wk_hotelbooking_res_customercontactseller',
												'module_wk_hotelbooking_res_customercontactseller_toadmin',
												'module_wk_hotelbooking_res_deleteReview',
												'module_wk_hotelbooking_res_editReview',
												'module_wk_hotelbooking_res_cancel',
												'module_wk_hotelbooking_res_header',
												'module_wk_hotelbooking_res_central',
												'module_wk_hotelbooking_res_delseller',
												'module_wk_hotelbooking_res_range'
                    );

   		$data['account_menu'] = array(
			'profile' => $this->language->get('entry_mod_profile'),
			'dashboard' => $this->language->get('entry_mod_dashboard'),
			'transaction' => $this->language->get('entry_mod_transaction'),
			'addhotel'	=> $this->language->get('entry_mod_add_hotel'),
			'addroom'	=> $this->language->get('entry_mod_add_room'),
			'addfxfacility'	=> $this->language->get('entry_mod_add_fxfacility'),
			'addopfacility'	=> $this->language->get('entry_mod_add_opfacility'),
			'hotelreview'	=> $this->language->get('entry_mod_hotel_review'),
			'allbookings'	=> $this->language->get('entry_mod_allbookings'),
			'query' => $this->language->get('entry_mod_query'),
			'asktoadmin' => $this->language->get('entry_mod_asktoadmin')
		);

   		$data['adminPath'] = DIR_APPLICATION;

        foreach ($config_array as $confbok) {
          if (isset($this->request->post[$confbok])) {
            $data[$confbok] = $this->request->post[$confbok];
          } else {
            $data[$confbok] = $this->config->get($confbok);
          }
        }

        $data['module_wk_hotel_res_tab'] = $this->model_extension_module_wk_hotelbooking_res->getTabData();

  	$this->load->model('localisation/language');
    $data['languages'] = $this->model_localisation_language->getLanguages();
		$data['config_language_id'] = $this->config->get('config_language_id');

		$data['profile_table'] = array();
		$profile_table = $this->db->query("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '".DB_DATABASE."' AND table_name = '".DB_PREFIX."customerpartner_to_customer'")->rows;

		$profile_table = array_slice($profile_table, 3, -1);
		if($profile_table[11]['COLUMN_NAME'] == 'companyname') {
			unset($profile_table[11]);
		}
		foreach($profile_table as $key => $value){
			$data['profile_table'][] = $value['COLUMN_NAME'];
		}

		$data['action'] = $this->url->link('extension/module/wk_hotelbooking_res', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'].'&type=module', true);

		$data['user_token']  = $this->session->data['user_token'];

		$this->load->model('tool/image');

		$data['placeholder']  = $this->model_tool_image->resize('placeholder.png',100,100);

		if($data['module_wk_hotelbooking_res_central'] && file_exists(DIR_IMAGE.'/'.$data['module_wk_hotelbooking_res_central'])) {
			$data['module_wk_hotelbooking_res_central_image'] = $this->model_tool_image->resize($data['module_wk_hotelbooking_res_central'],100,100);
		} else {
			$data['module_wk_hotelbooking_res_central_image'] = $this->model_tool_image->resize('catalog/Seller-Center-Hero-Banner.png',100,100);
			$data['module_wk_hotelbooking_res_central'] = 'catalog/Seller-Center-Hero-Banner.png';
		}
		if($data['module_wk_hotelbooking_res_header'] && file_exists(DIR_IMAGE.'/'.$data['module_wk_hotelbooking_res_header'])) {
			$data['module_wk_hotelbooking_res_header_image'] = $this->model_tool_image->resize($data['module_wk_hotelbooking_res_header'],100,100);
		} else {
			$data['module_wk_hotelbooking_res_header_image'] = $this->model_tool_image->resize('catalog/head.png',100,100);
			$data['module_wk_hotelbooking_res_header'] = 'catalog/head.png';
		}
		$this->load->model('customerpartner/mail');

		$data['mails'] = $this->model_customerpartner_mail->gettotal();
		$data['header'] = $this->load->Controller('common/header');
		$data['column_left'] = $this->load->Controller('common/column_left');
		$data['footer'] = $this->load->Controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/wk_hotelbooking_res',$data));
	}

	private function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/wk_hotelbooking_res')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->request->post['module_wk_hotelbooking_res_sellheader'] as $language_id => $value) {
			if ((utf8_strlen(trim($value)) < 1) || (utf8_strlen(trim($value)) > 255)) {
				$this->error['header_name_error'][$language_id] = $this->language->get('header_name_error');
			}
		}

		foreach ($this->request->post['module_wk_hotelbooking_res_sellbuttontitle'] as $language_id => $value) {
			if ((utf8_strlen(trim($value)) < 1) || (utf8_strlen(trim($value)) > 255)) {
				$this->error['header_button_error'][$language_id] = $this->language->get('header_button_error');
			}
		}

		if(!empty(trim($this->request->post['module_wk_hotelbooking_res_range']))) {
			if($this->request->post['module_wk_hotelbooking_res_range'] < 1) {
					$this->error['button_range_error'] = $this->language->get('button_range_error');
			}
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}
	public function upload() {

		if ($this->request->files['file']['name']) {
            if (!$this->request->files['file']['error']) {
                $name = md5(rand(100, 200));
                $ext = explode('.', $this->request->files['file']['name']);
                $filename = $name . '.' . $ext[1];
                if(is_dir(DIR_IMAGE .'hoteltab/')){
	                $destination =DIR_IMAGE .'hoteltab/' . $filename;
	                $location = $this->request->files["file"]["tmp_name"];
	                move_uploaded_file($location, $destination);
	                echo HTTP_CATALOG .'image/hoteltab/' . $filename;
	            }else{
	            	mkdir(DIR_IMAGE .'hoteltab/');
	                $destination = DIR_IMAGE .'hoteltab/' . $filename;
	                $location = $this->request->files["file"]["tmp_name"];
	                move_uploaded_file($location, $destination);
	                echo HTTP_CATALOG. 'image/hoteltab/' . $filename;
	            }
            }
            else
            {
              echo  $message = 'Ooops!  Your upload triggered the following error:  '.$this->request->files['file']['error'];
            }
        }
	}

	public function uninstall() {
		if ($this->user->hasPermission('modify', 'extension/module/wk_hotelbooking_res')) {
				$this->load->model('catalog/option');
				$this->model_catalog_option->deleteOption($this->config->get('wk_hotelbooking_options3'));
				$this->model_catalog_option->deleteOption($this->config->get('wk_hotelbooking_options2'));
				$this->model_catalog_option->deleteOption($this->config->get('wk_hotelbooking_options1'));
				$this->model_catalog_option->deleteOption($this->config->get('wk_hotelbooking_options0'));
				$this->model_catalog_option->deleteOption($this->config->get('wk_hotelbooking_options4'));
				$this->model_catalog_option->deleteOption($this->config->get('wk_hotelbooking_options5'));
				$this->model_catalog_option->deleteOption($this->config->get('wk_hotelbookingopt_optionid'));
				$this->load->model('extension/module/wk_hotelbooking_res');
				$this->model_extension_module_wk_hotelbooking_res->deleteTableReservation();
				//Delete Attributes and attribute group
				$this->load->model('catalog/attribute_group');
				$this->load->model('catalog/attribute');
				$this->load->model('catalog/category');
				$attribute = $this->model_catalog_attribute->getAttributes(array('filter_attribute_group_id'=>$this->config->get('wk_hotelbookingattr_attrgroupid')));
				if($attribute) {
					foreach ($attribute as $key => $value) {
						$this->model_catalog_attribute->deleteAttribute($value['attribute_id']);
					}
			  }
			 $this->model_catalog_attribute_group->deleteAttributeGroup($this->config->get('wk_hotelbookingattr_attrgroupid'));
			 $this->model_catalog_category->deleteCategory($this->config->get('wk_hotelbookingcat_categoryid'));
			 $this->model_extension_module_wk_hotelbooking_res->deleteTablePartner();
		} else {
			$this->load->language('extension/module/wk_hotelbooking_res');
			$this->error['warning'] = $this->language->get('error_permission');
		}
 }
}
