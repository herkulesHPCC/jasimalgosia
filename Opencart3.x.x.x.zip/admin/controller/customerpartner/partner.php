<?php
class ControllerCustomerpartnerPartner extends Controller {

	private $error = array();
	private $data = array();

  	public function index() {

		$this->load->language('customerpartner/partner');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('customerpartner/partner');

    	$this->getList();
  	}

  	private function getList() {

		if (isset($this->request->get['filter_name'])) {
			$filter_name = $this->request->get['filter_name'];
		} else {
			$filter_name = null;
		}

		if (isset($this->request->get['filter_email'])) {
			$filter_email = $this->request->get['filter_email'];
		} else {
			$filter_email = null;
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$filter_customer_group_id = $this->request->get['filter_customer_group_id'];
		} else {
			$filter_customer_group_id = null;
		}

		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = null;
		}

		if (isset($this->request->get['filter_approved'])) {
			$filter_approved = $this->request->get['filter_approved'];
		} else {
			$filter_approved = null;
		}

		if (isset($this->request->get['filter_ip'])) {
			$filter_ip = $this->request->get['filter_ip'];
		} else {
			$filter_ip = null;
		}

		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = null;
		}

		if (isset($this->request->get['view_all'])) {
			$filter_all = $this->request->get['view_all'];
		} else {
			$filter_all = 0;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'customer_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_approved'])) {
			$url .= '&filter_approved=' . $this->request->get['filter_approved'];
		}

		if (isset($this->request->get['filter_ip'])) {
			$url .= '&filter_ip=' . $this->request->get['filter_ip'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		if (isset($this->request->get['view_all'])) {
			$url .= '&view_all=' . $this->request->get['view_all'];
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . $url, 'true'),
      		'separator' => ' :: '
   		);

		$data['approve'] = $this->url->link('customerpartner/partner/approve', 'user_token=' . $this->session->data['user_token'] . $url, 'true');

        if (version_compare(VERSION, '2.1', '>=')) {
			$data['insert'] = $this->url->link('customer/customer/add', 'user_token=' . $this->session->data['user_token'] . $url, 'true');
		} else {
			$data['insert'] = $this->url->link('sale/customer/add', 'user_token=' . $this->session->data['user_token'] . $url, 'true');
		}
		$data['delete'] = $this->url->link('customerpartner/partner/delete', 'user_token=' . $this->session->data['user_token'] . $url, 'true');

		$data['customers'] = array();

		$filter_data = array(
			'filter_name'              => $filter_name,
			'filter_email'             => $filter_email,
			'filter_all'               => $filter_all,
			'filter_customer_group_id' => $filter_customer_group_id,
			'filter_status'            => $filter_status,
			'filter_approved'          => $filter_approved,
			'filter_date_added'        => $filter_date_added,
			'filter_ip'                => $filter_ip,
			'sort'                     => $sort,
			'order'                    => $order,
			'start'                    => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit'                    => $this->config->get('config_limit_admin')
		);

		$customer_total = $this->model_customerpartner_partner->getTotalCustomers($filter_data);

		$results = $this->model_customerpartner_partner->getCustomers($filter_data);

    	foreach ($results as $result) {
			$action = array();

			$action = $this->url->link('customerpartner/partner/update', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $result['customer_id'] . $url, 'true');

			if($result['is_partner']){
				$is_partner = ($result['is_partner'] == 0) ? "Not Host" : "Host";
				$commission = $result['commission'];
			}
			else{
				$is_partner = "Normal customer";
				$commission = '';
			}
			$data['customers'][] = array(
				'customer_id'    => $result['customer_id'],
				'name'           => $result['name'],
				'email'          => $result['email'],
				'customer_group' => $result['customer_group'],
				'status'         => ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				//'approved'       => ($result['approved'] ? $this->language->get('text_yes') : $this->language->get('text_no')),
				'ip'             => $result['ip'],
				'date_added'     => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'selected'       => isset($this->request->post['selected']) && in_array($result['customer_id'], $this->request->post['selected']),
				'action'         => $action,
				'is_partner'	 => $is_partner,
				'commission'	=>	$commission
			);
		}


		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->session->data['error_warning'])) {
			$this->error['warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_approved'])) {
			$url .= '&filter_approved=' . $this->request->get['filter_approved'];
		}

		if (isset($this->request->get['filter_ip'])) {
			$url .= '&filter_ip=' . $this->request->get['filter_ip'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		if (isset($this->request->get['view_all'])) {
			$url .= '&view_all=' . $this->request->get['view_all'];
		}

		$data['sort_customerId'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . '&sort=customer_id' . $url, 'true');
		$data['sort_name'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . '&sort=name' . $url, 'true');
		$data['sort_email'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . '&sort=c.email' . $url, 'true');
		$data['sort_customer_group'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . '&sort=customer_group' . $url, 'true');
		$data['sort_status'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . '&sort=c.status' . $url, 'true');
		$data['sort_approved'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . '&sort=c.approved' . $url, 'true');
		$data['sort_ip'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . '&sort=c.ip' . $url, 'true');
		$data['sort_date_added'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . '&sort=c.date_added' . $url, 'true');

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_approved'])) {
			$url .= '&filter_approved=' . $this->request->get['filter_approved'];
		}

		if (isset($this->request->get['filter_ip'])) {
			$url .= '&filter_ip=' . $this->request->get['filter_ip'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['view_all'])) {
			$url .= '&view_all=' . $this->request->get['view_all'];
			$data['customer_type'] = $this->request->get['view_all'];
		}

		$pagination = new Pagination();
		$pagination->total = $customer_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'true');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($customer_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($customer_total - $this->config->get('config_limit_admin'))) ? $customer_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $customer_total, ceil($customer_total / $this->config->get('config_limit_admin')));

		$data['filter_name'] = $filter_name;
		$data['filter_email'] = $filter_email;
		$data['filter_customer_group_id'] = $filter_customer_group_id;
		$data['filter_status'] = $filter_status;
		$data['filter_approved'] = $filter_approved;
		$data['filter_ip'] = $filter_ip;
		$data['filter_date_added'] = $filter_date_added;
		$data['wk_viewall'] = $filter_all;

		if (version_compare(VERSION, '2.1', '>=')) {
			$this->load->model('customer/customer_group');
	    	$data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();
		} else {
			$this->load->model('sale/customer_group');
	    	$data['customer_groups'] = $this->model_sale_customer_group->getCustomerGroups();
		}

		$this->load->model('setting/store');

		$data['stores'] = $this->model_setting_store->getStores();

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['footer'] = $this->load->controller('common/footer');
		$data['column_left'] = $this->load->controller('common/column_left');

		$this->response->setOutput($this->load->view('customerpartner/partner_list',$data));

  	}

  	public function delete() {

		$this->load->language('customerpartner/partner');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('customerpartner/partner');

		if (isset($this->request->post['selected']) && $this->validateForm()) {
			foreach ($this->request->post['selected'] as $customer_id) {
				$this->model_customerpartner_partner->deleteCustomer($customer_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer_group_id'])) {
				$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_approved'])) {
				$url .= '&filter_approved=' . $this->request->get['filter_approved'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['view_all'])) {
				$url .= '&view_all=' . $this->request->get['view_all'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . $url, 'true'));
		}

		$this->getList();
	}

	public function approve() {

		$this->load->language('customerpartner/partner');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('customerpartner/partner');

		if (!$this->user->hasPermission('modify', 'customerpartner/partner')) {
			$this->error['warning'] = $this->language->get('error_permission');

		} elseif (isset($this->request->post['selected'])) {

			$approved = $setstatus = 0;

			foreach ($this->request->post['selected'] as $customer_id) {

				if(isset($this->request->get['set_status']))
					$setstatus = $this->request->get['set_status'];

				$customer_info = $this->model_customerpartner_partner->approve($customer_id,$setstatus);

				$approved++;

				//to do send mail to seller after set status..
			}

			$this->session->data['success'] = sprintf($this->language->get('text_approved'), $approved);

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer_group_id'])) {
				$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_approved'])) {
				$url .= '&filter_approved=' . $this->request->get['filter_approved'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['view_all'])) {
				$url .= '&view_all=' . $this->request->get['view_all'];
			}


			$this->response->redirect($this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . $url, 'true'));

		}

		$this->getList();
	}

  	public function update() {

		$this->load->language('customerpartner/partner');

    	$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('customerpartner/partner');

		if (version_compare(VERSION, '2.1', '>=')) {
			$this->load->language('customer/customer');
			$this->load->model('customer/customer');
		} else {
			$this->load->language('sale/customer');
			$this->load->model('sale/customer');
		}

    	if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {

			//for mp
			$this->model_customerpartner_partner->updatePartner($this->request->get['customer_id'],$this->request->post);

			if(isset($this->request->post['product_ids']) AND $this->request->post['product_ids']){
				$this->model_customerpartner_partner->addproduct($this->request->get['customer_id'],$this->request->post);
	  		}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['filter_name'])) {
				$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_email'])) {
				$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
			}

			if (isset($this->request->get['filter_customer_group_id'])) {
				$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
			}

			if (isset($this->request->get['filter_status'])) {
				$url .= '&filter_status=' . $this->request->get['filter_status'];
			}

			if (isset($this->request->get['filter_approved'])) {
				$url .= '&filter_approved=' . $this->request->get['filter_approved'];
			}

			if (isset($this->request->get['filter_ip'])) {
				$url .= '&filter_ip=' . $this->request->get['filter_ip'];
			}

			if (isset($this->request->get['filter_date_added'])) {
				$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . $url, 'true'));
		}

    	$this->getForm();
  	}

  	private function getForm() {

    	$data['heading_title'] = $this->language->get('text_form');

		$data['user_token'] = $this->session->data['user_token'];

		if (isset($this->request->get['customer_id'])) {
			$data['customer_id'] = $this->request->get['customer_id'];
		} else {
			$data['customer_id'] = 0;
		}

 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_email'])) {
			$url .= '&filter_email=' . urlencode(html_entity_decode($this->request->get['filter_email'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_customer_group_id'])) {
			$url .= '&filter_customer_group_id=' . $this->request->get['filter_customer_group_id'];
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['filter_approved'])) {
			$url .= '&filter_approved=' . $this->request->get['filter_approved'];
		}

		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . $url, 'true'),
      		'separator' => ' :: '
   		);

		if (isset($data['customer_id']))
			$data['action'] = $this->url->link('customerpartner/partner/update', 'user_token=' . $this->session->data['user_token'] . '&customer_id=' . $data['customer_id'] . $url, 'true');

    	$data['cancel'] = $this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . $url, 'true');

		$partner_info = $this->model_customerpartner_partner->getPartnerCustomerInfo($data['customer_id']);

    	if($partner_info){

    		$data['partner_orders'] = $this->model_customerpartner_partner->getSellerOrders($this->request->get['customer_id']);

    		foreach ($data['partner_orders'] as $key => $value) {

    			$products = $this->model_customerpartner_partner->getSellerOrderProducts($value['order_id']);

				$data['partner_orders'][$key]['productname'] = '';
				$data['partner_orders'][$key]['total'] = 0;

				if($products){
					foreach ($products as $key2 => $value) {
						$data['partner_orders'][$key]['productname'] = $data['partner_orders'][$key]['productname'].$value['name'].' x '.$value['quantity'].' , ';
						$data['partner_orders'][$key]['total'] += $value['c2oprice'];
					}
				}

				$data['partner_orders'][$key]['total'] = $this->currency->format($data['partner_orders'][$key]['total'] ,$this->config->get('config_currency'));

				$data['partner_orders'][$key]['view'] = $this->url->link('sale/order/info', 'user_token=' . $this->session->data['user_token'] . '&order_id='.$value['order_id'], 'true');
    			$data['partner_orders'][$key]['edit'] = $this->url->link('sale/order/edit', 'user_token=' . $this->session->data['user_token'] . '&order_id='.$value['order_id'], 'true');
    		}

    		$this->load->model('tool/image');
    		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

    		foreach ($partner_info as $key => $value) {

    			$data[$key] = $value;

    			if($key=='avatar' || $key=='companylogo' || $key=='companybanner'){

    				if(is_file(DIR_IMAGE.$value))
						$data[$key.'_placeholder'] = $this->model_tool_image->resize($value, 100, 100);
					else
						$data[$key.'_placeholder'] = $data['placeholder'];
    			}

    		}

			$data['loadLocation'] = $this->url->link('customerpartner/partner/loadLocation&location='.$partner_info['companylocality'].'&user_token='. $this->session->data['user_token'] ,'true');

    		$data['partner_amount'] = $this->sellerCommission($partner_info['commission']);

    	}else{
    		$this->session->data['error_warning'] = $this->language->get('error_seller');
			$this->response->redirect($this->url->link('customerpartner/partner', 'user_token=' . $this->session->data['user_token'] . $url, 'true'));
    	}

		if (isset($this->request->post['commission'])) {
      		$data['commission'] = $this->request->post['commission'];
    	} elseif (!empty($partner_info)) {
			$data['commission'] = $partner_info['commission'];
		} else {
      		$data['commission'] = '';
    	}

    	if (isset($this->request->post['paypalid'])) {
      		$data['paypalid'] = $this->request->post['paypalid'];
    	} elseif (!empty($partner_info)) {
			$data['paypalid'] = $partner_info['paypalid'];
		} else {
      		$data['paypalid'] = '';
    	}

    	if (isset($this->request->post['otherpayment'])) {
      		$data['otherpayment'] = $this->request->post['otherpayment'];
    	} elseif (!empty($partner_info)) {
			$data['otherpayment'] = $partner_info['otherpayment'];
		} else {
      		$data['otherpayment'] = '';
    	}

    	$data['transactionTab'] = $this->url->link('customerpartner/transaction/addtransaction','user_token='.$this->session->data['user_token'].'seller_id='.$this->request->get['customer_id'].'action=partner' , 'true');

		$this->load->model('localisation/country');
		$data['countries'] = $this->model_localisation_country->getCountries();

		$data['header'] = $this->load->controller('common/header');
		$data['footer'] = $this->load->controller('common/footer');
		$data['column_left'] = $this->load->controller('common/column_left');

		$this->response->setOutput($this->load->view('customerpartner/partner_form',$data));
	}

  	public function transaction() {

		$this->language->load('customerpartner/partner');

		$this->load->model('customerpartner/partner');
		$this->load->model('customerpartner/transaction');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->user->hasPermission('modify', 'customerpartner/partner')){
			$this->model_customerpartner_transaction->addPartnerTransaction($this->request->get['customer_id'], $this->request->post['description'], $this->request->post['amount']);

			$data['success'] = $this->language->get('text_success');
		} else {
			$data['success'] = '';
		}

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && !$this->user->hasPermission('modify', 'customerpartner/partner')) {
			$data['error_warning'] = $this->language->get('error_permission');
		} else {
			$data['error_warning'] = '';
		}

		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_balance'] = $this->language->get('text_balance');

		$data['column_date_added'] = $this->language->get('column_date_added');
		$data['column_description'] = $this->language->get('column_description');
		$data['column_amount'] = $this->language->get('column_amount');

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$data['transactions'] = array();

		$results = $this->model_customerpartner_transaction->getTransactions($this->request->get['customer_id'], ($page - 1) * $this->config->get('config_limit_admin'), $this->config->get('config_limit_admin'));

		foreach ($results as $result) {
			$data['transactions'][] = array(
				'amount'      => $this->currency->format($result['amount'],$this->config->get('config_currency')),
				'description' => $result['details'],
				'date_added'  => date($this->language->get('date_format_short'), strtotime($result['date_added']))
			);
		}

		$data['balance'] = $this->currency->format($this->model_customerpartner_transaction->getTransactionTotal($this->request->get['customer_id']),$this->config->get('config_currency'));

		$transaction_total = $this->model_customerpartner_transaction->getTotalTransactions($this->request->get['customer_id']);

		$pagination = new Pagination();
		$pagination->total = $transaction_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('customerpartner/partner/transaction', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', 'true');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($transaction_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($transaction_total - $this->config->get('config_limit_admin'))) ? $transaction_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $transaction_total, ceil($transaction_total / $this->config->get('config_limit_admin')));

		if (version_compare(VERSION, '2.1', '>=')) {
			$this->response->setOutput($this->load->view('customer/customer_transaction', $data));
		} else {
			$this->response->setOutput($this->load->view('sale/customer_transaction', $data));
		}

	}

	public function autocomplete() {

		$json = array();

		if (isset($this->request->get['filter_name']) || isset($this->request->get['filter_email'])) {

			$this->load->model('customerpartner/partner');

			if (isset($this->request->get['filter_name'])) {
				$filter_name = $this->request->get['filter_name'];
			} else {
				$filter_name = '';
			}

			if (isset($this->request->get['filter_view'])) {
				$filter_view = $this->request->get['filter_view'];
			} else {
				$filter_view = 0 ;
			}

			if (isset($this->request->get['filter_email'])) {
				$filter_email = $this->request->get['filter_email'];
			} else {
				$filter_email = '';
			}

			if (isset($this->request->get['limit'])) {
				$limit = $this->request->get['limit'];
			} else {
				$limit = 20;
			}

			$data = array(
				'filter_name'         => $filter_name,
				'filter_all'         => $filter_view,
				'filter_email'  	  => $filter_email,
				'start'               => 0,
				'limit'               => $limit
			);

			$results = $this->model_customerpartner_partner->getCustomers($data);

			foreach ($results as $result) {

				$option_data = array();

				$json[] = array(
					'id' 		 => $result['customer_id'],
					'name'       => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					'email'      => $result['email'],
				);
			}
		}

		$this->response->setOutput(json_encode($json));
	}

	public function updateProductSeller() {

		$json = array();

		$this->language->load('customerpartner/partner');

		if ($this->validateForm() AND isset($this->request->get['product_id']) AND isset($this->request->get['partner_id'])) {

			$this->load->model('customerpartner/partner');

			$results = $this->model_customerpartner_partner->updateProductSeller($this->request->get['partner_id'],$this->request->get['product_id']);

			$json['success'] = $this->language->get('text_success_seller');

		}elseif(isset($this->error['warning'])){
			$json['success'] = $this->error['warning'];
		}

		$this->response->setOutput(json_encode($json));
	}

	public function sellerCommission($commission = 0){

		//get commission for seller
		$this->load->model('customerpartner/partner');
		$partner_amount = $this->model_customerpartner_partner->getPartnerAmount($this->request->get['customer_id']);

		if($partner_amount){
			$total = $partner_amount['total'];
			$admin_part = $partner_amount['admin'];
			$partner_part = $partner_amount['customer'];
			$paid = $partner_amount['paid'];
			$left = $partner_part - $partner_amount['paid'];

			$partner_amount = array(
				'commission' => $commission,
				'qty_sold' => $partner_amount['quantity'] ? $partner_amount['quantity'] : ' 0 ',
				'total' => $this->currency->format($total ,$this->config->get('config_currency')) ,
				'paid' => $this->currency->format($paid ,$this->config->get('config_currency')) ,
				'left_amount' => $this->currency->format($left, $this->config->get('config_currency')) ,
				'admin_amount' => $this->currency->format($admin_part,$this->config->get('config_currency')),
				'partner_amount' => $this->currency->format($partner_part,$this->config->get('config_currency')),
			);
		}

		$this->response->setOutput(json_encode($partner_amount));

		// return $partner_amount;
	}

	private function validateForm() {

    	if (!$this->user->hasPermission('modify', 'customerpartner/partner')) {
      		$this->error['warning'] = $this->language->get('error_permission');
    	}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		if (!$this->error) {
	  		return true;
		} else {
	  		return false;
		}
  	}

  	//for location tab
	public function loadLocation(){

		if($this->request->get['location']){
			$location = '<iframe id="seller-location" width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q='.$this->request->get['location'].'&amp;output=embed"></iframe>';

			$this->response->setOutput($location);
		}else{
			$this->response->setOutput('No location added by Seller.');
		}
	}

}
?>
