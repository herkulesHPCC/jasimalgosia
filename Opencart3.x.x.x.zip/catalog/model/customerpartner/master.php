<?php
class ModelCustomerpartnerMaster extends Model {
	//Live
	public function getProfile($customerid){
		$sql = "SELECT *,co.name as country, c.firstname as firstname, c.lastname as lastname FROM " . DB_PREFIX . "customerpartner_to_customer c2c LEFT JOIN ".DB_PREFIX ."customer c ON (c2c.customer_id = c.customer_id) LEFT JOIN ".DB_PREFIX ."address a ON (c.address_id = a.address_id) LEFT JOIN ".DB_PREFIX ."country co ON (c2c.country = co.iso_code_2) WHERE c2c.customer_id = '".(int)$customerid."' AND c2c.is_partner = '1'";
		$query = $this->db->query($sql);
		return $query->row;
	}
	public function getPartnerIdBasedonProduct($productid){
		return $this->db->query("SELECT c2p.customer_id as id FROM " . DB_PREFIX . "customerpartner_to_product c2p LEFT JOIN ".DB_PREFIX."product p ON(c2p.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) WHERE c2p.product_id = '".(int)$productid."' AND p.status = 1 AND p2s.store_id = '".$this->config->get('config_store_id')."' ORDER BY c2p.id ASC ")->row;
	}

	public function getFeedbackList($customerid) {
		$sql = "SELECT c2f.* FROM " . DB_PREFIX . "customerpartner_to_feedback c2f LEFT JOIN ".DB_PREFIX ."customer c ON (c2f.customer_id = c.customer_id) LEFT JOIN ".DB_PREFIX ."customerpartner_to_customer cpc ON (cpc.customer_id = c.customer_id) where c2f.seller_id = '".(int)$customerid."'";
		$query = $this->db->query($sql);
		return $query->rows;
	}

	public function getTotalFeedback($customerid){
		$query = $this->db->query("SELECT id FROM " . DB_PREFIX . "customerpartner_to_feedback c2f where c2f.seller_id='".(int)$customerid."'");
		return count($query->rows);
	}
	public function getPartnerCollectionCount($customerid){
		return count($this->db->query("SELECT DISTINCT p.product_id FROM " . DB_PREFIX . "customerpartner_to_product c2p LEFT JOIN ".DB_PREFIX ."product p ON (c2p.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_to_store p2s ON (p.product_id = p2s.product_id) WHERE c2p.customer_id='".$customerid."' AND p.status='1' AND p.date_available <= NOW() AND p2s.store_id = '".$this->config->get('config_store_id')."' ORDER BY c2p.product_id ")->rows);
	}
	public function getAverageFeedback($customerid){

		 $sum = 0;

		$avg = $this->db->query("SELECT avg(feedprice) AS p,avg(feedvalue) AS v,avg(feedquality) AS q FROM `" . DB_PREFIX . "customerpartner_to_feedback` WHERE seller_id='".(int)$customerid."'")->row;

		foreach ($avg as $value) {

              $sum += $value;
		}

		$rating = (int)$sum / 3;
	  return $rating ;


	}

	public function getAverageFeedbackTotal($customerid) {
		$sum = 0;

	 $avg = $this->db->query("SELECT * FROM `" . DB_PREFIX . "customerpartner_to_feedback` WHERE seller_id='".(int)$customerid."'")->rows;

	 return count($avg);
	}
	public function getProductFeedbackList($customerid) {
		$query = $this->db->query("SELECT r.*,pd.name,r.text FROM " . DB_PREFIX . "customerpartner_to_product c2p INNER JOIN ".DB_PREFIX ."review r ON (c2p.product_id = r.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON (pd.product_id = c2p.product_id) WHERE c2p.customer_id = '".(int)$customerid."' AND pd.language_id = '".$this->config->get('config_language_id')."' AND r.status = 1 ");
		return $query->rows;
	}

	public function getTotalProductFeedbackList($customerid){
		$query = $this->db->query("SELECT r.* FROM " . DB_PREFIX . "customerpartner_to_product c2p INNER JOIN ".DB_PREFIX ."review r ON (c2p.product_id = r.product_id) WHERE c2p.customer_id = '".(int)$customerid."' AND r.status = 1 ");
		return count($query->rows);
	}


	public function saveFeedback($data,$seller_id){

		$result = $this->db->query("SELECT id FROM ".DB_PREFIX ."customerpartner_to_feedback WHERE customer_id = ".$this->customer->getId()." AND seller_id = '".(int)$seller_id."'")->row;

		if(!$result){
			$this->db->query("INSERT INTO ".DB_PREFIX ."customerpartner_to_feedback SET customer_id = '".$this->customer->getId()."',seller_id = '".(int)$seller_id."', feedprice = '".(int)$this->db->escape($data['price_rating'])."',feedvalue = '".$this->db->escape($data['value_rating'])."',feedquality = '".$this->db->escape($data['quality_rating'])."', nickname = '".$this->db->escape($data['name'])."',  review = '".$this->db->escape($data['text'])."', createdate = NOW(),status=0 ");
		}else{
			$this->db->query("UPDATE ".DB_PREFIX ."customerpartner_to_feedback set feedprice='".$this->db->escape($data['price_rating'])."',feedvalue='".$this->db->escape($data['value_rating'])."',feedquality='".$this->db->escape($data['quality_rating'])."', nickname='".$this->db->escape($data['name'])."', review='".$this->db->escape($data['text'])."',createdate = NOW(),status=0 WHERE id = '".$result['id']."'");
		}

	}

	public function getShopData($shop){
		$sql = $this->db->query("SELECT * FROM " . DB_PREFIX . "customerpartner_to_customer where companyname = '" .$this->db->escape($shop)."'")->row;
		if($sql)
			return false;
		return true;
	}
}
?>
