<?php
class ControllerExtensionModuleWkHotel extends Controller
{
    public function index()
    {
        $this->load->language('extension/module/wk_hotel_booking');
        $this->load->model('catalog/category');
        $this->load->model('catalog/product');
        $this->load->model('extension/module/wk_hotel_booking');
        $this->load->model('tool/image');

        if(isset($this->request->get['hotel_id']) && (int)$this->request->get['hotel_id']) {
            $category_id = (int)$this->request->get['hotel_id'];
        } else {
            $category_id = 0;
        }
        $this->document->addScript('catalog/view/javascript/hotel/handlebar.js');
        $this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');
  			$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');

        $data['breadcrumbs'][] = array(
                      'text' => $this->language->get('text_home'),
                      'href' => $this->url->link('common/home')
                  );
        $data['breadcrumbs'][] = array(
                  'text' => $this->language->get('text_home_search'),
                  'href' => $this->url->link('common/home')
          );
        $data['checkintime'] = isset($this->session->data['checkintime']) ? $this->session->data['checkintime'] :'';
      	$data['checkouttime'] = isset($this->session->data['checkouttime']) ? $this->session->data['checkouttime'] :'';

        $category_info = $this->model_catalog_category->getCategory($category_id);
        $data['mail_for'] = '&contact_seller=true';
        $data['send_mail'] = $this->url->link('account/customerpartner/sendmail','',true);
        $data['hotel_details'] =
        $this->model_extension_module_wk_hotel_booking->getHotelDetails((int)$category_id);
        $server = $this->request->server['HTTPS'] ? $this->config->get('config_ssl') : $this->config->get('config_url');

        $data['placeholder'] = $this->model_tool_image->resize('placeholder.png',100,100);

        $data['logged'] = $this->customer->isLogged();
        $data['account_login'] = $this->url->link('account/login','',true);
        if ($category_info && $data['hotel_details']) {

            $this->document->setTitle($category_info['meta_title']);

            $this->document->setDescription($category_info['meta_description']);

            $this->document->setKeywords($category_info['meta_keyword']);

            $data['heading_title'] = $category_info['name'];

            $data['breadcrumbs'][] = array(
                      'text' => $category_info['name'],
                      'href' => $this->url->link('extension/module/wk_hotel&hotel_id='.$category_id)
                  );
            if(!$data['logged']) {
               $this->session->data['redirect'] = $this->url->link('extension/module/wk_hotel&hotel_id='.$category_id,'',true);
            }
            $review_info = $this->model_extension_module_wk_hotel_booking->getReview($category_id);
            if($review_info){
              foreach ($review_info as $key => $value) {
                if ($value['image']) {
                	$review_info[$key]['image'] = $server.'image/customers/'.$value['image'];
              	} else {
                	 $review_info[$key]['image'] = $this->model_tool_image->resize('placeholder.png',200,200);
              	}

                $review_info[$key]['info'] = sprintf($this->language->get('text_review_info'),$value['customer_name'],date('F j, Y',strtotime($review_info[$key]['date'])));
              }
            }

            $data['review_info'] = $review_info;
            if($review_info && isset($review_info[0]) && isset($review_info[0]['rating'])) {
              $data['review_info_total'] = $review_info[0]['rating'];
            }
            $data['current'] =$this->url->link('extension/module/wk_hotel&hotel_id='.$category_id);
            if ($category_info['image']) {
              $data['popup'] = $this->model_tool_image->resize($category_info['image'], $this->config->get('theme_' . $this->config->get('config_theme') . '_image_popup_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_popup_height'));
                $data['thumb'] = $server.'image/'.$category_info['image'];
            } else {
                $data['popup'] = $this->model_tool_image->resize('placeholder.png', $this->config->get('theme_' . $this->config->get('config_theme') . '_image_popup_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_popup_height'));
                $data['thumb'] = $this->model_tool_image->resize('placeholder.png', 800, 280);
            }

            $data['description'] = html_entity_decode($category_info['description'], ENT_QUOTES, 'UTF-8');

            $data['products'] =array();

            $data['success'] = $this->url->link('checkout/cart','',true);

            $this->load->model('customerpartner/master');
            $id = $this->model_extension_module_wk_hotel_booking->getPartnerIdBasedonHotel($category_info['category_id']);
            $data['contact_mail'] = $this->config->get('module_wk_hotelbooking_res_customercontactseller');
            $this->document->addScript('https://maps.googleapis.com/maps/api/js?libraries=places&key='.$this->config->get('module_wk_hotelbooking_res_google_key'));


            $this->url->link('extension/module/wk_hotelbooking_res/getRooms','',true);

            if(isset($id) && isset($id['id']) && $id['id']) {

              $partner = $this->model_customerpartner_master->getProfile($id['id']);

              if($partner){

                $data['seller_id'] = $id['id'];

                $data['hotels'] = $this->model_extension_module_wk_hotel_booking->getSellerHotels($data['seller_id']);

                $data['feedback_total'] = $this->model_customerpartner_master->getAverageFeedback($data['seller_id']);

                $partner['sellerHref'] = $this->url->link('customerpartner/profile&id='.$id['id'],'','true');

                $data['collectionHref'] = $this->url->link('customerpartner/profile&id='.$id['id'],'&collection','true');
                $partner['name'] = $partner['firstname'].' '.$partner['lastname'];
                $partner['total_products'] = $this->model_customerpartner_master->getPartnerCollectionCount($id['id']);
                if ($partner['avatar'] && file_exists(DIR_IMAGE . $partner['avatar'])) {
                  $partner['thumb'] = $this->model_tool_image->resize($partner['avatar'],100,100);
                }else {
                  $partner['thumb'] = $this->model_tool_image->resize('no_image.png',100,100);
                }
                $data['partner'] = $partner;

                $data['displayName'] = $partner['firstname']." ".$partner['lastname'];


              }
            }
            if(isset($this->session->data['adult'])){
              $data['adult'] = $this->session->data['adult'];
            }else{
              $data['adult'] = 1;
            }
            if(isset($this->session->data['child'])){
              $data['child'] = $this->session->data['child'];
            }else{
              $data['child'] = 1;
            }
            if(isset($this->session->data['room'])){
              $data['room'] = $this->session->data['room'];
            }else{
              $data['room'] = 1;
            }

            $this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment.min.js');
      			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment-with-locales.min.js');
      			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
      			$this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');
            $data['hotel_id'] = $category_id;
            $data['placeholder']    = $this->model_tool_image->resize('placeholder.png', 100, 100);

            $data['footer'] = $this->load->controller('common/footer');
            $data['header'] = $this->load->controller('common/header');
            $this->response->setOutput($this->load->view('extension/module/wk_hotel', $data));
        } else {
            $this->document->setTitle($this->language->get('text_error'));

            $data['heading_title'] = $this->language->get('text_error');

            $data['text_error'] = $this->language->get('text_error');

            $data['button_continue'] = $this->language->get('button_continue');

            $data['continue'] = $this->url->link('common/home');

            $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['column_right'] = $this->load->controller('common/column_right');
            $data['content_top'] = $this->load->controller('common/content_top');
            $data['content_bottom'] = $this->load->controller('common/content_bottom');
            $data['footer'] = $this->load->controller('common/footer');
            $data['header'] = $this->load->controller('common/header');

            $this->response->setOutput($this->load->view('error/not_found', $data));
        }
    }

    public function getRooms() {
      $data['products'] = array();

      if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
        $hotel_id = $this->request->post['hotel_id'];
        $filter_array = array(
          'filter_category_id' => $hotel_id,
          'adult' => isset($this->request->post['adult']) ? $this->request->post['adult'] : null,
          'adult' => isset($this->request->post['adult']) ? $this->request->post['adult'] : null,
          'checkintime' => isset($this->request->post['checkintime']) ? $this->request->post['checkintime'] : null,
          'checkouttime' => isset($this->request->post['checkouttime']) ? $this->request->post['checkouttime'] : null,
          'child' => isset($this->request->post['child']) ? $this->request->post['child'] : null,
          'room' => isset($this->request->post['room']) ? $this->request->post['room'] : null,
        );
      } else {
        $filter_array = array();
      }

      $this->load->model('catalog/product');
      $this->load->model('tool/image');
      $this->load->model('extension/module/wk_hotel_booking');

      $server = $this->request->server['HTTPS'] ? $this->config->get('config_ssl') : $this->config->get('config_url');

      $results = $this->model_extension_module_wk_hotel_booking->getProducts($filter_array);
      $data['language'] = $this->load->language('product/product');
      $data['language'] = array_merge($data['language'],$this->load->language('extension/module/wk_hotel_booking'));

      $data['images'] = array();
      $data['products_booking_options']= array();
      foreach ($results as $result) {
          $room_image = array();
          if ($result['image']) {
              $image = $server.'image/'.$result['image'];
              $popup = $this->model_tool_image->resize($result['image'], $this->config->get('theme_' . $this->config->get('config_theme') . '_image_popup_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_popup_height'));
          } else {
              $image = $server.'image/'.'placeholder.png';
              $popup = $this->model_tool_image->resize('placeholder.png', $this->config->get('theme_' . $this->config->get('config_theme') . '_image_popup_width'), $this->config->get('theme_' . $this->config->get('config_theme') . '_image_popup_height'));
          }

          $related_images_result = $this->model_catalog_product->getProductImages($result['product_id']);

          foreach ($related_images_result as $resulta) {
              $data['images'][] = $room_image[] = array(
                        'popup' => $this->model_tool_image->resize($resulta['image'], 300, 300),
                        'thumb' => $this->model_tool_image->resize($resulta['image'], 300, 300)
                    );
          }
          if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
              $rprice = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
          } else {
              $rprice = false;
          }

          if ((float)$result['special']) {
              $special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
          } else {
              $special = false;
          }

          if ($this->config->get('config_tax')) {
              $tax = $this->currency->format((float)$result['special'] ? $result['special'] : $result['price'], $this->session->data['currency']);
          } else {
              $tax = false;
          }

          if ($this->config->get('config_review_status')) {
              $rating = (int)$result['rating'];
          } else {
              $rating = false;
          }
          //fixed facilitites

          $attributes = $this->model_extension_module_wk_hotel_booking->getProductAttributes($result['product_id']);

          $room_attributes = array();

          if ($attributes) {
              foreach ($attributes[0]['attribute'] as $key => $value) {
                  $attr_image_info = $this->model_extension_module_wk_hotel_booking->getFxfacilitiesinfo($value['attribute_id']);
                  if (isset($attr_image_info['facility_image']) && $attr_image_info['facility_image']) {
                      $attr_image = $server.'image/'.$attr_image_info['facility_image'];
                  } else {
                      $attr_image = $this->model_tool_image->resize('placeholder.png', 20, 20);
                  }
                  $room_attributes[] = array(
                            'name' => $value['name'],
                            'image'=>$attr_image
                            );
              }
          }
          $options= array();

          foreach ($this->model_catalog_product->getProductOptions($result['product_id']) as $option) {
            $product_option_value_data = array();

            foreach ($option['product_option_value'] as $option_value) {
              if (!$option_value['subtract'] || ($option_value['quantity'] > 0)) {
                if ((($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) && (float)$option_value['price']) {
                  $price = $this->currency->format($this->tax->calculate($option_value['price'], $result['tax_class_id'], $this->config->get('config_tax') ? 'P' : false), $this->session->data['currency']);
                } else {
                  $price = false;
                }
                if ($option_value['image']) {
                    $opimage = $this->model_tool_image->resize($option_value['image'], 20, 20);
                } else {
                    $opimage = $this->model_tool_image->resize('placeholder.png', 20, 20);
                }

                $product_option_value_data[] = array(
                  'product_option_value_id' => $option_value['product_option_value_id'],
                  'option_value_id'         => $option_value['option_value_id'],
                  'name'                    => $option_value['name'],
                  'image'                   => $opimage,
                  'price'                   => $price,
                  'price_prefix'            => $option_value['price_prefix']
                );
              }
            }

            $options[] = array(
              'product_option_id'    => $option['product_option_id'],
              'product_option_value' => $product_option_value_data,
              'option_id'            => $option['option_id'],
              'name'                 => $option['name'],
              'type'                 => $option['type'],
              'value'                => $option['value'],
              'required'             => $option['required']
            );
          }
          $booking_options = $this->model_extension_module_wk_hotel_booking->getTotalOptionData($result['product_id']);
          $booking_option_keys = array('booking_duration','booking_from','booking_to','booking_rate','booking_adult','booking_child');
          foreach ($booking_options as $key => $value) {
            if(isset($value['product_option_id'])) {
              $data['products_booking_options'][$result['product_id']][$booking_option_keys[$key]] = $value['product_option_id'];
            }
          }
          $data['products'][] = array(
                    'product_id'  => $result['product_id'],
                    'thumb'       => $image,
                    'popup'       => $popup,
                    'options'        => $options,
                    'attribute'      => $room_attributes,
                    'name'        => $result['name'],
                    'description' => utf8_substr(trim(strip_tags(str_replace("&nbsp;", "",html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8')))), 0, 300),
                    'price'       => $rprice,
                    'images'     => $room_image,
                    'special'     => $special,
                    'tax'         => $tax,
                    'minimum'     => $result['minimum'] > 0 ? $result['minimum'] : 1,
                    'rating'      => $result['rating'],
                    'reviews'     => sprintf($this->language->get('text_reviews'), (int)$result['reviews']),
                    'review_status' =>  $this->config->get('config_review_status'),
                    'review_guest' => ($this->config->get('config_review_guest') || $this->customer->isLogged()) ? true :false,
                    'attribute_groups' => $this->model_extension_module_wk_hotel_booking->getProductAttributes($result['product_id']),
                    'href'        => $this->url->link('product/product&product_id='.$result['product_id'],'',true)
                );
      }
      
      $this->response->addHeader('Content-Type:application/json');
      $this->response->setOutput(json_encode($data));
    }
    public function addResponse(){
    	$json = array();
    	if($this->request->server['REQUEST_METHOD'] == "POST"){
    		$name = $this->request->post['name'];
    		$email= $this->request->post['email'];
    		$response = $this->request->post['text'];
    		$image = $this->request->post['profile'];
    		$rating = $this->request->post['rating'];
    		$hotel_id= $this->request->post['hotel_id'];
    		$this->load->model('extension/module/wk_hotel_booking');
        $this->load->language('extension/module/wk_hotel_booking');

    			if(isset($this->request->files) && $this->request->files['image'] && isset($this->request->files['image']['tmp_name'])  && $this->request->files['image']['tmp_name']) {

      			$info = getimagesize($this->request->files['image']['tmp_name']);
      			if ($info === FALSE) {
      			   $json['error'] = "Unable to determine image type of uploaded file";
      			}
      			if (($info[2] !== IMAGETYPE_GIF) && ($info[2] !== IMAGETYPE_JPEG) && ($info[2] !== IMAGETYPE_PNG)) {
      			   $json['error'] = "Incorrect File Type";
      			}
      			is_dir(DIR_IMAGE .'customers') ?  '' : mkdir(DIR_IMAGE .'customers');
      			if($this->request->files['image']['tmp_name'] && $this->request->files['image']['name'] ){
      				$file = $this->request->files['image']['name'];
      				move_uploaded_file($this->request->files['image']['tmp_name'], DIR_IMAGE .'customers/'. $file);
      			}
    	    }
    	    if(!isset($json['error']) || !$json['error']){
    	      $this->model_extension_module_wk_hotel_booking->addResponse($name,$email,$response,$image,$rating,$hotel_id);
    	      $json['success'] = $this->language->get('text_review_submitted');
    	    }
    	    $this->response->addHeader('Content-Type: application/json');
    		$this->response->setOutput(json_encode($json));
    	}
    }

}
