<?php
class ControllerCommonhotelHeader extends Controller {
	public function index() {
		// Analytics
		$this->load->model('setting/extension');

		$data['analytics'] = array();

		$analytics = $this->model_setting_extension->getExtensions('analytics');

		foreach ($analytics as $analytic) {
			if ($this->config->get('analytics_' . $analytic['code'] . '_status')) {
				$data['analytics'][] = $this->load->controller('extension/analytics/' . $analytic['code'], $this->config->get('analytics_' . $analytic['code'] . '_status'));
			}
		}

		if ($this->request->server['HTTPS']) {
			$server = $this->config->get('config_ssl');
		} else {
			$server = $this->config->get('config_url');
		}

		if (is_file(DIR_IMAGE . $this->config->get('config_icon'))) {
			$this->document->addLink($server . 'image/' . $this->config->get('config_icon'), 'icon');
		}

		$data['title'] = $this->document->getTitle();

		$data['base'] = $server;
		$data['description'] = $this->document->getDescription();
		$data['keywords'] = $this->document->getKeywords();
		$data['links'] = $this->document->getLinks();
		$data['styles'] = $this->document->getStyles();
		$data['scripts'] = $this->document->getScripts('header');
		$data['lang'] = $this->language->get('code');
		$data['direction'] = $this->language->get('direction');

		$data['name'] = $this->config->get('config_name');

		if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
			$data['logo'] = $server . 'image/' . $this->config->get('config_logo');
		} else {
			$data['logo'] = '';
		}

		$this->load->language('common/header');


		$data['text_logged'] = sprintf($this->language->get('text_logged'), $this->url->link('account/account', '', true), $this->customer->getFirstName(), $this->url->link('account/logout', '', true));

		$data['home'] = $this->url->link('common/home');
        $data['wishlist'] = $this->url->link('account/wishlist', '', true);
        $data['logged'] = $this->customer->isLogged();
        $data['account'] = $this->url->link('account/account', '', true);
        $data['register'] = $this->url->link('account/register', '', true);
        $data['login'] = $this->url->link('account/login', '', true);
        $data['order'] = $this->url->link('account/order', '', true);
        $data['transaction'] = $this->url->link('account/transaction', '', true);
        $data['download'] = $this->url->link('account/download', '', true);
        $data['logout'] = $this->url->link('account/logout', '', true);
        $data['shopping_cart'] = $this->url->link('checkout/cart');
        $data['checkout'] = $this->url->link('checkout/checkout', '', true);
        $data['central'] = $this->url->link('customerpartner/central','',true);

		$data['text_list_hotel'] = 'List Your Hotel';
    $data['text_menu_hotel'] = 'Booking Menu';
		$this->load->model('account/customerpartner');
		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();
		if(!$data['chkIsPartner']) {
			$chk = $this->db->query("SELECT * FROM ".DB_PREFIX."customerpartner_to_customer WHERE customer_id ='".$this->customer->getId()."'")->row;
			if($chk) {
				$data['text_list_hotel'] = 'Pending Host Approval';
				$data['central'] = $this->url->link('account/account','',true);
			}

		}
		$data['st_controller'] = 0;
		if(isset($this->request->get['route']) && (substr($this->request->get['route'],0,8)=='account/')) {
			//LOAD LANGUAGE
			 $this->language->load('extension/module/wk_hotel_booking');
			//Modal heading
		 $data['st_controller'] = 1;
			$this->load->model('catalog/product');
			$this->load->model('extension/module/wk_hotel_booking');
			$data['logged'] = $this->customer->isLogged();
			$this->load->model('account/customerpartner');
			$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();
			if($data['chkIsPartner']===0) {
				$data['text_becomePartner'] = $this->language->get('text_alreadyrequest');
			} else {
				$data['text_becomePartner'] = $this->language->get('text_becomePartner');
			}

			$data['send_mail'] = $this->url->link('account/customerpartner/sendmail','',true);
			$data['partners']	= $this->url->link('customerpartner/sell','',true);
			$data['mail_for'] = '&contact_admin=true';

			$data['account_menus'] = array();

			if($this->config->get('module_wk_hotelbooking_res_accmenuseq') && $this->model_account_customerpartner->chkIsPartner()) {

				$data['seller_id'] = $this->customer->getId();
				$data['partner'] = true;

				$data['mphotel_allowed_account_menu'] = $this->config->get('module_wk_hotelbooking_res_allowedaccmenu');
				$data['account_menu_href'] = array(
					'profile' => $this->url->link('account/customerpartner/profile', '', true),
					'dashboard' => $this->url->link('account/customerpartner/dashboard', '', true),
					'transaction' => $this->url->link('account/customerpartner/transaction', '', true),
					'addhotel' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', '', true),
					'addroom' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true),
					'addfxfacility' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility', '', true),
					'addopfacility' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_opfacility', '', true),
					'hotelreview' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_review', '', true),
					'allbookings' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res', '', true),
					'query'	=> $this->url->link('account/customerpartner/query', '',true),
					'asktoadmin' =>'',
				);

				if(isset($data['mphotel_allowed_account_menu']) && $data['mphotel_allowed_account_menu']) {
					foreach ($data['account_menu_href'] as $key => $value) {
						if(in_array($key,$data['mphotel_allowed_account_menu'])) {
							$data['account_menus'][$key] = $value;
						}
					}
				}
			}
		}

		$server = $this->request->server['HTTPS']  ? $this->config->get('config_ssl') : $this->config->get('config_url');
		$data['cart_count'] = $this->cart->countProducts();
		$data['language'] = $this->load->controller('common/language');
		$data['search'] = $this->load->controller('common/search');
		$data['cart'] = $this->load->controller('common/cart');
		$data['menu'] = $this->load->controller('common/menu');
    $this->load->model('tool/image');

    if($this->config->get('module_wk_hotelbooking_res_header')){
        $data['background_image'] = $server."image/".$this->config->get('module_wk_hotelbooking_res_header');
    } else {
			$data['background_image'] = $server."image/".'catalog/head.png';
		}
		$data['route'] = isset($this->request->get['route']) ? $this->request->get['route'] : 'common/home';
		return $this->load->view('common/hotel_header	', $data);
	}
}
