<?php
// Text
$_['text_list_hotel']          = 'List Your Hotel';
$_['text_list_hotel_pending']  = 'Pending Host Approval';
