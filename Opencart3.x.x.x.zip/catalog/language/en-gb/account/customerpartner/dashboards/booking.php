<?php
// Heading
$_['heading_title'] 			= 'Booking Information';

$_['text_order']    			= 'Orders';
$_['text_sale']    		 		= 'Sales';

$_['text_room']    			    = 'Room';
$_['text_avail']	 			= 'Available Room';

$_['text_total_room']			= 'Total Room';

$_['text_booked_room'] 			= 'Total Booking';
$_['text_from'] 				= 'From';
$_['text_till']					= 'Till';

$_['text_info']					= 'Information';
$_['text_detail']				= 'Details';

$_['text_from']					= 'Booking From';
$_['text_till']					= 'Booking Till';

$_['text_customer_name']		= 'Customer Name';
$_['text_quantity']				= 'Quantity';

$_['text_room']					= 'Room';
