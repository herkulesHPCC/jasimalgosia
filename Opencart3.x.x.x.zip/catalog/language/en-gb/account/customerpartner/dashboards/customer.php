<?php
// Heading
$_['heading_title'] = 'Total Buyers';

// Text
$_['text_view'] = 'View more...';