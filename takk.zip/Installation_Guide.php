###################################################################################################################################
##																																                                                               ##
##			INSTALLATION INFORMATION(STEP) FOR OPENCART MARKETPLACE HOTEL BOOKING AND RESERVATION MODULE						                 ##
##							                         (Version 2.0.0)																						                                                       ##
##																																                                                               ##
##																																                                                               ##
##																																                                                               ##
###################################################################################################################################

Manual Installation:

1) Unzip the main module directory.

2) Upload admin, catalog, image directories into your opencart's root directory.

3) After uploading directories, go to your browser run opencart and login admin side. Go to Extensions->Extension Installer upload that wkmphotelbooking.zip which are present under the OCMOD folder.

4) After uploading xml file goto Admin->Extensions->Modification Refresh the content by clicking the upper right button.

5) Now install module Admin->Extension->Extension->module(Marketplace Hotel Booking and Reservation,Marketplace Hotel Booking and Reservation Search, Advance Layer Navigation, Popular Hotel).

6) Set the Advance Layer navigation and Marketplace Hotel Search Module at the column left of category page from the Desing > Layout >category(edit).

7) Create a new layout by named Hotel Home from Design >  Layout  and add button at the top

  Layout name : Hotel Home
  Route       : common/hotel_home

  And set the Marketplace Hotel Search at content Top and Popular Hotels at content bottom.

8) Goto users->users group and edit desire group(specially admin) and then give access and modify permission to all the uploaded files
