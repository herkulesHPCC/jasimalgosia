<?php
//Reviews
// Heading
$_['heading_title']							= 'Hosts Review';
$_['review_heading_title']     				= 'Reviews';

// Text
$_['text_review_success']      				= 'Success: You have modified reviews!';
$_['text_review_list']         				= 'Host Review List';

$_['text_review_edit']         				= 'Edit Host Review';

// Column
$_['column_review_product']    				= 'Host';
$_['column_review_author']     				= 'Author';
$_['column_review_rating']     				= 'Rating';
$_['column_review_status']     				= 'Status';
$_['column_date_added'] 	   				= 'Date Added';
$_['column_action']     	   				= 'Action';

$_['column_owner']							= 'Owner';

// Entry
$_['entry_review_product']     				= 'Host';
$_['entry_review_author']      				= 'Author';
$_['entry_rating']      	   				= 'Rating';
$_['entry_review_status']     				= 'Status';
$_['entry_review_text']        				= 'Text';
$_['entry_date_added']  	   				= 'Date Added';
$_['entry_author']			   				= 'Customer';

$_['entry_text']							= 'Review';
$_['entry_status']							= 'Status';

$_['entry_price']							= 'Price';
$_['entry_value']							= 'Value';
$_['entry_quality']							= 'Quality';

$_['error_value']							= 'Value must be between 1 to 5';
$_['error_price']							= 'Price must be between 1 to 5';
$_['error_quality']							= 'Quality must be between 1 to 5';
$_['error_permission']         = 'Warning: You do not have permission to modify Reviews!';
?>
