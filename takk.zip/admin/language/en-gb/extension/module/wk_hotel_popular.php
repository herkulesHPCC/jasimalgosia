<?php
// Heading
$_['heading_title']    = 'Popular Hotels';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified popular hotels module!';
$_['text_edit']        = 'Edit Popular Hotels Module';

// Entry
$_['entry_status']     = 'Status';
$_['entry_hotel']      = 'Popular Hotels';
$_['help_hotel']       = 'Add the popular hotels which will show at front end home page';
$_['module_info']      = 'This module will show only 6 random popular enabled hotels which are added here';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify popular hotels module!';
