<?php

class ControllerCatalogWkhotelbookingbooking extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/wk_hotelbooking_hotels');
		$this->document->setTitle($this->language->get('booking_heading_title'));
		$this->load->model('catalog/wk_hotelbooking_hotels');

		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('booking_heading_title'),
			'href'      => $this->url->link('catalog/wk_hotelbooking_booking', '&user_token=' . $this->session->data['user_token'] , 'true'),
   		);

   		$data['hotels'] = $this->model_catalog_wk_hotelbooking_hotels->getHotels();
		$data['user_token'] = $this->session->data['user_token'];

		$data['action'] = $this->url->link('catalog/wk_hotelbooking_booking/manualBooking', 'user_token=' . $this->session->data['user_token'], 'true');





   		$data['store_url'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
   		$data['user_token'] = $this->session->data['user_token'];
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_booking',$data));
	}
	public function getRooms(){
		if($this->request->server['REQUEST_METHOD'] == 'POST'){
			$hotel_id = $this->request->post['hotel_id'];
			$this->load->model('catalog/wk_hotelbooking_hotels');
			$rooms = $this->model_catalog_wk_hotelbooking_hotels->getRoomOfHotel($hotel_id);
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($rooms));
		}
	}

	public function updateQuantity($data){
		$del=$this->db->query("DELETE FROM ".DB_PREFIX."wk_booking_quantity WHERE product_id='".$data['product_id']."'AND customer_id='".(int)$this->customer->getId()."'AND options= '".$data['options']."'");
		$this->db->query("INSERT " . DB_PREFIX . "wk_booking_quantity SET customer_id = '" . (int)$this->customer->getId() . "', product_id = '" . $data['product_id'] ."', quantity = '" . $data['hours'] . "',options = '".$data['options']."'");
	}


  	public function manualBooking(){

  		if(!isset($this->request->post['room'])){
  			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_booking', 'user_token=' . $this->session->data['user_token'], 'true'));
  		}

  		$this->document->addScript("view/javascript/hotel/jquery-ui-1.10.4.custom.js");

  		$id = $this->request->post['room'];


		$this->load->model('catalog/product');
		$this->load->model('catalog/wk_hotelbooking_hotels');


		$data['product_info']= $this->model_catalog_product->getProduct($id);
		$data['product_info']['price'] = $this->currency->format($data['product_info']['price'],$this->config->get('config_currency'));
		$product_options= $this->model_catalog_product->getProductOptions($id);
		$this->load->model('catalog/option');
		foreach ($product_options as $key => $value) {
			$i=0;
			foreach ($product_options[$key]['product_option_value'] as $product_option_value) {
				if(isset($product_option_value['option_value_id'])) {
					$option_value_info = $this->model_catalog_option->getOptionValue($product_option_value['option_value_id']);
					if ($option_value_info) {
						$product_option_value_data[$i] = array(
						'product_option_value_id' => $product_option_value['product_option_value_id'],
						'option_value_id'         => $product_option_value['option_value_id'],
						'name'                    => $option_value_info['name'],
						'price'                   => (float)$product_option_value['price'] ? $this->currency->format($product_option_value['price'], $this->config->get('config_currency')) : false,
						'price_prefix'            => $product_option_value['price_prefix']
						);
					}
					$product_options[$key]['product_option_value']= $product_option_value_data;
					$i++;
				}

		 	}

		}
		$data['product_options'] = $product_options;


      	$this->load->language('catalog/wk_hotelbooking_hotels');
      	$this->document->setTitle($this->language->get('booking_information'));

		$data['user_token'] = $this->session->data["user_token"];
		// $data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
      		'separator' => false
   		);
   		$data['duration'] = $this->config->get('wk_hotelbooking_options0');
   		$data['rate'] = $this->config->get('wk_hotelbooking_options1');
   		$data['ffrom'] = $this->config->get('wk_hotelbooking_options2');
   		$data['to'] = $this->config->get('wk_hotelbooking_options3');
   		$data['adult'] = $this->config->get('wk_hotelbooking_options4');
   		$data['child'] = $this->config->get('wk_hotelbooking_options5');
   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('booking_information'),
			'href'      => $this->url->link('catalog/wk_hotelbooking_booking', '&user_token=' . $this->session->data['user_token'] , 'true'),
      		'separator' => ' :: '
   		);
 		$this->load->model('catalog/category');
		$url = '';
		$data['order_id'] = 0;
		$data['store_id'] = '';
		$data['store_url'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;


		$data['customer'] = '';
		$data['customer_id'] = '';
		$data['customer_group_id'] = $this->config->get('config_customer_group_id');
		$data['firstname'] = '';
		$data['lastname'] = '';
		$data['email'] = '';
		$data['telephone'] = '';
		$data['fax'] = '';
		$data['customer_custom_field'] = array();

		$data['addresses'] = array();

		$data['payment_firstname'] = '';
		$data['payment_lastname'] = '';
		$data['payment_company'] = '';
		$data['payment_address_1'] = '';
		$data['payment_address_2'] = '';
		$data['payment_city'] = '';
		$data['payment_postcode'] = '';
		$data['payment_country_id'] = '';
		$data['payment_zone_id'] = '';
		$data['payment_custom_field'] = array();
		$data['payment_method'] = '';
		$data['payment_code'] = '';

		$data['shipping_firstname'] = '';
		$data['shipping_lastname'] = '';
		$data['shipping_company'] = '';
		$data['shipping_address_1'] = '';
		$data['shipping_address_2'] = '';
		$data['shipping_city'] = '';
		$data['shipping_postcode'] = '';
		$data['shipping_country_id'] = '';
		$data['shipping_zone_id'] = '';
		$data['shipping_custom_field'] = array();
		$data['shipping_method'] = '';
		$data['shipping_code'] = '';

		$data['order_products'] = array();
		$data['order_vouchers'] = array();
		$data['order_totals'] = array();

		$data['order_status_id'] = $this->config->get('config_order_status_id');
		$data['comment'] = '';
		$data['affiliate_id'] = '';
		$data['affiliate'] = '';
		$data['currency_code'] = $this->config->get('config_currency');

		$data['coupon'] = '';
		$data['voucher'] = '';
		$data['reward'] = '';
		$this->load->model('setting/store');

		$data['stores'] = array();

		$data['stores'][] = array(
			'store_id' => 0,
			'name'     => $this->language->get('text_default'),
		);

		$results = $this->model_setting_store->getStores();

		foreach ($results as $result) {
			$data['stores'][] = array(
				'store_id' => $result['store_id'],
				'name'     => $result['name']
			);
		}

		// Customer Groups
		$this->load->model('customer/customer_group');

		$data['customer_groups'] = $this->model_customer_customer_group->getCustomerGroups();

		// Custom Fields
		$this->load->model('customer/custom_field');

		$data['custom_fields'] = array();
		$custom_fields = $this->model_customer_custom_field->getCustomFields();

		foreach ($custom_fields as $custom_field) {
			$data['custom_fields'][] = array(
				'custom_field_id'    => $custom_field['custom_field_id'],
				'custom_field_value' => $this->model_customer_custom_field->getCustomFieldValues($custom_field['custom_field_id']),
				'name'               => $custom_field['name'],
				'value'              => $custom_field['value'],
				'type'               => $custom_field['type'],
				'location'           => $custom_field['location'],
				'sort_order'         => $custom_field['sort_order']
			);
		}

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$this->load->model('localisation/country');

		$data['countries'] = $this->model_localisation_country->getCountries();

		$this->load->model('localisation/currency');

		$data['currencies'] = $this->model_localisation_currency->getCurrencies();

		$data['voucher_min'] = $this->config->get('config_voucher_min');

		$this->load->model('sale/voucher_theme');

		$data['voucher_themes'] = $this->model_sale_voucher_theme->getVoucherThemes();

		// API login
		$this->load->model('user/api');

		$api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));

		if ($api_info && $this->user->hasPermission('modify', 'sale/order')) {
			$session = new Session($this->config->get('session_engine'), $this->registry);

			$session->start();

			$this->model_user_api->deleteApiSessionBySessonId($session->getId());

			$this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);

			$session->data['api_id'] = $api_info['api_id'];

			$data['api_token'] = $session->getId();
		} else {
			$data['api_token'] = '';
		}
		$data['catalog'] = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
		$data['booking_adult'] = $data['booking_child'] = 0;
		$data['booking_from'] = $this->request->post['from'];
		$data['booking_till'] = $this->request->post['till'];
		if(isset($this->request->post['adult']))
			$data['booking_adult'] = $this->request->post['adult'];
		if(isset($this->request->post['child']))
			$data['booking_child'] = $this->request->post['child'];
		$data['booking_rate'] = $data['product_info']['price'];
		$data['booking_quantity'] = $this->request->post['quantity'];

		$diff = abs(strtotime($data['booking_till']) - strtotime($data['booking_from']));

		$days = $diff/(24*60*60);

		$data['booking_duration'] = $days;

		// $data['name'] = $data['product_info']['name'];
		// $data['price'] = $data['product_info']['price'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_manual',$data));

  		}
  		public function updateBooking(){
	  		$this->load->model('catalog/wk_hotelbooking_hotels');
	  		$ementies = json_encode(array('admin_booking'));
	  		$this->model_catalog_wk_hotelbooking_hotels->updateBooking($this->request->post['product_id'],$this->request->post['order_id'],$this->request->post['from_date'],$this->request->post['to_date'],$this->request->post['quant'],$this->request->post['name'],$this->request->post['email'],$this->request->post['telephone'],$ementies);
	  		$this->cart->clear();
  		}
  		public function getBookedSlots(){
  			$this->load->model('catalog/wk_hotelbooking_hotels');
  			$room_id = $this->request->post['room_id'];
  			$from = $this->request->post['from'];
  			$till = $this->request->post['to'];
  			$json = array();
  			$bookedSlots = $this->model_catalog_wk_hotelbooking_hotels->getBookedSlots($room_id,$from,$till);
  			if(empty($bookedSlots)) {

			} else {
			foreach($bookedSlots as $key=>$value){
					$json= $bookedSlots;
			}
		}
  			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));
  		}
}
