<?php

class ControllerCatalogWkhotelbookingRoom extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('catalog/wk_hotelbooking_hotels');
		$this->document->setTitle($this->language->get('room_heading_title'));
		$this->getList();
	}
	public function getList() {
		$this->load->model('catalog/wk_hotelbooking_hotels');
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'true'),
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('room_heading_title'),
			'href'      => $this->url->link('catalog/wk_hotelbooking_room', '&user_token=' . $this->session->data['user_token'] , 'true'),
   		);
   	if(isset($this->request->get['sort'])){
			$data['sort'] = $sort = $this->request->get['sort'];
		}else{
			$sort = null;
		}
		if(isset($this->request->get['name'])){
			$data['name'] = $name = $this->request->get['name'];
		}else{
			$name = null;
		}
		if(isset($this->request->get['status'])){
			$data['status'] = $status = $this->request->get['status'];
		}else{
			$status = null;
		}
		if(isset($this->request->get['rname'])){
			$data['rname'] = $rname = $this->request->get['rname'];
		}else{
			$rname = null;
		}
		if(isset($this->request->get['price'])){
			$data['price'] = $price = $this->request->get['price'];
		}else{
			$price = null;
		}
		if(isset($this->request->get['order'])){
			$data['order'] = $order = $this->request->get['order'];
		}else{
			$order = null;
		}
		if(isset($this->request->get['type'])){
			$data['type'] = $type = $this->request->get['type'];
		}else{
			$type = null;
		}

		$limit = $this->config->get('config_limit_admin');

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
			$page = 1;
		}
		$filterValues = array(
				'sort'	=> $sort,
				'name'	=> $name,
				'order'	=> $order,
				'status'	=> $status,
				'rname'	=> $rname,
				'price' => $price,
				'start'	=> $start,
				'end'	=> $end,
				'type'	=> $type
		);
   		$rooms = $this->model_catalog_wk_hotelbooking_hotels->getRooms($filterValues);
  		$total_room = $this->model_catalog_wk_hotelbooking_hotels->getTotoalRooms($filterValues);
  		$this->load->model('customer/customer');
   		$data['rooms'] =array();
   		$this->load->model('tool/image');

   		if(!empty($rooms)) {
	   		foreach ($rooms as $result) {
	   			if($result['owner']) {
					$owner_name = $this->model_customer_customer->getCustomer($result['owner']);
					if($owner_name && isset($owner_name['firstname'])) {
						$owner_name = $owner_name['firstname'].' '.$owner_name['lastname'];
						$ownerr = $result['owner'];
						$approve_action = true;
					}
					else {
						$owner_name = 'Admin';
						$ownerr = 0;
						$approve_action = false;
					}
				} else {
					$owner_name = 'Admin';
					$ownerr = 0;
					$approve_action = false;
				}
				if (is_file(DIR_IMAGE . $result['image'])) {
					$image = $this->model_tool_image->resize($result['image'], 60, 60);
				} else {
					$image = $this->model_tool_image->resize('no_image.png', 60, 60);
				}
				$data['rooms'][] = array(
					'room_id' => $result['room_id'],
					'image'      => $image,
					'name'       => $result['name'],
					'status'  	 => $result['status'],
					'price'      => $result['price'],
					'hotel_name' => $result['hotel_name'],
					'owner'		 => $owner_name,
					'ownerr'      => $ownerr,
					'approve'	 => $approve_action,
					'is_approve' => $result['approve'],
					'edit'       => $this->url->link('catalog/wk_hotelbooking_room/edit', 'user_token=' . $this->session->data['user_token'] . '&room_id=' . $result['room_id'], true)
				);
			}
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		$pagination = new Pagination();
		$pagination->total = $total_room;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('catalog/wk_hotelbooking_room', 'user_token=' . $this->session->data['user_token'] . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($total_room) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($total_room - $this->config->get('config_limit_admin'))) ? $total_room : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $total_room, ceil($total_room / $this->config->get('config_limit_admin')));
		$data['user_token'] = $this->session->data['user_token'];
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		$data['add']	=	$this->url->link('catalog/wk_hotelbooking_room/add', 'user_token='.$this->session->data['user_token'],true);
		$data['delete']	=	$this->url->link('catalog/wk_hotelbooking_room/delete', 'user_token='.$this->session->data['user_token'],true);
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_room_list',$data));
	}

	public function add() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('room_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {

			$postData = $this->setDefaultValue($this->request->post);

			$this->load->model('catalog/product');
			if($this->validateForm($postData)) {
				$product_id = $this->model_catalog_product->addProduct($postData);

				$this->model_catalog_wk_hotelbooking_hotels->addRoom($product_id , $postData);

				$this->session->data['success'] = $this->language->get('text_room_success');
				$this->response->redirect($this->url->link('catalog/wk_hotelbooking_room', 'user_token=' . $this->session->data['user_token'] , true));
		   }
		}
		$this->getForm();
	}
	public function edit() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('room_heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {

			$postData = $this->setDefaultValue($this->request->post);

			$this->load->model('catalog/product');

			if($this->validateForm($postData)) {

				$this->model_catalog_product->editProduct($this->request->get['room_id'],$postData);

				$this->model_catalog_wk_hotelbooking_hotels->editRoom($this->request->get['room_id'], $postData);

				$this->session->data['success'] = $this->language->get('text_room_success');

				$this->response->redirect($this->url->link('catalog/wk_hotelbooking_room', 'user_token=' . $this->session->data['user_token'], true));
			}
		}
		$this->getForm();
	}
	public function getForm() {
		$data['text_form'] = !isset($this->request->get['room_id']) ? $this->language->get('text_room_add') : $this->language->get('text_room_edit');


		$this->load->model('catalog/wk_hotelbooking_hotels');
		if(isset($this->request->get['room_id'])) {
			$room_info =  $this->model_catalog_wk_hotelbooking_hotels->getRoom($this->request->get['room_id']);
		}

		$this->load->model('localisation/language');
		$this->load->model('catalog/product');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}

		if (isset($this->error['meta_title'])) {
			$data['error_meta_title'] = $this->error['meta_title'];
		} else {
			$data['error_meta_title'] = array();
		}

		if (isset($this->error['model'])) {
			$data['error_model'] = $this->error['model'];
		} else {
			$data['error_model'] = '';
		}
		if (isset($this->error['from'])) {
			$data['error_from'] = $this->error['from'];
		} else {
			$data['error_from'] = '';
		}
		if (isset($this->error['till'])) {
			$data['error_till'] = $this->error['till'];
		} else {
			$data['error_till'] = '';
		}
		if (isset($this->error['price'])) {
			$data['error_price'] = $this->error['price'];
		} else {
			$data['error_price'] = '';
		}

		if (isset($this->error['quantity'])) {
			$data['error_quantity'] = $this->error['quantity'];
		} else {
			$data['error_quantity'] = '';
		}

		if (isset($this->error['max_adult'])) {
			$data['error_max_adult'] = $this->error['max_adult'];
		} else {
			$data['error_max_adult'] = '';
		}

		if (isset($this->error['max_child'])) {
			$data['error_max_child'] = $this->error['max_child'];
		} else {
			$data['error_max_child'] = '';
		}

		if (isset($this->request->post['product_description'])) {
			$data['product_description'] = $this->request->post['product_description'];
		} elseif (isset($this->request->get['room_id'])) {
			$data['product_description'] = $this->model_catalog_product->getProductDescriptions($this->request->get['room_id']);
		} else {
			$data['product_description'] = array();
		}

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (isset($room_info) && $room_info && $room_info['status']){
			$data['status'] = $room_info['status'];
		}  else {
			$data['status'] = '';
		}
		if (isset($this->request->post['from'])) {
			$data['from'] = $this->request->post['from'];
		} elseif (isset($room_info) && $room_info && $room_info['start_from']){
			$data['from'] = $room_info['start_from'];
		}  else {
			$data['from'] = '';
		}
		if (isset($this->request->post['till'])) {
			$data['till'] = $this->request->post['till'];
		} elseif (isset($room_info) && $room_info && $room_info['till']){
			$data['till'] = $room_info['till'];
		}  else {
			$data['till'] = '';
		}
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (isset($room_info) && $room_info && $room_info['status']){
			$data['status'] = $room_info['status'];
		}  else {
			$data['status'] = '';
		}
		if (isset($this->request->post['price'])) {
			$data['price'] = $this->request->post['price'];
		} elseif (isset($room_info) && $room_info && $room_info['price']){
			$data['price'] = $room_info['price'];
		}  else {
			$data['price'] = '';
		}
		if (isset($this->request->post['quantity'])) {
			$data['quantity'] = $this->request->post['quantity'];
		} elseif (isset($room_info) && $room_info && $room_info['quantity']){
			$data['quantity'] = $room_info['quantity'];
		}  else {
			$data['quantity'] = 0;
		}
		if (isset($this->request->post['max_adult'])) {
			$data['max_adult'] = $this->request->post['max_adult'];
		} elseif (isset($room_info) && $room_info && $room_info['max_adult']){
			$data['max_adult'] = $room_info['max_adult'];
		}  else {
			$data['max_adult'] = '';
		}
		if (isset($this->request->post['max_child'])) {
			$data['max_child'] = $this->request->post['max_child'];
		} elseif (isset($room_info) && $room_info && $room_info['max_child']){
			$data['max_child'] = $room_info['max_child'];
		}  else {
			$data['max_child'] = '';
		}
		if (isset($room_info) && $room_info && $room_info['hotel_id']){
			$data['hotel_id'] = $room_info['hotel_id'];
		}  else {
			$data['hotel_id'] = '';
		}
		$this->load->model('tool/image');
		if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
			$data['image'] = $this->request->post['image'];
		} elseif (isset($room_info) && $room_info && $room_info['image'] && is_file(DIR_IMAGE . $room_info['image'] )){
			$data['thumb'] = $this->model_tool_image->resize($room_info['image'] , 100, 100);
			$data['image'] = $room_info['image'];
		}  else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
			$data['image'] = '';
		}

		$hotels =  $this->model_catalog_wk_hotelbooking_hotels->getHotels();
		foreach ($hotels as $hotel) {
			$data['hotels'][] = array(
				'category_id' => $hotel['category_id'],
				'name' => $hotel['name']
				);
		}
		// Attributes
		$this->load->model('catalog/attribute');

		if (isset($this->request->post['product_attribute'])) {
			$product_attributes = $this->request->post['product_attribute'];
		} elseif (isset($this->request->get['room_id'])) {
			$product_attributes = $this->model_catalog_product->getProductAttributes($this->request->get['room_id']);
		} else {
			$product_attributes = array();
		}
		if (isset($this->request->post['product_image'])) {
			$product_images = $this->request->post['product_image'];
		} elseif (isset($this->request->get['room_id'])) {
			$product_images = $this->model_catalog_product->getProductImages($this->request->get['room_id']);
		} else {
			$product_images = array();
		}
		$data['product_images'] = array();

		foreach ($product_images as $product_image) {
			if (is_file(DIR_IMAGE . $product_image['image'])) {
				$image = $product_image['image'];
				$thumb = $product_image['image'];
			} else {
				$image = '';
				$thumb = 'no_image.png';
			}

			$data['product_images'][] = array(
				'image'      => $image,
				'thumb'      => $this->model_tool_image->resize($thumb, 100, 100),
				'sort_order' => $product_image['sort_order']
			);
		}
		$data['product_attributes'] = array();

		$this->load->model('catalog/option');
		$data['optionals'] = $this->model_catalog_option->getOptionValues($this->config->get('wk_hotelbookingopt_optionid'));

		foreach ($product_attributes as $product_attribute) {
			$attribute_info = $this->model_catalog_attribute->getAttribute($product_attribute['attribute_id']);

			if ($attribute_info) {
				$data['product_attributes'][] = array(
					'attribute_id'                  => $product_attribute['attribute_id'],
					'name'                          => $attribute_info['name'],
					'product_attribute_description' => $product_attribute['product_attribute_description']
				);
			}
		}

		$this->load->model('catalog/category');

		if (isset($this->request->post['product_category'])) {
			$categories = $this->request->post['product_category'];
		} elseif (isset($this->request->get['room_id'])) {
			$categories = $this->model_catalog_product->getProductCategories($this->request->get['room_id']);
		} else {
			$categories = array();
		}

		$data['product_categories'] = array();

		foreach ($categories as $category_id) {
			$category_info = $this->model_catalog_category->getCategory($category_id);

			if ($category_info) {
				$data['product_categories'][] = array(
					'category_id' => $category_info['category_id'],
					'name' => ($category_info['path']) ? $category_info['path'] . ' &gt; ' . $category_info['name'] : $category_info['name']
				);
			}
		}
		$data['product_option_id'] = '';

		if (isset($this->request->post['product_option'])) {
			$product_option = $this->request->post['product_option'];
		} elseif (isset($this->request->get['room_id'])) {
			$product_option = $this->model_catalog_product->getProductOptions($this->request->get['room_id']);
		} else {
			$product_option = array();
		}
		$data['user_token'] = $this->session->data['user_token'];
		if(isset($product_option) ) {
			foreach ($product_option as $key => $value) {
				if($value['option_id']==$this->config->get('wk_hotelbookingopt_optionid')) {

					if(isset($value['product_option_value']) && $value['product_option_value']){
						foreach ($value['product_option_value'] as $key1 => $value1) {
							foreach ($data['optionals'] as $key2 => $value2) {
								if($value1['option_value_id'] == $value2['option_value_id']){
									$product_option[$key]['product_option_value'][$key1]['status'] = 1;
								}
							}
						}
					}
					$data['product_option_id'] = $product_option[$key]['product_option_id'];
					$data['product_option_value'] = $product_option[$key]['product_option_value'];
					$data['option_values'][$product_option[$key]['option_id']] = $this->model_catalog_option->getOptionValues($product_option[$key]['option_id']);
				}
			}

		}
		else
			$data['product_option_value'] = array();

		$temp_array = array();
		if(isset($data['product_option_value']) && $data['product_option_value']) {
			foreach ($data['optionals'] as $key1 => $value1) {
				foreach ($data['product_option_value'] as $key2 => $value2) {
					if(isset($value2['option_value_id']) && isset($value1['option_value_id']) && $value2['option_value_id'] == $value1['option_value_id'])
						$temp_array[$key1] = $value2;

				}
			}
		}
		$data['product_option_value'] = $temp_array;


		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('room_heading_title'),
			'href' => $this->url->link('catalog/wk_hotelbooking_room', 'user_token=' . $this->session->data['user_token'], true)
		);

		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();

		$data['cancel'] = $this->url->link('catalog/wk_hotelbooking_room', 'user_token=' . $this->session->data['user_token'] , true);

		$data['user_token'] = $this->session->data['user_token'];

		if (!isset($this->request->get['room_id'])) {
			$data['action'] = $this->url->link('catalog/wk_hotelbooking_room/add', 'user_token=' . $this->session->data['user_token'], true);
		} else {
			$data['action'] = $this->url->link('catalog/wk_hotelbooking_room/edit', 'user_token=' . $this->session->data['user_token'] .'&room_id='.$this->request->get['room_id'] , true);
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('catalog/wk_hotelbooking_room_form', $data));
	}
	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_room')) {
			$this->error['warning'] = $this->language->get('room_error_permission');
		}

		return !$this->error;
	}
	public function delete() {
		$this->load->language('catalog/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/product');

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {

			foreach ($this->request->post['selected'] as $product_id) {

				$this->model_catalog_product->deleteProduct($product_id);

				$this->model_catalog_wk_hotelbooking_hotels->deleteRoom($product_id);
			}

			$this->session->data['success'] = $this->language->get('text_room_delete_success');

			$this->response->redirect($this->url->link('catalog/wk_hotelbooking_room', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();

	}

	protected function validateForm($postData=array()) {

		$this->load->language('catalog/wk_hotelbooking_hotels');

		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_room')) {
			$this->error['warning'] = $this->language->get('room_error_permission');
		}
		foreach ($postData['product_description'] as $language_id => $value) {
			if ((utf8_strlen(trim($value['name'])) < 3) || (utf8_strlen(trim($value['name'])) > 255)) {
				$this->error['name'][$language_id] = $this->language->get('room_error_name');
			}

			if ((utf8_strlen(trim($value['meta_title'])) < 3) || (utf8_strlen(trim($value['meta_title'])) > 255)) {
				$this->error['meta_title'][$language_id] = $this->language->get('room_error_meta_title');
			}
		}

		if ((utf8_strlen(trim($postData['model'])) < 1) || (utf8_strlen(trim($postData['model'])) > 64)) {
			$this->error['model'] = $this->language->get('error_model');
		}
		if(!preg_match("/^[0-9]+(\.[0-9]{2})?$/",$postData['price']))
			$this->error['price'] =  $this->language->get('room_price_error');

		if(!empty($postData['quantity']) && !preg_match('/^\d+$/',$postData['quantity']))
			$this->error['quantity'] =  $this->language->get('valid_number_error');

		if(!empty($postData['max_adult']) && !preg_match('/^\d+$/',$postData['max_adult']))
			$this->error['max_adult'] =  $this->language->get('valid_number_error');

		if(!empty($postData['max_child']) && !preg_match('/^\d+$/',$postData['max_child']))
			$this->error['max_child'] =  $this->language->get('valid_number_error');


		if(!$postData['from'])
			$this->error['from'] =  $this->language->get('room_from_error');

		if(!$postData['till'])
			$this->error['till'] =  $this->language->get('room_till_error');

		if (utf8_strlen($postData['keyword']) > 0) {
			$this->load->model('catalog/url_alias');

			$url_alias_info = $this->model_catalog_url_alias->getUrlAlias($this->request->post['keyword']);

			if ($url_alias_info && isset($this->request->get['product_id']) && $url_alias_info['query'] != 'product_id=' . $this->request->get['product_id']) {
				$this->error['keyword'] = sprintf($this->language->get('error_keyword'));
			}

			if ($url_alias_info && !isset($this->request->get['product_id'])) {
				$this->error['keyword'] = sprintf($this->language->get('error_keyword'));
			}
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('room_error_warning');
		}
		return !$this->error;
	}
	public function fixedautocomplete() {
		$json = array();

		$this->load->model('catalog/wk_hotelbooking_hotels');

		$fixed_facility = $this->model_catalog_wk_hotelbooking_hotels->getFixedFacility(array('filter_name'=>$this->request->get['filter_name']));

		foreach ($fixed_facility as $result) {
			$json[] = array(
				'attribute_id'    => $result['attribute_id'],
				'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
				'attribute_group' => $result['attribute_group']
			);
		}
		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	protected function setDefaultValue($data=array()) {
			$postData = $data;

			$this->load->model('catalog/category');
			if(isset($postData['product_category']) && $postData['product_category'][0] ) {
				$hotel_info = $this->model_catalog_category->getCategory($postData['product_category'][0]);

				$postData['hotel_id'] = $postData['product_category'][0];
				$postData['product_category'][1]=$this->config->get('wk_hotelbookingcat_categoryid');
				$postData['model'] = $hotel_info['name'];
			} else {
				$postData['hotel_id'] = '';
				$postData['model'] = '';
			}
			$set_value1 = array(
				'tax_class_id',
				'subtract',
				'sort_order',
				'shipping',
				'manufacturer_id'
				);
			$set_value2 = array(
				'sku',
				'upc',
				'ean',
				'jan',
				'isbn',
				'mpn',
				'location',
				'length',
				'width',
				'height',
				'weight',
				'manufacturer',
				'category',
				'filter',
				'download',
				'related',
				'option',
				'points'
				);
			$set_value3 = array(
				'minimum',
				'length_class_id',
				'weight_class_id'
				);

			foreach ($set_value2 as $key => $value) {
				$postData[$value] = '';
				if(isset($set_value1[$key]))
					$postData[$set_value1[$key]] = 0;
				if(isset($set_value3[$key]))
					$postData[$set_value3[$key]] = 1;
			}
			$option_data['product_option_value'] = array();
			if(isset($postData['product_option_value'])) {
				foreach ($postData['product_option_value'] as $enable) {
					if($enable['status'])
						$option_data['product_option_value'][]= $enable;
				}
			}

			if(isset($option_data) && $option_data) {
				foreach ($option_data['product_option_value'] as $key => $opt) {
					$option_data['product_option_value'][$key]['quantity'] = 1;
					$option_data['product_option_value'][$key]['subtract'] =0;
					$option_data['product_option_value'][$key]['points_prefix'] ='+';
					$option_data['product_option_value'][$key]['points'] ='0';
					$option_data['product_option_value'][$key]['weight_prefix'] ='+';
					$option_data['product_option_value'][$key]['weight'] ='0';
				}
				$postData['product_option'][0] = array(
					'required' => 0,
					'product_option_id' => isset($postData['product_option_id']) ? $postData['product_option_id'] : 0,
					'option_id' => $this->config->get('wk_hotelbookingopt_optionid'),
					'type' => 'checkbox',
					'name'=> 'Hotel Management',
					'product_option_value' => $option_data['product_option_value']
					);
			} else {
				unset($postData['product_option']);
			}
			$postData['product_store'][0] = 0;
			$postData['keyword'] = '';
			$postData['date_available'] = date('D/M/Y');
			$postData['stock_status_id'] = 6;

			unset($postData['product_option_value']);

			return $postData;
	}
	public function approve(){
		$this->load->language('catalog/wk_hotelbooking_hotels');
			if($this->request->server['REQUEST_METHOD'] == "POST" && $this->request->post['room_id']) {
				$json = array();
				$this->load->model('catalog/wk_hotelbooking_hotels');
				$this->model_catalog_wk_hotelbooking_hotels->approveRoom($this->request->post['room_id']);
				$json['success'] = $this->language->get("text_aprm_success");
			}
		if(isset($json) && $json['success']) {
			$this->response->addHeader('Content-Type: application/json');
			$this->response->setOutput(json_encode($json));

		}
	}
}
?>
