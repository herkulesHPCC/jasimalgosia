<?php
class ModelExtensionModuleWkhotelbooking extends Model {
	/**
	 * [getHotels all hotels]
	 * @return [array] [details about all hotels]
	 */
public function getHotels($filter_data = array()) {
			$sql = "SELECT whd.*,c.image,cd.name FROM ".DB_PREFIX."wk_hotel_details whd LEFT JOIN ".DB_PREFIX."category c ON (whd.category_id=c.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (whd.category_id=cd.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND whd.status=1 ";
			if(isset($filter_data['filter_name'])) {
				$sql.= " AND cd.name LIKE '%".$this->db->escape($filter_data['filter_name'])."%'";
			}
      $result = $this->db->query($sql)->rows;
      return $result;
}

/**
 * [getFxfacilitiesinfo information about particular facility]
 * @param  [type] $attribute_id [description]
 * @return [type]               [description]
 */
public function getFxfacilitiesinfo($attribute_id){
	$result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_facility WHERE facility_ocid='".(int)$attribute_id."'")->row;
	return $result;
}

public function getRoom($product_id){
	$result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_room WHERE product_id = '".(int)$product_id."'")->row;
	return $result;
}
public function getTotalOptionData($id) {
		$chk_query[]= $this->db->query("SELECT product_option_id FROM " . DB_PREFIX . "product_option WHERE product_id = '".(int)$id."' AND option_id = '".(int)$this->config->get('wk_hotelbooking_options0')."'")->row;

		$chk_query[]= $this->db->query("SELECT product_option_id FROM " . DB_PREFIX . "product_option WHERE product_id = '".(int)$id."' AND option_id = '".(int)$this->config->get('wk_hotelbooking_options2')."'")->row;

		$chk_query[]= $this->db->query("SELECT product_option_id FROM " . DB_PREFIX . "product_option WHERE product_id = '".(int)$id."' AND option_id = '".(int)$this->config->get('wk_hotelbooking_options3')."'")->row;
		$chk_query[]= $this->db->query("SELECT product_option_id FROM " . DB_PREFIX . "product_option WHERE product_id = '".(int)$id."' AND option_id = '".(int)$this->config->get('wk_hotelbooking_options1')."'")->row;
		$chk_query[]= $this->db->query("SELECT product_option_id FROM " . DB_PREFIX . "product_option WHERE product_id = '".(int)$id."' AND option_id = '".(int)$this->config->get('wk_hotelbooking_options4')."'")->row;
		$chk_query[]= $this->db->query("SELECT product_option_id FROM " . DB_PREFIX . "product_option WHERE product_id = '".(int)$id."' AND option_id = '".(int)$this->config->get('wk_hotelbooking_options5')."'")->row;
		return $chk_query;
	}
 public function getHotelDetails($category_id) {
       $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_details WHERE category_id ='".(int)$category_id."' AND status=1")->row;
       return $result;
    }


public function isBooking($product_id) {
	$booking = $this->db->query("SELECT product_id FROM ".DB_PREFIX."wk_hotel_room WHERE product_id = '".(int)$product_id."' AND status = '1' ")->row;
	if($booking){
			return 1;
	} else {
		return 0;
	}
}
public function updateBooking($pid,$order_id,$from,$till,$quantity,$ementies){
		if ($this->customer->isLogged()) {
			$name=$this->customer->getFirstName().' '.$this->customer->getLastName();
			$email=$this->customer->getEmail();
			$telephone=$this->customer->getTelephone();
		} else {
			$name = $this->session->data['guest']['firstname'].' '.$this->session->data['guest']['lastname'];
			$email = $this->session->data['guest']['email'];
			$telephone = $this->session->data['guest']['telephone'];
		}
		$this->db->query("INSERT INTO " . DB_PREFIX . "wk_booking_slots VALUES('',".(int)$pid.",'".(int)$order_id."','".$from."','".$till."',".(int)$quantity.",'".$this->db->escape($name)."','".$this->db->escape($email)."','".$telephone."','".$ementies."', 1)");
}


public function getBookedSlots($product_id,$start_date,$last_Date, $date = ''){
$bookedSlots= $this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots WHERE product_id= ".(int)$product_id." AND NOT(( DATE(start_day) <= '".$this->db->escape($last_Date)."' AND DATE(end_day) <= '".$this->db->escape($start_date)."') OR (DATE(start_day) >= '".$this->db->escape($last_Date)."' AND DATE(end_day) >= '".$this->db->escape($start_date)."')) AND status=1")->rows;
return $bookedSlots;
}
public function updateQuantity($data){
		$del=$this->db->query("DELETE FROM ".DB_PREFIX."wk_booking_quantity WHERE product_id='".(int)$data['product_id']."'AND customer_id='".(int)$this->customer->getId()."'AND options= '".$data['options']."' AND session_id = '" . $this->db->escape($this->session->getId()) . "'");
		$this->db->query("INSERT " . DB_PREFIX . "wk_booking_quantity SET customer_id = '" . (int)$this->customer->getId() . "', product_id = '" .(int)$data['product_id'] ."', quantity = '" .(int)$data['hours'] . "',options = '".$data['options']."',session_id = '" . $this->db->escape($this->session->getId()) . "'");
	}
/**
 * [addResponse add new review]
 * @param [string] $name     [name of client]
 * @param [string] $email    [email of client]
 * @param [string] $response [review value]
 * @param [string] $image    [image path]
 * @param [int] $rating   [rating number]
 * @param [int] $hotel_id [id of hotel]
 */
public function addResponse($name,$email,$response,$image,$rating,$hotel_id) {
	$this->db->query("INSERT INTO " . DB_PREFIX . "wk_hotel_reviews VALUES('','".$this->db->escape($name)."','".$this->db->escape($email)."','".$this->db->escape($response)."','".$image."',".(int)$rating.",NOW(),0,'".(int)$hotel_id."')");
}
/**
 * [getReview review of particular hotel]
 * @param  [int] $hotel_id [hotel id of hotel]
 * @return [array]           [array of reviews related to particular hotel]
 */
public function getReview($hotel_id){
$result = $this->db->query("SELECT *,(SELECT AVG(rating) AS total FROM " . DB_PREFIX . "wk_hotel_reviews WHERE status = '1' AND hotel_id = ".(int)$hotel_id." GROUP BY hotel_id) AS rating FROM ".DB_PREFIX."wk_hotel_reviews WHERE status=1 AND hotel_id = '".(int)$hotel_id."'")->rows;
return $result;
}
/**
 * [checkRoomAvail check room is available or not for search date]
 * @param  [date] $checkintime  [searched checkintime]
 * @param  [date] $checkouttime [searched checkouttime]
 * @param  [int] $room_id      [room id]
 * @return [array]               [array of rooms that are avail]
 */
public function checkRoomAvail($checkintime,$checkouttime,$room_id){

  $result = $this->db->query("SELECT start_from, till FROM ".DB_PREFIX."wk_hotel_room WHERE product_id='".$room_id."' AND ((start_from < '".$checkouttime."' AND till > '".$checkouttime."') OR (start_from < '".$checkintime."' AND till > '".$checkintime."'))")->row;
  if($result)
  	return $result;
   else
   	return 0;
}
/**
 * [checkCityByProductid return boolean value that hotel is in that city or not]
 * @param  [int] $hotel_id [product id of hotel]
 * @param  [string] $city    [city name]
 * @return [boolean]
 */
public function checkCity($hotel_id,$city){
	$result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_details WHERE category_id='".(int)$hotel_id."' AND address LIKE '%".$this->db->escape($city)."%' AND status=1")->row;
	if($result)
		return true;
	else
		return false;
}
/**
 * [checkCityByProductid return boolean value that room is in that city or not]
 * @param  [int] $room_id [product id of room]
 * @param  [string] $city    [city name]
 * @return [boolean]
 */
public function checkCityByProductid($room_id,$city){
	$result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_details WHERE category_id= (SELECT hotel_id FROM ".DB_PREFIX."wk_hotel_room WHERE product_id = '".(int)$room_id."') AND address LIKE '%".$this->db->escape($city)."%' AND status=1")->row;

	if($result)
		return true;
	else
		return false;
}
public function getProductAttributes($product_id) {
		$product_attribute_group_data = array();

		$product_attribute_group_query = $this->db->query("SELECT ag.attribute_group_id, agd.name FROM " . DB_PREFIX . "product_attribute pa LEFT JOIN " . DB_PREFIX . "attribute a ON (pa.attribute_id = a.attribute_id) LEFT JOIN " . DB_PREFIX . "attribute_group ag ON (a.attribute_group_id = ag.attribute_group_id) LEFT JOIN " . DB_PREFIX . "attribute_group_description agd ON (ag.attribute_group_id = agd.attribute_group_id) WHERE pa.product_id = '" . (int)$product_id . "' AND agd.language_id = '" . (int)$this->config->get('config_language_id') . "' GROUP BY ag.attribute_group_id ORDER BY ag.sort_order, agd.name");

		foreach ($product_attribute_group_query->rows as $product_attribute_group) {
			$product_attribute_data = array();

			$product_attribute_query = $this->db->query("SELECT f.facility_image,a.attribute_id, ad.name, pa.text FROM " . DB_PREFIX . "product_attribute pa LEFT JOIN " . DB_PREFIX . "attribute a ON (pa.attribute_id = a.attribute_id) LEFT JOIN " . DB_PREFIX . "attribute_description ad ON (a.attribute_id = ad.attribute_id) LEFT JOIN ".DB_PREFIX."wk_hotel_facility f ON(a.attribute_id=f.facility_ocid) WHERE pa.product_id = '" . (int)$product_id . "' AND a.attribute_group_id = '" . (int)$product_attribute_group['attribute_group_id'] . "' AND f.status = '1' AND ad.language_id = '" . (int)$this->config->get('config_language_id') . "' AND pa.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY a.sort_order, ad.name");

			foreach ($product_attribute_query->rows as $product_attribute) {
				$product_attribute_data[] = array(
					'attribute_id' => $product_attribute['attribute_id'],
					'name'         => $product_attribute['name'],
					'text'         => $product_attribute['text'],
					'image'		   => $product_attribute['facility_image']
				);
			}

			$product_attribute_group_data[] = array(
				'attribute_group_id' => $product_attribute_group['attribute_group_id'],
				'name'               => $product_attribute_group['name'],
				'attribute'          => $product_attribute_data
			);
		}

		return $product_attribute_group_data;
	}

public function getSellerHotels($seller_id,$page=null) {
	$sql = "SELECT wh.*,c.* , cd.*  FROM ".DB_PREFIX."wk_hotel_details wh LEFT JOIN ".DB_PREFIX."category c ON (c.category_id = wh.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id = c.category_id)  WHERE wh.owner = '".(int)$seller_id."' AND wh.status = 1 AND cd.language_id='".$this->config->get('config_language_id')."'";
	if (!is_null($page)) {
	$start =$page*4;
	$limit =4;
		$sql .= " LIMIT " . (int)$start . "," . (int)$limit;
	}

	$results = $this->db->query($sql);
	return $results->rows;
}
public function totalSellerhotels($seller_id,$page=null) {
	$sql = "SELECT wh.*,c.* , cd.*  FROM ".DB_PREFIX."wk_hotel_details wh LEFT JOIN ".DB_PREFIX."category c ON (c.category_id = wh.category_id) LEFT JOIN ".DB_PREFIX."category_description cd ON (cd.category_id = c.category_id)  WHERE wh.owner = '".(int)$seller_id."' AND wh.status = 1 AND cd.language_id='".$this->config->get('config_language_id')."'";

	$results = $this->db->query($sql);
	return count($results->rows);
}
public function getSellerRooms($seller_id) {
$sql = "SELECT wr.*,p.* , pd.* FROM ".DB_PREFIX."wk_hotel_room wr LEFT JOIN ".DB_PREFIX."product p ON (wr.product_id = p.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON (pd.product_id = p.product_id) WHERE wr.owner = '".(int)$seller_id."' AND p.status = 1 AND pd.language_id='".$this->config->get('config_language_id')."' AND wr.status = 1";
	$results = $this->db->query($sql);
	return $results->rows;
}

 public function getHoteltab(){
    $result = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_hotel_tab WHERE language_id = '".(int)$this->config->get('config_language_id')."'")->rows;
    return $result;
  }

 public function getReviews($seller_id){
 	return $this->db->query("SELECT * FROM ".DB_PREFIX."customerpartner_to_feedback WHERE seller_id = '".(int)$seller_id."'")->rows;
 }
 public function getRooms($hotel_id,$seller_id = 0){
 	$sql = "SELECT wr.*,pd.name FROM ".DB_PREFIX."wk_hotel_room wr LEFT JOIN ".DB_PREFIX."product p ON(p.product_id=wr.product_id) LEFT JOIN ".DB_PREFIX."product_description pd ON(pd.product_id=p.product_id) WHERE pd.language_id = '".(int)$this->config->get('config_language_id')."' AND wr.hotel_id = '".(int)$hotel_id."' AND p.status = 1";
 	if($seller_id) {
 		$sql .= " AND wr.owner='".(int)$seller_id."'";
 	}
 	$results = $this->db->query($sql)->rows;

 	return $results;

 }
  public function getAllRoomBooking($room_id) {
	 	$bookedSlots= $this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots WHERE product_id= ".(int)$room_id." AND status=1")->rows;
		return $bookedSlots;
 }
 public function getTotalBookings($start_date,$last_Date, $date = ''){
	$bookedSlots= $this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots WHERE NOT(( DATE(start_day) < '".$last_Date."' AND DATE(end_day) < '".$start_date."') OR (DATE(start_day) > '".$last_Date."' AND DATE(end_day) > '".$start_date."')) AND status=1")->rows;
	return $bookedSlots;
 }
public function getProducts($data = array()) {
	$sql = "SELECT p.product_id, (SELECT AVG(rating) AS total FROM " . DB_PREFIX . "review r1 WHERE r1.product_id = p.product_id AND r1.status = '1' GROUP BY r1.product_id) AS rating, (SELECT price FROM " . DB_PREFIX . "product_discount pd2 WHERE pd2.product_id = p.product_id AND pd2.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND pd2.quantity = '1' AND ((pd2.date_start = '0000-00-00' OR pd2.date_start < NOW()) AND (pd2.date_end = '0000-00-00' OR pd2.date_end > NOW())) ORDER BY pd2.priority ASC, pd2.price ASC LIMIT 1) AS discount, (SELECT price FROM " . DB_PREFIX . "product_special ps WHERE ps.product_id = p.product_id AND ps.customer_group_id = '" . (int)$this->config->get('config_customer_group_id') . "' AND ((ps.date_start = '0000-00-00' OR ps.date_start < NOW()) AND (ps.date_end = '0000-00-00' OR ps.date_end > NOW())) ORDER BY ps.priority ASC, ps.price ASC LIMIT 1) AS special";

	if (!empty($data['filter_category_id'])) {
			$sql .= " FROM " . DB_PREFIX . "product_to_category p2c";
			$sql .= " LEFT JOIN " . DB_PREFIX . "product p ON (p2c.product_id = p.product_id)";
	} else {
		$sql .= " FROM " . DB_PREFIX . "product p";
	}
  $sql .= " LEFT JOIN ". DB_PREFIX ."wk_hotel_room wr ON(p.product_id=wr.product_id)";

	$sql .= " LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id) LEFT JOIN " . DB_PREFIX . "product_to_store p2s ON (p.product_id = p2s.product_id) WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND p.status = '1' AND p.date_available <= NOW() AND p2s.store_id = '" . (int)$this->config->get('config_store_id') . "' AND wr.product_id IS NOT NULL";

	if (!empty($data['filter_category_id'])) {
			$sql .= " AND p2c.category_id = '" . (int)$data['filter_category_id'] . "'";
	}
	if (isset($data['adult']) && $data['adult']) {
			$sql .= " AND wr.max_adult >= '" . (int)$data['adult'] . "'";
	}
	if (isset($data['adult']) && $data['child']) {
			$sql .= " AND wr.max_child >= '" . (int)$data['child'] . "'";
	}
	if (isset($data['room']) && $data['room']) {
			$sql .= " AND p.quantity >= '" . (int)$data['room'] . "'";
	}
	if (isset($data['checkintime']) && $data['checkintime']) {
			$sql .= " AND DATE(wr.start_from) <= '" . $data['checkintime'] . "' AND DATE(wr.till) >= '".$data['checkouttime']."'";
	}
	$sql .= " GROUP BY p.product_id ORDER BY p.sort_order";

	if (isset($data['start']) || isset($data['limit'])) {
		if ($data['start'] < 0) {
			$data['start'] = 0;
		}

		if ($data['limit'] < 1) {
			$data['limit'] = 20;
		}

		$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
	}

	$product_data = array();
	$query = $this->db->query($sql);
	$this->load->model('catalog/product');
	foreach ($query->rows as $result) {
		$product_data[$result['product_id']] = $this->model_catalog_product->getProduct($result['product_id']);
	}

	return $product_data;
}
public function getPartnerIdBasedonHotel($category_id) {
	$result = $this->db->query("SELECT wd.owner as id FROM ".DB_PREFIX."wk_hotel_details wd LEFT JOIN ".DB_PREFIX."customer c ON(wd.owner = c.customer_id) WHERE wd.category_id = '".(int)$category_id."' AND c.customer_id IS NOT NULL")->row;
	return $result;
}

}
