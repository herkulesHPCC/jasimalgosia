<?php
class ControllerAccountCustomerpartnerDashboard extends Controller {

	private $error = array();
	private $data = array();

	public function index() {

		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/dashboard', '', 'true');
			$this->response->redirect($this->url->link('account/login', '', 'true'));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();	
			
		if(!$data['chkIsPartner'])
			$this->response->redirect($this->url->link('account/account'));

    	$this->document->addStyle('catalog/view/theme/default/stylesheet/MP/sell.css');

		$this->language->load('account/customerpartner/dashboard');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_sale'] = $this->language->get('text_sale');
		$data['text_activity'] = $this->language->get('text_activity');
		$data['text_recent'] = $this->language->get('text_recent');

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home'),     	
        	'separator' => false
      	); 

      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_account'),
			'href'      => $this->url->link('account/account', '', 'true'),       	
        	'separator' => $this->language->get('text_separator')
      	);
		
      	$data['breadcrumbs'][] = array(
        	'text'      => $this->language->get('text_dashboard'),
			'href'      => $this->url->link('account/customerpartner/dashboard', '', 'true'),       	
        	'separator' => $this->language->get('text_separator')
      	);
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

      	$data['order'] = $this->load->controller('account/customerpartner/dashboards/order');
		$data['sale'] = $this->load->controller('account/customerpartner/dashboards/sale');
		$data['customer'] = $this->load->controller('account/customerpartner/dashboards/customer');
		$data['booking'] = $this->load->controller('account/customerpartner/dashboards/booking');		
		$data['recent'] = $this->load->controller('account/customerpartner/dashboards/recent');

      	$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');	
		$data['isMember'] = true;

      	if(!in_array('dashboard', $this->config->get('module_wk_hotelbooking_res_allowedaccmenu'))) {
      		$this->response->redirect($this->url->link('account/account','', 'true'));
      	}
		$this->response->setOutput($this->load->view('account/customerpartner/dashboard' , $data));
		
	}

	public function changereview(){
		
		$this->language->load('account/customerpartner/dashboard');
		
		$this->load->model('account/customerpartner');
		
		$json = array();
		
		if ($this->request->server['REQUEST_METHOD'] == 'POST' AND $this->customer->getID()) {

			if ($this->model_account_customerpartner->chkIsPartner() AND isset($this->request->post['review'])) {
				$latestcomment=$this->model_account_customerpartner->UpdateReview($this->request->post['review']);	
				$json['success'] = $this->language->get('text_change_review');	
			}else{
				$json['error'] = $this->language->get('text_error');
			}		    	    
			
		}
		
		$this->response->setOutput(json_encode($json));

	}	
}
?>
