<?php
class ControllerAccountCustomerpartnerInvoice extends Controller {
	public function index(){
			$this->load->language('account/order');
			if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
				$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
				$this->response->redirect($this->url->link('account/login', '', true));
			}

			$this->load->model('account/customerpartner');

			$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

			if(!$data['chkIsPartner']){
				$this->response->redirect($this->url->link('account/account'));
			}
			if (isset($this->request->get['order_id'])) {
				$order_id = $this->request->get['order_id'];
			} else {
				$order_id = 0;
			}

			if (!$this->customer->isLogged()) {
				$this->session->data['redirect'] = $this->url->link('account/order/info', 'order_id=' . $order_id, true);

				$this->response->redirect($this->url->link('account/login', '', true));
			}

			$this->load->model('account/order');

			$order_info = $this->model_account_order->getOrder($order_id);

			$invoice_data['order_id'] = $this->request->get['order_id'];
			$invoice_data['payment_method'] = $order_info['payment_method'];


			 $this->load->model('catalog/product');
			 $this->load->model('tool/upload');
			 $invoice_data['products'] = array();

			 $products = $this->model_account_order->getOrderProducts($this->request->get['order_id']);

			 foreach ($products as $product) {
			 	$option_data = array();

			 	$options = $this->model_account_order->getOrderOptions($this->request->get['order_id'], $product['order_product_id']);

			 	foreach ($options as $option) {
			 		if ($option['type'] != 'file') {
			 			$value = $option['value'];
			 		} else {
			 			$upload_info = $this->model_tool_upload->getUploadByCode($option['value']);

			 			if ($upload_info) {
			 				$value = $upload_info['name'];
			 			} else {
			 				$value = '';
			 			}
			 		}

			 		$option_data[] = array(
			 			'name'  => $option['name'],
			 			'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
			 		);
			 	}

			$order_totals = array();

			$totals = $this->model_account_order->getOrderTotals($this->request->get['order_id']);

			foreach ($totals as $total) {
				$order_totals[] = array(
					'title' => $total['title'],
					'text'  => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
				);
			}
			 	$product_info = $this->model_catalog_product->getProduct($product['product_id']);

			 	if ($product_info) {
			 		$reorder = $this->url->link('account/order/reorder', 'order_id=' . $order_id . '&order_product_id=' . $product['order_product_id'], true);
			 	} else {
			 		$reorder = '';
			 	}
			 	$this->load->model('tool/image');

				if ($product_info['image']) {
					$image = $this->model_tool_image->resize($product_info['image'], $this->config->get($this->config->get('config_theme') . '_image_thumb_width'), $this->config->get($this->config->get('config_theme') . '_image_thumb_height'));
				} else {
					$image = '';
				}
				$store_address= $this->config->get('config_address');
				$store_name = $this->config->get('config_name');
				$store_email = $this->config->get('config_email');
			 	$invoice_data['products'][] = array(
			 		'name'     => $product['name'],
			 		'model'    => $product['model'],
			 		'option'   => $option_data,
			 		'quantity' => $product['quantity'],
			 		'image'	   => $image,
			 		'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
			 		'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']),
			 		'reorder'  => $reorder,
			 		'return'   => $this->url->link('account/return/add', 'order_id=' . $order_info['order_id'] . '&product_id=' . $product['product_id'], true)
			 	);
			 }
			// Page header
			$invoice_data['date_added'] = date($this->language->get('date_format_short'), strtotime($order_info['date_added']));
			$results = $this->model_account_order->getOrderHistories($this->request->get['order_id']);

			$details = $this->db->query("SELECT * FROM ".DB_PREFIX."wk_booking_slots WHERE order_id = '".$order_id."'")->rows;
			if ($this->request->server['HTTPS']) {
					$server = $this->config->get('config_true');
				} else {
					$server = $this->config->get('config_url');
				}

			if (is_file(DIR_IMAGE . $this->config->get('config_logo'))) {
				$logo= $server . 'image/' . $this->config->get('config_logo');
			} else {
				$logo = '';
			}
			$this->load->language('account/customerpartner/invoice');
			require_once(DIR_IMAGE. '../fpdf/fpdf.php');
			$pdf = new fpdf();
			$pdf->AddPage(); //added new page to the document
			$pdf->SetFont('Arial','B',16); //set the font-related properties
			if($logo) {
				$pdf->Image($logo,20,16,40); // adding the logo to the pdf
			}

			$pdf->Cell(80);// Move to the right
			$pdf->Cell(40,20,$this->language->get('heading_title').$order_id);
		    $pdf->Ln();// Line break
		    $pdf->SetFont('helvetica','I',10);
			$pdf->Cell(190,7,$this->language->get('text_order_details'),1,2);
			$pdf->SetFont('helvetica','',10);
			$y = $pdf->GetY(); //ordinate of the current position.
			$pdf->MultiCell(95,8,$this->language->get('text_order_id').$order_id."\n".$this->language->get('text_order_status').$results[sizeof($results)-1]['status'],'LRB',1);// Text with line break
			$x = $pdf->GetX(); //the abscissa of the current position
			$pdf->setXY($x+95,$y);
			$pdf->MultiCell(95,8,$this->language->get('text_payment_method').$invoice_data['payment_method']."\n".$this->language->get('text_order_date').$invoice_data['date_added'],'LRB','T');
			$pdf->Ln();
			$pdf->SetFont('helvetica','I',10);
			$y = $pdf->GetY();
			$pdf->Cell(90,7,$this->language->get('text_account_info'),1,2);
			$pdf->SetFont('helvetica','',10);
			$pdf->MultiCell(90,8, $this->language->get('text_customer_name').$order_info['firstname'].' '.$order_info['lastname']."\n"."Email : ".$order_info['email'],'LRB',1);
			$x = $pdf->GetX();
			$pdf->setXY($x+100,$y);
			$pdf->SetFont('helvetica','I',10);
			$pdf->Cell(90,7,$this->language->get('text_purchase_info'),1,2);
			$pdf->SetFont('helvetica','',10);
			$pdf->MultiCell(90,8,$this->language->get('text_ip').$order_info['ip']."\n".$this->language->get('text_store_name').$order_info['store_name'],'LRB','T');
			$pdf->Ln();
		    $pdf->SetFont('helvetica','I',10);
			$pdf->Cell(190,7,$this->language->get('text_item'),1,2);
			$pdf->SetFont('helvetica','',8);
			$pdf->setFillColor(230,230,230);

			$pdf->Cell(38,10,$this->language->get('column_name'),1,0,'C',0);
			$pdf->Cell(32,10,$this->language->get('column_model'),1,0,'C',0);
			$pdf->Cell(42,10,$this->language->get('column_dates'),1,0,'C',0);
			$pdf->Cell(26,10,$this->language->get('column_price'),1,0,'C',0);
			$pdf->Cell(26,10,$this->language->get('column_quantity'),1,0,'C',0);
			$pdf->Cell(26,10,$this->language->get('column_total'),1,1,'C',0);

			// $pdf->setFillColor(255,255,255); // For set the background color of cells
			foreach($invoice_data['products'] as $key => $value) { // iterating each product of order
				$pdf->Cell(38,10,$value['name'],1,0,'C',0);
				$pdf->Cell(32,10,$value['model'],1,0,'C',0);
				$y = $pdf->GetY();
				if(isset($details[$key])) {
					$string = 'From : '.$details[$key]['start_day']."\n Till : ".$details[$key]['end_day'];
					$pdf->MultiCell(42,5,$string,1,'L',0); // If the cells have text with line breaks
				} else {
					$pdf->MultiCell(42,10,'N.A'."\n",1,'C',0);
				}
				$x = $pdf->GetX();
				$pdf->setXY($x+112,$y);
				$pdf->Cell(26,10,$value['price'],1,0,'C',0);
				$pdf->Cell(26,10,$products[$key]['quantity'],1,0,'C',0);
				$pdf->Cell(26,10,$value['total'],1,1,'C',0);
			}
			$flag= 1;
			foreach ($order_totals as $key => $value) { // iterating each total of order like sub-total,tax etc.
				$val ='';
				if($flag==1){
					$val='T';
					$flag=0;
				}
				$j='';
				if(end($order_totals)){
					$j='B';
				}
				// Cell(width,height,text of cell,border, position after call, center/align text, true/false for cell background, URL) width is require only other filed are optional
				$pdf->Cell(38,10,'','TL'.$j,0,'C',0);	// left the cell as blank.
				$pdf->Cell(32,10,'','T'.$j,0,'C',0);
				$pdf->Cell(42,10,'','T'.$j,0,'C',0);
				$pdf->Cell(26,10,'','T'.$j,0,'C',0);
				$pdf->setFillColor(0,148,197);
				$pdf->setTextColor(255,255,255);
				$pdf->Cell(26,10,$value['title'],1,0,'C',1);
				$pdf->Cell(26,10,$value['text'],1,1,'C',1);
				$pdf->setTextColor(0,0,0);
				$pdf->setFillColor(255,255,255);
			}

			$pdf->Output(); //Send the file in inline browser

	}
}

?>
