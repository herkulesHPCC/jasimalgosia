<?php
class ControllerAccountCustomerpartnerhotelwkhotelbookingres extends Controller {

	private $error = array();

	public function index() {
				if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res', '', 'true');
			$this->response->redirect($this->url->link('account/login', '', 'true'));
		}
		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner'])
			$this->response->redirect($this->url->link('account/account'));
		$this->load->language('extension/module/wk_hotelbooking_hotels');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');


		$this->getList();
  	}


	protected function getList() {
		if (!$this->customer->isLogged() || !$this->config->get('module_wk_hotelbooking_res_status')) {
			$this->session->data['redirect'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true);
			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->model('account/customerpartner');

		$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();

		if(!$data['chkIsPartner']){
			$this->response->redirect($this->url->link('account/account'));
		}
		$this->load->language('extension/module/wk_hotelbooking_hotels');


  	$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', 'true')
		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title_booking'),
					'href'      => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res', '', 'true')
   		);
			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment.min.js');
			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment-with-locales.min.js');
			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
			$this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');
		  $data['update'] = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res/delete', '' , 'true');

		$data['questionarray'] = array();


		$questionarray = array();

		$limit = $this->config->get('config_limit_admin');

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
			$page = 1;
		}

		if(isset($this->request->get['sort'])){
			$data['sort'] = $sort = $this->request->get['sort'];
		}else{
			$data['sort'] = $sort = null;
		}

		if(isset($this->request->get['order'])){
			$data['order'] = $order = $this->request->get['order'];
		}else{
			$order = null;
		}

		if(isset($this->request->get['name'])){
			$data['name'] = $name = $this->request->get['name'];
		}else{
			$name = null;
		}

		if(isset($this->request->get['date_added'])){
			$data['date_added'] = $date_added = $this->request->get['date_added'];
		}else{
			$date_added = null;
		}

		if(isset($this->request->get['order_id'])){
			$data['order_id'] = $order_id = $this->request->get['order_id'];
		}else{
			$order_id = null;
		}

		if(isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
			$start = ($page-1)*$limit;
			$end = $limit;
		} else {
			$start = 0;
			$end = $limit;
			$page = 1;
		}
		$filterValues = array(
				'sort'	=> $sort,
				'order'	=> $order,
				'name'	=> $name,
				'order_id' => $order_id,
				'date_added' => $date_added,
				'start'	=> $start,
				'limit'	=> $end
			);


			$data['sub_heading_title'] = $this->language->get('heading_title_products');
			//$product_total = $this->model_catalog_wk_hotelbooking_hotels->viewtotalentry($filterValues);

			$orders = $this->model_catalog_wk_hotelbooking_hotels->viewtotalbookings($filterValues);

			$orders_total = $this->model_catalog_wk_hotelbooking_hotels->viewtotalbookingentry($filterValues);

			$data['result_book'] = array();
			if($orders){

				foreach($orders as $key => $order_list){
						$data['result_book'][]= array(
							'selected' => false,
							'customer_name' => $order_list['name'],
							'status' => $order_list['orderstatus'],
							'date_added' => $order_list['date_added'],
							'order_id' => $order_list['order_id'],
							'action' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res_booking&order_id='.$order_list['order_id'],'',true)
							);
					}

			}


 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		if (isset($this->session->data['error'])) {
			$data['error_warning'] = $this->session->data['error'];

			unset($this->session->data['error']);
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
			$this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');
			$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');
			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment.js');
			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
			$this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');

		$pagination = new Pagination();
		$pagination->total = $orders_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res' . '&page={page}','',true);

		$data['pagination'] = $pagination->render();
		$data['results'] = sprintf($this->language->get('text_pagination'), ($orders_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($orders_total - $this->config->get('config_limit_admin'))) ? $orders_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $orders_total, ceil($orders_total / $this->config->get('config_limit_admin')));

		$data['header'] = $this->load->controller('common/header');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('account/customerpartner/hotel/wk_hotelbooking_res',$data));
  	}


  	public function delete() {
    	$this->load->language('extension/module/wk_hotelbooking_hotels');

    	$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/wk_hotelbooking_hotels');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			$this->load->model('catalog/product');

			foreach ($this->request->post['selected'] as $id) {
				$this->model_catalog_wk_hotelbooking_hotels->deleteRoom($id);
				$this->model_catalog_product->deleteProduct($product_id);
	  		}

			$this->session->data['success'] = $this->language->get('text_room_delete_success');

			$url='';

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('account/customerpartner/hotel/wk_hotelbooking_res', '', 'true'));
		}

    	$this->getList();
  	}


	private function validateForm() {
		if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_res')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}



		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		if (!$this->error) {
				return true;
		} else {
			return false;
		}
		}
	protected function validateDelete() {
    	if (!$this->user->hasPermission('modify', 'catalog/wk_hotelbooking_res')) {
      		$this->error['warning'] = $this->language->get('error_permission');
    	}

		if (!$this->error) {
	  		return true;
		} else {
	  		return false;
		}
  	}
  }
?>
