<?php
class ControllerExtensionModuleWkHotelSearch extends Controller {
	public function index($module) {

		$route = isset($this->request->get['route']) ? (string)$this->request->get['route'] : 'common/hotel_home';

		$this->load->language('extension/module/wk_hotel_booking');

		$this->load->model('extension/module/wk_hotel_booking');


		$data['city'] = isset($this->session->data['city']) ? $this->session->data['city'] :'';
		$data['checkintime'] = isset($this->session->data['checkintime']) ? $this->session->data['checkintime'] :'';
		$data['checkouttime'] = isset($this->session->data['checkouttime']) ? $this->session->data['checkouttime'] :'';
		$data['room'] = isset($this->session->data['room']) ? $this->session->data['room'] :1;
		$data['guest'] = isset($this->session->data['guest']) ? $this->session->data['guest'] :1;
		$data['adult'] = isset($this->session->data['adult']) ? $this->session->data['adult'] :1;
		$data['child'] = isset($this->session->data['child']) ? $this->session->data['child'] :0;

		$this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');
		$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');
		$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment.min.js');
		$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment-with-locales.min.js');
		$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
		$this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');
		$data['action'] = $this->url->link('product/category');
		$data['path'] = $this->config->get('wk_hotelbookingcat_categoryid');
		if(isset($this->session->data['hotel']) && $this->session->data['hotel']) {
			 $data['hotel_path'] = $this->session->data['hotel'];
		}
		$data['search_hotels'] = $this->url->link('extension/module/wk_hotel_search/searchHotels');
		$this->document->addScript('https://maps.googleapis.com/maps/api/js?libraries=places&key='.$this->config->get('module_wk_hotelbooking_res_google_key'));
		$data['route'] = $route;
		return $this->load->view('extension/module/wk_hotel_search', $data);
	}
public function getHotels(){
		$json = array();
		$filter_name = isset($this->request->get['filter_name']) ? $this->request->get['filter_name'] : '';
		$this->load->model('extension/module/wk_hotel_booking');
		$hotels = $this->model_extension_module_wk_hotel_booking->getHotels(array('filter_name'=>$filter_name));
		foreach ($hotels as $hotel) {
			$json[] = array(
					'hotel' => $hotel['name'],
					'hotel_id' => $hotel['category_id'],
					'address' => $hotel['address']
				);
		}
		$this->response->addHeader('Content-Type:application/json');
		$this->response->setOutput(json_encode($json));
}
}
