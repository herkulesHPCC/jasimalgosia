<?php
class ControllerExtensionModulewkhotelbookingres extends Controller {

		public function index() {
		//LOAD LANGUAGE
		$this->language->load('extension/module/wk_hotel_booking');
		//Modal heading
    $data['heading_title'] = $this->language->get('text_book_heading_tile');
  	$this->load->model('catalog/product');
  	$this->load->model('extension/module/wk_hotel_booking');

		if(isset($this->request->get['route']) && (substr($this->request->get['route'],0,8)=='account/')) {

			$data['logged'] = $this->customer->isLogged();
			$this->load->model('account/customerpartner');
			$data['chkIsPartner'] = $this->model_account_customerpartner->chkIsPartner();
			if($data['chkIsPartner']===0) {
				$data['text_becomePartner'] = $this->language->get('text_alreadyrequest');
			} else {
				$data['text_becomePartner'] = $this->language->get('text_becomePartner');
			}
			$data['want_partner']	= $this->url->link('customerpartner/sell','',true);
		  $data['send_mail'] = $this->url->link('account/customerpartner/sendmail','',true);

			$data['mail_for'] = '&contact_admin=true';

			if($this->config->get('module_wk_hotelbooking_res_accmenuseq') && $this->model_account_customerpartner->chkIsPartner()) {

				$data['seller_id'] = $this->customer->getId();
				$data['partner'] = true;
				foreach ($this->config->get('module_wk_hotelbooking_res_accmenuseq') as $key => $lang_value) {
					$mp_language[$key] = $this->language->get('text_'.$key);
				}
				$data['wk_hotelbooking_res_accmenuseq'] = $mp_language;

				$data['mphotel_allowed_account_menu'] = $this->config->get('module_wk_hotelbooking_res_allowedaccmenu');
				$data['account_menu_href'] = array(
					'profile' => $this->url->link('account/customerpartner/profile', '', true),
					'dashboard' => $this->url->link('account/customerpartner/dashboard', '', true),
					'transaction' => $this->url->link('account/customerpartner/transaction', '', true),
					'addhotel' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_hotel', '', true),
					'addroom' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_room', '', true),
					'addfxfacility' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_facility', '', true),
					'addopfacility' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_opfacility', '', true),
					'hotelreview' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_review', '', true),
					'allbookings' => $this->url->link('account/customerpartner/hotel/wk_hotelbooking_res', '', true),
					'query'	=> $this->url->link('account/customerpartner/query', '',true),
					'asktoadmin' =>'',
				);
				$data['account_menu_href_icon'] = array(
					'profile' => '<i class="fa fa-user-plus"></i>',
					'dashboard' =>'<i class="fa fa-dashboard"></i>',
					'transaction' => '<i class="fa fa-credit-card"></i>',
					'addhotel'	=> '<i class="fa fa-building"></i>',
					'addroom' => '<i class="fa fa-bed"></i>',
					'addfxfacility' => '<i class="fa fa-cogs"></i>',
					'addopfacility' => '<i class="fa fa-television"></i>',
					'hotelreview' => '<i class="fa fa-comments-o"></i>',
					'allbookings' =>'<i class="fa fa-book"></i>',
					'query'	=> '<i class="fa fa-quora"></i>',
					'asktoadmin' => '<i class="fa fa-envelope-open-o"></i>',
				);
			}

		}
		if(isset($data['chkIsPartner'])){
			return $this->load->view('extension/module/wk_hotelbooking_res', $data);
		}
	}

	public function checkSlot(){
		if($this->request->server['REQUEST_METHOD'] == 'POST'){
			$booked_quan=0;
			$json = array();
			$this->load->model('extension/module/wk_hotel_booking');
			$this->load->language('extension/module/wk_hotelbooking_hotels');
			if(strtotime($this->request->post['start_time']) < strtotime($this->request->post['last_time'])) {
			if(strtotime($this->request->post['start_time']) >= strtotime(date("Y/m/d")) && strtotime($this->request->post['last_time'])>= strtotime(date("Y/m/d"))) {
			$room_info  = $this->model_extension_module_wk_hotel_booking->getRoom($this->request->post['product_id']);
			$adult = isset($this->request->post['adult']) ? $this->request->post['adult'] : 1;
			$child = isset($this->request->post['child']) ? $this->request->post['child'] : 0;
			if($adult > $room_info['max_adult'] || $child > $room_info['max_child']) {
				$json['error'] = sprintf($this->language->get('guest_error'), $room_info['max_adult'], $room_info['max_child']);
			}
			$bookedSlots = $this->model_extension_module_wk_hotel_booking->getBookedSlots($this->request->post['product_id'],$this->request->post['start_time'],$this->request->post['last_time']);

			$this->load->model('catalog/product');
			$res = $this->model_catalog_product->getProduct($this->request->post['product_id']);
			if(empty($bookedSlots) && !isset($json['error'])) {
				$cart_id = $this->cart->getproducts();
				foreach ($cart_id as $value) {
					if($value['product_id']==$this->request->post['product_id']) {
						$arr=array();
						foreach ($value['option'] as $option) {
						if($option['option_id']==$this->config->get('wk_hotelbooking_options3'))
							$arr['till'] = $option['value'];
						else if($option['option_id']==$this->config->get('wk_hotelbooking_options2'))
							$arr['from'] = $option['value'];
						}
						if(isset($arr['till']) && $arr['till']==$this->request->post['last_time'])
								$this->cart->remove($value['cart_id']);
					}
				}
					if($this->request->post['quant'] == 0){
						$json['error'] = "No room are available";
					}else if($res['quantity'] >= $this->request->post['quant']){
						$json['success'] = "Book your room now";
					} else if($res['quantity'] > 0){
								$json['error'] = "Only ".$res['quantity']." rooms are available";
						}else{
							$json['error'] = "No room are available";
						}
			} else if(!isset($json['error'])) {
					foreach($bookedSlots as $key=>$value){
								$booked_quan += $bookedSlots[$key]['quantity'];
					}
				if($res['quantity'] <= $booked_quan )
						$json['error']="No room are available";
				else if($this->request->post['quant'] > $res['quantity']-$booked_quan)
						$json['error'] = "Only ".($res['quantity']-$booked_quan)." item(s) are available";
				else
						$json['success']="Book your room now";
		 	}
		} else {
			$json['error'] = $this->language->get('error_check_in');
		}
		} else {
			$json['error'] = $this->language->get('error_check_out');
		}
	}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
 * [updateHours update the quantity to cahnge the unit price]
 * @return [type] [description]
 */
	public function updateQuantity(){
		if($this->request->server['REQUEST_METHOD'] == 'POST'){
		$this->load->model('extension/module/wk_hotel_booking');
		$result_options = $this->model_extension_module_wk_hotel_booking->getTotalOptionData($this->request->post['product_id']);
			$data['booknig_from'] = $result_options[1]['product_option_id'];
			$data['booknig_to'] = $result_options[2]['product_option_id'];
		$a=array(
			$result_options[2]['product_option_id'] => $this->request->post['till'],
			$result_options[1]['product_option_id'] => $this->request->post['from'],
			);
		$this->request->post['options']=json_encode($a);
		$this->model_extension_module_wk_hotel_booking->updateQuantity($this->request->post);
		$json['success']= 'quantity Updated';
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		}
	}

	public function getRoom(){
		$this->load->model('extension/module/wk_hotel_booking');
		if(isset($this->request->post['hotel']))
			$hotel_id = $this->request->post['hotel'];
		else
			$hotel_id = 0;
		if(isset($this->request->post['seller']))
			$seller_id = $this->request->post['seller'];
		else
			$seller_id = 0;
		$rooms = $this->model_extension_module_wk_hotel_booking->getRooms($hotel_id,$seller_id);
		$this->response->addHeader('Content-Type : application/json');
		$this->response->setOutput(json_encode($rooms));
	}
}
?>
