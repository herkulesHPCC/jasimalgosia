<?php
class ControllerExtensionModuleLayerNavigation extends Controller
{
    static $filters = array();
    static $filter_by = array();
    public function index()
    {
        if (!$this->config->get('module_wk_hotelbooking_res_status')  ||  !($this->config->get('config_store_id') == $this->config->get('module_wk_hotelbooking_res_store'))) {
            return;
        }

        if(!isset($this->session->data['checkintime']) || !isset($this->session->data['city']) ||
      !isset($this->session->data['checkouttime'])) {
          $this->response->redirect($this->url->link('common/home','',true));
        }

        //LOAD LANGUAGE
        $this->language->load('extension/module/layer_navigation');
        $this->load->model('extension/module/layer_navigation');

        $this->document->addScript('catalog/view/javascript/wk_pro_catalog_filter/jquery-ui.js');
        $this->document->addStyle('catalog/view/javascript/wk_pro_catalog_filter/jquery-ui.css');
        $this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment.min.js');
        $this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment-with-locales.min.js');
        $this->document->addScript('https://maps.googleapis.com/maps/api/js?libraries=places&key='.$this->config->get('module_wk_hotelbooking_res_google_key'));
        //SET TITLE
        $this->document->setTitle($this->language->get('text_filterheading_title'));

        $data['heading_title'] = $this->language->get('heading_title');
        $data['symbol_left'] = $this->currency->getSymbolLeft($this->session->data['currency']);
        $data['symbol_right'] = $this->currency->getSymbolRight($this->session->data['currency']);
        $data['curr_value'] = $this->currency->getValue($this->session->data['currency']);

        $data['config_min'] = $this->config->get('module_layer_navigation_price_min');
        $data['config_max'] = $this->config->get('module_layer_navigation_price_max');
        $data['path'] = $this->request->get['path'];
        return $this->load->view('extension/module/layer_navigation', $data);
    }


    public function createUrl($grp, $id = '')
    {
        $url = '';
        $selected = false;
        $category_array = array();

        if (isset($this->request->get['path'])) {
            $ncategory_array = $this->request->get['path'];

            $ncategory_array = $category_array = array_filter(explode('_', $this->request->get['path']));
            $selected = in_array($id, $category_array) ? true : false ;
            $url .= in_array($id, $category_array) ? $add : '&path=' . $this->request->get['path'];
        } elseif (!isset($this->request->get['path'])) {
            $url .= '&path=' .$id;
        } elseif (isset($this->request->get['path'])) {
            $url .= '&path=' .$this->request->get['path'];
        }
        if (isset($this->request->get['option_value']) and $grp=='opt') {
            $noption_value_array = $option_value_array = array_filter(explode('_', $this->request->get['option_value']));
            if (($key = array_search($id, $noption_value_array)) !== false) {
                unset($noption_value_array[$key]);
                $noption_value_array = implode('_', $noption_value_array);
                $add = '';
                if ($noption_value_array) {
                    $add = '&option_value=' .$noption_value_array;
                }
            }

            $selected = in_array($id, $option_value_array) ? true : false ;
            $url .= in_array($id, $option_value_array) ? $add : '&option_value=' . $this->request->get['option_value'].'_'.$id;
        } elseif (!isset($this->request->get['option_value']) and $grp=='opt') {
            $url .= '&option_value=' .$id;
        } elseif (isset($this->request->get['option_value'])) {
            $url .= '&option_value=' .$this->request->get['option_value'];
        }

        if (isset($this->request->get['attr']) and $grp=='attr') {
            $nattribute_array = $attribute_array = array_filter(explode('_', $this->request->get['attr']));
            if (($key = array_search($id, $nattribute_array)) !== false) {
                unset($nattribute_array[$key]);
                $nattribute_array = implode('_', $nattribute_array);
                $add = '';
                if ($nattribute_array) {
                    $add = '&attr=' .$nattribute_array;
                }
            }

            $selected = in_array($id, $attribute_array) ? true : false ;
            $url .= in_array($id, $attribute_array) ? $add : '&attr=' . $this->request->get['attr'].'_'.$id;
        } elseif (!isset($this->request->get['attr']) and $grp=='attr') {
            $url .= '&attr=' .$id;
        } elseif (isset($this->request->get['attr'])) {
            $url .= '&attr=' .$this->request->get['attr'];
        }

        return array('url' => $url ,'selected' => $selected);
    }

      public function loadData()
    {
        $json = array();
				$data['all_hotels'] = array();

        $this->load->language('product/category');
        $this->load->language('extension/module/layer_navigation');
        $this->load->language('extension/module/wk_hotel_booking');

        $this->load->model('catalog/category');
        $this->load->model('catalog/product');
        $this->load->model('tool/image');
        $this->load->model('extension/module/wk_hotel_booking');


        $category_id = $this->request->get['path'] = $hotel = isset($this->request->get['path']) ? $this->request->get['path'] : 0;
        // Url Preserve
        $url = '';
        $url_array = array(
                'limit',
                'max_price',
                'checkintime',
                'hotel',
                'checkouttime',
                'min_price',
                'filter',
                'attr',
                'option_value',
                'categ',
                'page'
        );
        foreach ($url_array as $url_element) {
            $url .= isset($this->request->get[$url_element]) ? '&'.$url_element.'='. $this->request->get[$url_element] : '';
        }

        //Sort Url
        $data['sorts'] = array();

        $sort_array = array(
                'text_default' => 'c.sort_order-ASC',
                'text_name_asc' => 'cd.name-ASC',
                'text_name_desc' => 'cd.name-DESC',
                'text_distances' => 'distance-ASC',
                'text_distance_rev'=>'distance-DESC'
            );
        foreach ($sort_array as $key => $sort_elem) {
            $elem = explode('-', $sort_elem);
            $data['sorts'][] = array(
                'text' => $this->language->get($key),
                'value' => $sort_elem,
                'href'=> $this->url->link('product/category', 'path=' . $this->request->get['path'] . '&sort='.$elem[0].'&order='.$elem[1]. $url)
            );
        }

        if (isset($this->request->get['page'])) {
           $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

			 $return_data =  $this->searchHotels($category_id,$page);

       $data['all_hotels'] = $return_data['hotels'];

       $data['pagination'] = isset($return_data['pagination'])?$return_data['pagination'] :'';
       if($return_data['address'] && is_array($return_data['address'])) {
        $data = array_merge($data,$return_data['address']);
       }

			 $data['text_interested_show'] = ($category_id && $category_id!=$this->config->get('wk_hotelbookingcat_categoryid')) ? $category_id : 0;

       if($data['text_interested_show']) {
         $int_show_flag = 0;
         array_filter($data['all_hotels'],function($v) use (&$int_show_flag,$category_id){
           if($v['category_id'] == $category_id ) {
             $int_show_flag = 1;
           }
         });

         if($int_show_flag==0) {
           $data['text_interested_show'] = 0;
         }
       }


        if (isset($category_info)) {
            $this->document->setTitle($category_info['meta_title']);
            $this->document->setDescription($category_info['meta_description']);
            $this->document->setKeywords($category_info['meta_keyword']);
            $this->document->addLink($this->url->link('product/category', 'path=' . $this->request->get['path']), 'canonical');
            $data['thumb'] = $category_info['image'] ? $this->model_tool_image->resize($category_info['image'], 150, 150) : '';

            $data['description'] = html_entity_decode($category_info['description'], ENT_QUOTES, 'UTF-8');

            $data['compare'] = $this->url->link('product/compare');

        }
				$json = $this->response->setOutput($this->load->view('product/layer_navigation_all', $data));
        return $json;
    }

    public function updatedSearchData()
    {
        $this->session->data['checkintime'] = isset($this->request->post['checkintime']) ? $this->request->post['checkintime'] : '';
        $this->session->data['checkouttime'] = isset($this->request->post['checkouttime']) ? $this->request->post['checkouttime'] : '';
        $this->session->data['city'] = isset($this->request->post['city']) ? $this->request->post['city'] : '';
        $this->session->data['hotel'] = isset($this->request->post['hotel']) && $this->config->get('wk_hotelbookingcat_categoryid')!= $this->request->post['hotel'] ? $this->request->post['hotel'] : '';
        $this->session->data['adult'] = isset($this->request->post['adult']) ? $this->request->post['adult'] : 1;
        $this->session->data['child'] = isset($this->request->post['child']) ? $this->request->post['child'] : 0;
        $this->session->data['room'] = isset($this->request->post['room']) ? $this->request->post['room'] : 1;
        $this->response->addHeader('Content-Type:application/json');
        $this->response->setOutput(json_encode(array()));
    }


    public function searchHotels($category_id = '',$page=1)
    {
        $this->load->model('extension/module/layer_navigation');
        $this->load->model('extension/module/wk_hotel_booking');
				$this->load->model('tool/image');
        $this->load->language('extension/module/wk_hotel_booking');
        $this->load->model('catalog/product');
				$search_hotels = array();
				if ($this->request->server['HTTPS']) {
					$server = $this->config->get('config_ssl');
				} else {
					$server = $this->config->get('config_url');
				}
        if(isset($this->request->get['page'])) {
          $page = $this->request->get['page'];
        } else {
          $page= 1;
        }

        if(isset($this->request->post) && isset($this->request->post['notToFilter'])) {
          $notToFilter = $this->request->post['notToFilter'];
        } else {
          $notToFilter = array();
        }
        if($this->request->server['REQUEST_METHOD']=='POST' && isset($this->request->post['page'])) {
          $page = $this->request->post['page'];
        }
        $filter_array = array(
          'sort' => isset($this->request->get['sort']) ? $this->request->get['sort'] : null,
          'start'  => ($page - 1) * 5,
          'order' => isset($this->request->get['order']) ? $this->request->get['order'] : null,
          //'categ' => $search_hotels[$key]['category_id'],
          'checkintime' => isset($this->session->data['checkintime']) ? $this->session->data['checkintime'] : null,
          'checkouttime' => isset($this->session->data['checkouttime']) ? $this->session->data['checkouttime'] : null,
          'adult' => isset($this->session->data['adult']) ? $this->session->data['adult'] : null,
          'child' => isset($this->session->data['child']) ? $this->session->data['child'] : null,
          'room' => isset($this->session->data['room']) ? $this->session->data['room'] : null,
          'min' => isset($this->request->get['min']) && $this->request->get['min'] ? $this->request->get['min'] : (isset($this->request->get['min_price'])? $this->request->get['min_price'] :$this->config->get('module_layer_navigation_price_min')),
          'max' => isset($this->request->get['max']) && $this->request->get['max'] ? $this->request->get['max'] : (isset($this->request->get['max_price'])? $this->request->get['max_price'] :$this->config->get('module_layer_navigation_price_max')),
          'attr' => isset($this->request->get['attr']) && $this->request->get['attr'] ? $this->request->get['attr'] : '',
          'option_value' => isset($this->request->get['option_value']) && $this->request->get['option_value'] ? $this->request->get['option_value'] : '',
        );
        // if(isset($this->request->get['city']) && $this->request->get['city']) {
        //   $this->session->data['city'] = $this->request->get['city'];
        // }
				if (isset($this->session->data['city']) && $this->session->data['city'] || $category_id) {

					if($category_id && $category_id != $this->config->get('wk_hotelbookingcat_categoryid')) {
            $hotel_details = $this->model_extension_module_layer_navigation->getHotel($category_id);
						$default_hotel_address['latitude'] = $lat = isset($hotel_details['latitude']) ? $hotel_details['latitude'] : 0 ;
						$default_hotel_address['longitude'] = $long = isset($hotel_details['longitude']) ? $hotel_details['longitude'] : 0 ;
					} else {

              if(!isset($this->session->data['city'])) {
                $this->load->model('localisation/zone');
                $zone = $this->model_localisation_zone->getZone($this->config->get('config_zone_id'));
                $this->session->data['city'] = $zone['name'];
              }

							$city = $this->session->data['city'];


							$address = str_replace(" ", "+", $city);
              $url = "https://maps.google.com/maps/api/geocode/json?key=". $this->config->get('module_wk_hotelbooking_res_google_key') ."&address=$address";
              $ch = curl_init();
              curl_setopt($ch, CURLOPT_URL, $url);
              curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
              curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
              curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
              curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
              $response = curl_exec($ch);
              curl_close($ch);

            $response = json_decode($response);

              if($response->results) {
                $lat = $response->results[0]->geometry->location->lat;
      					$long = $response->results[0]->geometry->location->lng;
      					$default_hotel_address['latitude'] = $lat;
      					$default_hotel_address['longitude'] = $long;
              } else {
                $address_values = $this->model_extension_module_layer_navigation->getHotelbyName($city);
                $default_hotel_address['latitude'] = $lat = $address_values['latitude'];
  						 	$default_hotel_address['longitude'] = $long = $address_values['longitude'];
              }
					}
          $search_hotels  = array_merge($search_hotels,$this->model_extension_module_layer_navigation->getHotelFromcity($lat, $long,$category_id,$filter_array));
          $totalHotels = $this->model_extension_module_layer_navigation->getHotelFromcity($lat, $long,$category_id,$filter_array,true);
          $totalHotels = count($totalHotels);
				 	if ($search_hotels) {
            if(!isset($default_hotel_address) && isset($search_hotels[0])) {
              $default_hotel_address['latitude'] = $lat = isset($search_hotels[0]['latitude']) ? $search_hotels[0]['latitude'] : 0 ;
  						$default_hotel_address['longitude'] = $long = isset($search_hotels[0]['longitude']) ? $search_hotels[0]['longitude'] : 0 ;

            }
				     	foreach ($search_hotels as $key => $value) {
				         	$image = $search_hotels[$key]['image'];

				         	if ($image) {
				             	$search_hotels[$key]['image'] = $server . 'image/' .$image;//$this->model_tool_image->resize($image, 100, 100);
				             	$search_hotels[$key]['thumb'] = $server . 'image/' .$image;//$this->model_tool_image->resize($image, 200, 200);
				         	} else {
				             	$search_hotels[$key]['image'] = $this->model_tool_image->resize('placeholder.png', 100, 100);
				             	$search_hotels[$key]['thumb'] = $this->model_tool_image->resize('placeholder.png', 200, 200);
				         	}

				         	$review_info = $this->model_extension_module_wk_hotel_booking->getReview($value['category_id']);

				         	$rating = 0;

				         	if ($review_info) {
				             	foreach ($review_info as $key1 => $value1) {
				                 	$rating += $value1['rating'];
				             	}
				             	$rating = $rating/sizeof($review_info);
				         	}

				         	$search_hotels[$key]['rating'] = $rating;

				         	$search_hotels[$key]['reviews'] = sprintf($this->language->get('text_reviews'), sizeof($review_info));

				         	$this->load->model('catalog/product');

				         	$search_hotels[$key]['href']  = $this->url->link('extension/module/wk_hotel', '&hotel_id=' . $search_hotels[$key]['category_id']);

									$search_hotels[$key]['description'] = utf8_substr(strip_tags(html_entity_decode($value['description'], ENT_QUOTES, 'UTF-8')), 0, 170) . ' '.'<a href='.$search_hotels[$key]['href'].'>'.$this->language->get('text_read_more').'</a>';

                  if(isset($value['room_id']) && $value['room_id']) {
                    $avail_rooms = array();
                    $rooms = explode(',',$value['room_id']);

                    foreach ($rooms as  $room) {
                      if(isset($filter_array['checkintime']) && isset($filter_array['checkouttime']) && $filter_array['checkintime'] && $filter_array['checkouttime']) {
                        $bookedSlots = $this->model_extension_module_wk_hotel_booking->getBookedSlots($room,$filter_array['checkintime'],$filter_array['checkouttime']);
                        if(!$bookedSlots) {
                          $avail_rooms[] = $room;
                        } else {
                          $booked_quan = 0;
                          foreach($bookedSlots as $key1=>$value1){
                    						$booked_quan += $bookedSlots[$key1]['quantity'];
                    			}
                          $product_info = $this->model_catalog_product->getProduct($value['room_id']);

                          if($product_info && isset($product_info['quantity']) && $filter_array['room'] < ($product_info['quantity']-$booked_quan)) {
                            $avail_rooms[] = $room;
                          }
                        }
                        if($avail_rooms) {
                          $search_hotels[$key]['rooms_left'] = sprintf($this->language->get('text_hurry'),count($avail_rooms));
                          $search_hotels[$key]['label_class'] = 'hurry_up_label';
                        } else {
                          $search_hotels[$key]['rooms_left'] = $this->language->get('text_missed');
                          $search_hotels[$key]['label_class'] = 'missed_label';
                        }
                      }
                    }
                  } else {
                     $search_hotels[$key]['rooms_left'] = $this->language->get('text_missed');
                     $search_hotels[$key]['label_class'] = 'missed_label';
                  }
				     	}
				   }
          if($this->request->server['REQUEST_METHOD']=='POST' && isset($this->request->post['hotels'])) {
              $this->response->addHeader('Content-Type:application/json');
              $search_hotels = array_merge($search_hotels,$default_hotel_address,$this->getFilters($search_hotels,$notToFilter));
              $this->response->setOutput(json_encode($search_hotels));
              return;
          }
          $pagination = new Pagination();
          $pagination->total = $totalHotels;
          $pagination->page = $page;
          $pagination->limit = 5;
          $pagination_view = $pagination->render();
					 return array('hotels'=>$search_hotels,'address'=>$default_hotel_address,'pagination'=>$pagination_view);
        }
    }

    function getFilters($search_hotels,$notToFilter) {


      $filter_array = array();
      $filter_array['fixed'] = array();
      $filter_array['optionals'] = array();
      foreach ($search_hotels as $hotel) {
        // Get all the rooms and there attributes and options for filter
        $this->load->model('extension/module/layer_navigation');
        $rooms = explode(',',$hotel['room_id']);

        $this->load->model('catalog/product');
        foreach ($rooms as $room) {
          $fixed = $this->model_catalog_product->getProductAttributes($room);
          $options = $this->model_catalog_product->getProductOptions($room);

          if(!is_array($notToFilter) || !in_array('fx',$notToFilter)) {
            foreach ($fixed as $key => $value) {
              if($value['attribute_group_id'] == $this->config->get('wk_hotelbookingattr_attrgroupid')) {
                $filter_array['fixed']= array_merge($filter_array['fixed'],$value['attribute']);
                break;
              }
            }
          }

            foreach ($options as $option) {
                if($option['option_id'] == $this->config->get('wk_hotelbookingopt_optionid') && isset($option['product_option_value']) && $option['product_option_value']) {
                  foreach($option['product_option_value'] as $product_option) {
                    if(!isset($filter_array['optionals'][$product_option['option_value_id']])) {
                        $filter_array['optionals'][$product_option['option_value_id']] =$product_option['name'];
                    }
                  }
                  break;
                }
            }

        }
      }
      $filter_fixed = array();
      if(!is_array($notToFilter) || !in_array('fx',$notToFilter)) {
        if($filter_array['fixed']) {
          array_filter($filter_array['fixed'],function($arr) use (&$filter_fixed) {
              if(!array_key_exists($arr['attribute_id'],$filter_fixed)) {
                  $filter_fixed[$arr['attribute_id']] = $arr['name'];
              }
          });
          $filter_array['fixed'] = $filter_fixed;
        }
     } else {
       unset($filter_array['fixed']);
     }
     if(is_array($notToFilter) && in_array('op',$notToFilter)) {
       unset($filter_array['optionals']);
     }
      return $filter_array;
    }
}
