<?php
$_['heading_title']  			= 'Invoice for Order : #';
$_['text_order_details'] 		= 'Order details';
$_['text_order_id']				= "Order id : #";
$_['text_order_status']			= 'Order Status : ';
$_['text_payment_method']		= "Payment Method : ";
$_['text_order_date']			= 'Order Date : ';
$_['text_account_info']			= 'Account Information ';
$_['text_customer_name']		= "Name : ";
$_['text_purchase_info']		= 'Purchase Information ';
$_['text_ip']					= "IP Address : ";
$_['text_store_name']			= 'Store Name : ';
$_['text_item']					= 'Item of Invoice ';
$_['column_name']				= "Product Name";
$_['column_model']				= 'Model Name';
$_['column_dates']				= "Booking Dates";
$_['column_price']				= "Price";
$_['column_quantity']			= "Quantity";
$_['column_total']				= "Total";
?>